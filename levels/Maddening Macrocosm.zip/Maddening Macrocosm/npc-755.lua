local npcManager = require("npcManager")
local vectr = require("vectr")
local particles = require("particles")

local sentinel = {}
local npcID = NPC_ID

local sentinelSettings = {
	id = npcID,
	gfxheight = 32,
	gfxwidth = 32,
	width = 32,
	height = 32,
	gfxoffsetx = 0,
	gfxoffsety = 0,
	frames = 1,
	framestyle = 0,
	framespeed = 8,
	speed = 1,
	npcblock = false,
	npcblocktop = false,
	playerblock = false,
	playerblocktop = false,
	nohurt=false,
	nogravity = true,
	noblockcollision = true,
	nofireball = true,
	noiceball = true,
	noyoshi= true,
	nowaterphysics = true,
	jumphurt = true,
	spinjumpsafe = true,
	harmlessgrab = false,
	harmlessthrown = false,
	grabside=false,
	grabtop=false,
}

npcManager.setNpcSettings(sentinelSettings)

function sentinel.onInitAPI()
	npcManager.registerEvent(npcID, sentinel, "onTickNPC")
	npcManager.registerEvent(npcID, sentinel, "onDrawNPC")
end

function sentinel.onTickNPC(v)
	if Defines.levelFreeze then return end
	
	local data = v.data
	
	if v:mem(0x12A, FIELD_WORD) <= 0 then
		data.initialized = false
		return
	end

	if not data.initialized then
		data.initialized = true
		data.atkVectr = nil
		data.spikedBorder = Sprite{
			image = Graphics.loadImage(Misc.resolveFile("sentinelSpikes.png")),
			x = v.x + v.width * 0.5,
			y = v.y + v.height * 0.5,
			align = Sprite.align.CENTER
		}
		data.spikedBorder2 = Sprite{
			image = Graphics.loadImage(Misc.resolveFile("sentinelSpikes2.png")),
			x = v.x + v.width * 0.5,
			y = v.y + v.height * 0.5,
			align = Sprite.align.CENTER
		}
		data.particles = particles.Ribbon(0,0, Misc.resolveFile("sentinel_trail.ini"))
		data.particles:Attach(v)
		data.wait = 0
	end

	for _,p in ipairs(Player.get()) do
		if p.x < v.x + v.width * 3 and
		   p.x > v.x - v.width * 2 and
		   p.y > v.y - v.height * 2 and
		   p.y < v.y + v.height * 3 then
			data.atkVectr = vectr.v2(
				(player.x + player.width * 0.5) - (v.x + v.width * 0.5),
				(player.y + player.height * 0.5) - (v.y + v.height * 0.5)):normalize() * 1.3
		else
			data.atkVectr = vectr.v2(
				(player.x + player.width * 0.5) - (v.x + v.width * 0.5),
				(player.y + player.height * 0.5) - (v.y + v.height * 0.5)):normalize() * 1.5
		end
		if p:mem(0x122, FIELD_WORD) == 0 and p:mem(0x13E, FIELD_WORD) == 0 then
			if data.wait == 0 then
				v.speedX = data.atkVectr.x
				v.speedY = data.atkVectr.y
			else
				data.wait = data.wait - 1
			end
		else
			v.speedX = 0
			v.speedY = 0
			data.wait = 64
		end
		data.spikedBorder:rotate(6)
		data.spikedBorder2:rotate(6)
	end
end

function sentinel.onDrawNPC(v)
	v.data.spikedBorder.x = v.x + v.width * 0.5
	v.data.spikedBorder.y = v.y + v.height * 0.5
	v.data.spikedBorder2.x = v.x + v.width * 0.5
	v.data.spikedBorder2.y = v.y + v.height * 0.5
	v.data.spikedBorder:draw{
		priority = -45,
		sceneCoords = true
	}
	v.data.spikedBorder2:draw{
		priority = -44,
		sceneCoords = true
	}
	Graphics.drawImageToSceneWP(Graphics.loadImage(Misc.resolveFile("npc-755.png")), v.x, v.y, -43)
	v.data.particles:Draw(-60)
end

return sentinel