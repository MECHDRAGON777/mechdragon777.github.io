local npcManager = require("npcManager")
local vectr = require("vectr")

local bigFireball = {}
local npcID = NPC_ID

local bigFireballSettings = {
	id = npcID,
	gfxheight = 128,
	gfxwidth = 128,
	width = 128,
	height = 128,
	gfxoffsetx = 0,
	gfxoffsety = 0,
	frames = 1,
	framestyle = 0,
	framespeed = 8,
	speed = 1,
	npcblock = false,
	npcblocktop = false,
	playerblock = false,
	playerblocktop = false,
	nohurt=false,
	nogravity = true,
	noblockcollision = true,
	nofireball = true,
	noiceball = true,
	noyoshi= true,
	nowaterphysics = true,
	jumphurt = true,
	spinjumpsafe = false,
	harmlessgrab = false,
	harmlessthrown = false,
	grabside=false,
	grabtop=false,
}

npcManager.setNpcSettings(bigFireballSettings)


function bigFireball.onInitAPI()
	npcManager.registerEvent(npcID, bigFireball, "onTickNPC")
	--npcManager.registerEvent(npcID, bigFireball, "onTickEndNPC")
	npcManager.registerEvent(npcID, bigFireball, "onDrawNPC")
	--registerEvent(bigFireball, "onNPCKill")
end

function bigFireball.onTickNPC(v)
	if Defines.levelFreeze then return end
	
	local data = v.data
	
	if v:mem(0x12A, FIELD_WORD) <= 0 then
		data.initialized = false
		return
	end

	if not data.initialized then
		data.initialized = true
		data.atkVectr = nil
		data.waitTime = 240
		v:mem(0x46, FIELD_BOOL, true)
		data.fireball = Graphics.loadImage(Misc.resolveFile("bigFireball.png"))
		data.sprite = Sprite{
			image = data.fireball,
			x = v.x + v.width * 0.5,
			y = v.y + v.height * 0.5,
			align = Sprite.align.CENTER
		}
		data.scale = data.sprite.scale
		data.sprite.scale = data.sprite.scale - data.sprite.scale
	end

	data.sprite:rotate(20)
	data.sprite.x = v.x + v.width * 0.5
	data.sprite.y = v.y + v.height * 0.5
	if data.waitTime > 0 then
		if data.sprite.scale[1] < data.scale[1] then
			data.sprite.scale = data.sprite.scale + 0.05
		else
			v:mem(0x46, FIELD_BOOL, false)
		end
		data.waitTime = data.waitTime - 1
	else
		if not(data.atkVectr) then
			data.atkVectr = vectr.v2(
				(player.x + player.width * 0.5) - (v.x + v.width * 0.5),
				(player.y + player.height * 0.5) - (v.y + v.height * 0.5)):normalize() * 3
			SFX.play(42)
		end
		v.speedX = data.atkVectr.x
		v.speedY = data.atkVectr.y
	end
end

function bigFireball.onDrawNPC(v)
	local data = v.data
	
	if data.sprite ~= nil then
		data.sprite:draw{
			priority = -45,
			sceneCoords = true
		}
	end
	if data.waitTime ~= nil then
		if data.waitTime > 0 then
			if player.section == 10 then
				v.x = camera.x + 96
			elseif player.section ~= 9 then
				v.x = camera.x + 336
			else
				v.x = camera.x + 576
			end
			if player.section == 8 then
				v.y = camera.y + 60
			else
				v.y = camera.y + 236
			end
		end
	end
end
return bigFireball