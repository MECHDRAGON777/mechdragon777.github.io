local npcManager = require("npcManager")
local lineguide = require("base/lineguide")

local jumpPlatform = {}
local npcID = NPC_ID

lineguide.registerNpcs({832})

local jumpPlatformSettings = {
	id = npcID,
	gfxheight = 96,
	gfxwidth = 32,
	width = 96,
	height = 32,
	gfxoffsetx = 0,
	gfxoffsety = 0,
	frames = 9,
	framestyle = 0,
	framespeed = 8,
	speed = 1,
	npcblock = false,
	npcblocktop = true,
	playerblock = false,
	playerblocktop = true,
	nohurt=true,
	nogravity = false,
	noblockcollision = true,
	nofireball = true,
	noiceball = true,
	noyoshi= true,
	nowaterphysics = false,
	jumphurt = false,
	spinjumpsafe = false,
	harmlessgrab = false,
	harmlessthrown = false,
	grabside=false,
	grabtop=false
}

npcManager.setNpcSettings(jumpPlatformSettings)

function jumpPlatform.onInitAPI()
	npcManager.registerEvent(npcID, jumpPlatform, "onTickNPC")
	npcManager.registerEvent(npcID, jumpPlatform, "onDrawNPC")
end

function jumpPlatform.onTickNPC(v)
	if Defines.levelFreeze then return end
	
	local data = v.data
	
	v:mem(0xE8, FIELD_FLOAT, 0)
	
	if v:mem(0x146, FIELD_WORD) == player.section then
		v:mem(0x12A, FIELD_WORD, 180)
	end
	
	if v:mem(0x12A, FIELD_WORD) <= 0 then
		data.initialized = false
		return
	end

	if not data.initialized then
		data.initialized = true
		settings = data._settings
		data.on = settings.on or 0
		data.wait = 2
		data.button = false
	end
	
	for _,p in ipairs(Player.get()) do
		if not(data.button) and p.speedY < 0 then
			data.button = true
			if data.on == 0 then
				data.on = 1
			else
				data.on = 0
			end
			if v.x > camera.x - 96 and v.x < camera.x + camera.width + 96 and v.y > camera.y - 96 and v.y + v.height < camera.y + camera.height + 96 then
				SFX.play(32)
			end
		end
		if not(p.keys.jump) and not(p.keys.altJump) and p.speedY > 0 then
			data.button = false
		end
	end
	
	if data.on then
		
	end
end

function jumpPlatform.onDrawNPC(v)
	if v.data.on == 0 then
		if v.animationFrame < 7 then
			if v.data.wait == 2 then
				v.animationFrame = v.animationFrame + 1
				v.data.wait = 0
			else
				v.data.wait = v.data.wait + 1
			end
		else
			v.animationFrame = 0
		end
		v:mem(0x46, FIELD_BOOL, false)
	else
		v.animationFrame = 8
		v:mem(0x46, FIELD_BOOL, true)
	end
end

return jumpPlatform