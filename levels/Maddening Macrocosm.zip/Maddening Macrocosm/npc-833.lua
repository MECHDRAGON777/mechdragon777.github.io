local npcManager = require("npcManager")
local lineguide = require("base/lineguide")

local blueJumpPlatform = {}
local npcID = NPC_ID

lineguide.registerNpcs({833})

local blueJumpPlatformSettings = {
	id = npcID,
	gfxheight = 96,
	gfxwidth = 32,
	width = 96,
	height = 32,
	gfxoffsetx = 0,
	gfxoffsety = 0,
	frames = 9,
	framestyle = 0,
	framespeed = 8,
	speed = 1,
	npcblock = false,
	npcblocktop = true,
	playerblock = false,
	playerblocktop = true,
	nohurt=true,
	nogravity = false,
	noblockcollision = true,
	nofireball = true,
	noiceball = true,
	noyoshi= true,
	nowaterphysics = false,
	jumphurt = false,
	spinjumpsafe = false,
	harmlessgrab = false,
	harmlessthrown = false,
	grabside=false,
	grabtop=false
}

npcManager.setNpcSettings(blueJumpPlatformSettings)

function blueJumpPlatform.onInitAPI()
	npcManager.registerEvent(npcID, blueJumpPlatform, "onTickNPC")
	npcManager.registerEvent(npcID, blueJumpPlatform, "onDrawNPC")
end

function blueJumpPlatform.onTickNPC(v)
	if Defines.levelFreeze then return end
	
	local data = v.data
	
	v:mem(0xE8, FIELD_FLOAT, 0)
	
	if v:mem(0x146, FIELD_WORD) == player.section then
		v:mem(0x12A, FIELD_WORD, 180)
	end
	
	if v:mem(0x12A, FIELD_WORD) <= 0 then
		data.initialized = false
		return
	end

	if not data.initialized then
		data.initialized = true
		settings = data._settings
		data.on = settings.on or 0
		data.timer = settings.timer or 2
		data.timer = data.timer * 64
		data.timerGoal = data.timer
		data.wait = 2
	end
	
	if data.timer == data.timerGoal then
		if data.on == 0 then
			data.on = 1
		else
			data.on = 0
		end
		if v.x > camera.x - 96 and v.x < camera.x + camera.width + 96 and v.y > camera.y - 96 and v.y + v.height < camera.y + camera.height + 96 then
			SFX.play(32)
		end
		data.timer = 0
	elseif player:mem(0x122, FIELD_WORD) == 0 then
		data.timer = data.timer + 1
	end
end

function blueJumpPlatform.onDrawNPC(v)
	if v.data.on == 0 then
		if v.animationFrame < 7 then
			if v.data.wait == 2 then
				v.animationFrame = v.animationFrame + 1
				v.data.wait = 0
			else
				v.data.wait = v.data.wait + 1
			end
		else
			v.animationFrame = 0
		end
		v:mem(0x46, FIELD_BOOL, false)
	else
		v.animationFrame = 8
		v:mem(0x46, FIELD_BOOL, true)
	end
end

return blueJumpPlatform