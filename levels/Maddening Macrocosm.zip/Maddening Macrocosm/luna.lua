local defGrav = require("defGrav")

------------------------------------------------------------------------------------------------
----										I M A G E S										----
------------------------------------------------------------------------------------------------
local bg1 = Graphics.loadImage(Misc.resolveFile("backgrounds/background1.png"))
local tile = Graphics.loadImage(Misc.resolveFile("backgrounds/tile.png"))
local flowerBG1 = Graphics.loadImage(Misc.resolveFile("backgrounds/flowerRoom1.png"))
local flowerBG2 = Graphics.loadImage(Misc.resolveFile("backgrounds/flowerRoom2.png"))
local flowerBG3 = Graphics.loadImage(Misc.resolveFile("backgrounds/flowerRoom3.png"))
local flowerBG4 = Graphics.loadImage(Misc.resolveFile("backgrounds/flowerRoom4.png"))
local flowerBG5 = Graphics.loadImage(Misc.resolveFile("backgrounds/flowerRoom5.png"))
local flowerBG6 = Graphics.loadImage(Misc.resolveFile("backgrounds/flowerRoom6.png"))
local eyeBallIMG = Graphics.loadImage(Misc.resolveFile("backgrounds/eyeBall.png"))
local eyeShadeIMG = Graphics.loadImage(Misc.resolveFile("backgrounds/eyeShade.png"))
local eyePupilIMG = Graphics.loadImage(Misc.resolveFile("backgrounds/eyePupil.png"))
local negativePupilIMG = Graphics.loadImage(Misc.resolveFile("backgrounds/negativePupil.png"))
local cutsceneIMG = Graphics.loadImage(Misc.resolveFile("cutscene.png"))
local bottomlessPit = Graphics.loadImage(Misc.resolveFile("bottomlessPit.png"))
local warpEff = Graphics.loadImage(Misc.resolveFile("warpEff.png"))
local warpEff2 = Graphics.loadImage(Misc.resolveFile("warpEff2.png"))
local messageIMG = Graphics.loadImage(Misc.resolveFile("message.png"))
local bananas = Graphics.loadImage(Misc.resolveFile("backgrounds/banana.png"))
local starCoin = Graphics.loadImage(Misc.resolveFile("starCoin.png"))

------------------------------------------------------------------------------------------------
----									V A R I A B L E S									----
------------------------------------------------------------------------------------------------
local cutscene = false
local flowerGot = false
local topC = camera.y - 64
local bottomC = camera.y + camera.height
local eyeSize = 400
local messageTimer = 100
local flashOp = 1
local textOp = 0
local ceroFlash = 0
local firstFlash = 0
local finalFlash = 0
local isAgressive = false
local spawnTimer = 400
local flowerChange1 = false
local pupilY = camera.y + camera.height * 0.5
local pupilX = camera.x + camera.width * 0.5
local endTimer = 0
local endTimerRun = 0
local finalFlashTimer = 30
local countdown = 5
local natureGottaWait = 100
local deathWait = 2
local deathTurn = 1
local endOp = 0
local bananaFrame = 0
local bananaTimer = 4
local soundHasPlayer = false
local beforeItChanges = 0
local bananaY = 19488
local oneUpTimer = 32
local oneUp = 10
local coinFrame = 0
local coinTimer = 8
local starCount = 0

------------------------------------------------------------------------------------------------
----									  S P R I T E S									    ----
------------------------------------------------------------------------------------------------
local tile1 = Sprite{
	image = tile,
	align = Sprite.align.CENTER
}
local tile2 = Sprite{
	image = tile,
	align = Sprite.align.CENTER
}
local vortex = Sprite{
	image = bg1,
	x = camera.x + camera.width * 0.5,
	y = camera.y + camera.height * 0.5,
	align = Sprite.align.CENTER
}
local flowerVortex1 = Sprite{
	image = flowerBG1,
	x = camera.x + camera.width * 0.5,
	y = camera.y + camera.height * 0.5,
	align = Sprite.align.CENTER
}
local flowerVortex2 = Sprite{
	image = flowerBG2,
	x = camera.x + camera.width * 0.5,
	y = camera.y + camera.height * 0.5,
	align = Sprite.align.CENTER
}
local flowerVortex3 = Sprite{
	image = flowerBG3,
	x = camera.x + camera.width * 0.5,
	y = camera.y + camera.height * 0.5,
	align = Sprite.align.CENTER
}
local eyeBallVortex = Sprite{
	image = eyeBallIMG,
	x = camera.x + camera.width * 0.5,
	y = camera.y + camera.height * 0.5,
	align = Sprite.align.CENTER
}
local eyeShadeVortex = Sprite{
	image = eyeShadeIMG,
	x = camera.x + camera.width * 0.5,
	y = camera.y + camera.height * 0.5,
	align = Sprite.align.CENTER
}
local eyePupilVortex = Sprite{
	image = eyePupilIMG,
	x = camera.x + camera.width * 0.5,
	y = camera.y + camera.height * 0.5,
	align = Sprite.align.CENTER
}

------------------------------------------------------------------------------------------------
----									F U N C T I O N S									----
------------------------------------------------------------------------------------------------
function onStart()
	--The following lines save the normal scale of the eye parts for later use.
	scale = eyeBallVortex.scale
	scale2 = eyeShadeVortex.scale
	scale3 = eyePupilVortex.scale
end

function onTick()
	--The following lines keep the sprites coordinates attached to the camera.
	vortex.x = camera.x + camera.width * 0.5
	vortex.y = camera.y + camera.height * 0.5
	flowerVortex1.x = pupilX
	flowerVortex2.x = pupilX
	flowerVortex3.x = pupilX
	flowerVortex1.y = pupilY
	flowerVortex2.y = pupilY
	flowerVortex3.y = pupilY
	--The following lines rotate specific sprites because they look cool.
	if not(vend) then
		vortex:rotate(1)
		flowerVortex1:rotate(2)
		flowerVortex2:rotate(-1)
		flowerVortex3:rotate(1)
		tile1:rotate(1)
		tile2:rotate(-1)
		eyeBallVortex:rotate(-0.5)
	end
	if flowerGot or player.section > 6 then
		--The following lines change the flower room vortex color to red.
		flowerVortex1.image = flowerBG4
		flowerVortex2.image = flowerBG5
		flowerVortex3.image = flowerBG6
	end
	if cutscene then
		if player.section < 11 then
			if topC < 0 and messageTimer > 0 then
				topC = topC + 2
				hud(false)
			end
			if bottomC > 536 and messageTimer > 0 then
				bottomC = bottomC - 2
			end
		end
		if player.section == 6 then
			if eyeBallVortex.scale[1] < scale[1] and not(revert) then
				eyeBallVortex.scale = eyeBallVortex.scale + 0.05
				eyeShadeVortex.scale = eyeShadeVortex.scale + 0.05
				eyePupilVortex.scale = eyePupilVortex.scale + 0.05
			elseif eyeBallVortex.scale[1] < scale[1] + 0.1 and not(revert) then
				eyeBallVortex.scale = eyeBallVortex.scale + 0.025
				eyeShadeVortex.scale = eyeShadeVortex.scale + 0.025
				eyePupilVortex.scale = eyePupilVortex.scale + 0.025
			elseif eyeBallVortex.scale[1] < scale[1] + 0.25 and not(revert) then
				eyeBallVortex.scale = eyeBallVortex.scale + 0.0125
				eyeShadeVortex.scale = eyeShadeVortex.scale + 0.0125
				eyePupilVortex.scale = eyePupilVortex.scale + 0.0125
			else
				messageTimer = messageTimer - 1
				revert = true
			end
			if revert and eyeBallVortex.scale[1] > scale[1] then
				eyeBallVortex.scale = eyeBallVortex.scale - 0.0125
				eyeShadeVortex.scale = eyeShadeVortex.scale - 0.0125
				eyePupilVortex.scale = eyePupilVortex.scale - 0.0125
			else
				if textOp < 1 and messageTimer > 0 then
					textOp = textOp + 0.025
				elseif messageTimer < 0 and textOp > 0 then
					textOp = textOp - 0.025
				elseif topC ~= -64 then
					topC = topC - 2
					bottomC = bottomC + 2
				else
					cutscene = false
					doNotMove = false
					hud(true)
				end
			end
		elseif player.section == 10 then
			messageTimer = 100
			Layer.get("spikes"):hide(true)
			player.speedX = 0
			doNotMove = true
			isAgressive = false
			for _, j in ipairs(NPC.get(959)) do
				j:kill()
			end
			if endTimer < 1 then
				if player.section < 11 then
					flowerGot = true
				end
				if finalFlashTimer == 0 and flashOp == 1 then
					if countdown < 10 and countdown > 6 then
						flowerGone = true
					elseif countdown < 6 and countdown > 4 then
						flowerGone = true
					elseif countdown < 4 and countdown > 2 then
						Layer.get("missing1"):hide(true)
					elseif countdown < 2 and countdown > 0 then
						Layer.get("missing2"):hide(true)
					elseif countdown < 1 then
						if natureGottaWait > 0 then
							stay = true
						else
							Layer.get("warp"):show(true)
							stay = false
						end
						natureGottaWait = natureGottaWait - 0.5
					end
					if countdown > 0 then
						countdown = countdown - 1
					end
				end
				endTimer = 100 - endTimerRun
				if endTimerRun ~= 100 then
					endTimerRun = endTimerRun + 20
				else
					if finalFlashTimer > 0 then
						stay = true
						finalFlashTimer = finalFlashTimer - 1
					else
						if countdown > 0 then
							stay = false
						end
					end
				end
			else
				endTimer = endTimer - 1
			end
		end
	else
		if player.section ~= 11 then
			topC = -64
			bottomC = 600
		end
		if player.section < 6 then
			eyeBallVortex.scale = eyeBallVortex.scale - eyeBallVortex.scale
			eyeShadeVortex.scale = eyeShadeVortex.scale - eyeShadeVortex.scale
			eyePupilVortex.scale = eyePupilVortex.scale - eyePupilVortex.scale
		end
	end
	if isAgressive then
		if spawnTimer > 0 then
			spawnTimer = spawnTimer - 1
		else
			spawnTimer = 800
			soundPlay("fire")
		end
	end
	if player.section > 6 and not(cutscene) and player.section < 11 then
		isAgressive = true
	end
	if coinTimer > 0 then
		coinTimer = coinTimer - 1
	else
		if coinFrame < 3 then
			coinFrame = coinFrame + 1
		else
			coinFrame = 0
		end
		coinTimer = 8
	end
	if bananaTimer == 0 then
		if bananaFrame == 14 then
			bananaFrame = 0
		else
			bananaFrame = bananaFrame + 1
		end
		if beforeItChanges < 384 then
			bananaTimer = 6
		elseif beforeItChanges < 704 then
			bananaTimer = 4
		elseif beforeItChanges < 960 then
			bananaTimer = 2
		elseif beforeItChanges < 1200 then
			bananaTimer = 1
		else
			bananaTimer = 0
		end
		if beforeItChanges > 1470 then
			bananaY = bananaY - 6
		end
		if bananaY < 19000 then
			if oneUpTimer == 0 then
				if oneUp > 0 then
					NPC.spawn(90, player.x, camera.y - 32, player.section)
					oneUp = oneUp - 1
				end
				oneUpTimer = 32
			else
				oneUpTimer = oneUpTimer - 1
			end
		end
	else
		bananaTimer = bananaTimer - 1
	end
	if not(soundHasPlayer) and player.section == 11 and player.x < 16320 then
		SFX.play(Misc.resolveFile("banana.ogg"))
		soundHasPlayer = true
	elseif soundHasPlayer then
		beforeItChanges = beforeItChanges + 1
	end
	if player.section == 11 then
		for _,j in ipairs(NPC.get(90)) do
			j.speedX = 0
			j.x = player.x
		end
	end
end

function onDraw()
	Text.print(starCount.." / 10",19614 - camera.x, 19731 - camera.y)
	if player.section == 8 then
		pupilY = camera.y + camera.height * 0.2
	else
		pupilY = camera.y + camera.height * 0.5
	end
	if player.section == 10 then
		if not(cutscene) then
			pupilX = camera.x + camera.width * 0.2
		else
			Audio.MusicStop()
			if deathWait > 0 then
				deathWait = deathWait - 1
			else
				deathWait = 2
				if deathTurn == 1 then
					pupilX = camera.x + camera.width * 0.5 + 4
					deathTurn = 0
				else
					pupilX = camera.x + camera.width * 0.5 - 4
					deathTurn = 1
				end
			end
		end
	elseif player.section == 9 then
		pupilX = camera.x + camera.width * 0.8
	else
		pupilX = camera.x + camera.width * 0.5
	end
	if spawnTimer == 0 then
		NPC.spawn(959, pupilX - 64, pupilY - 64, player.section, false, true)
	end
	eyeBallVortex.x = pupilX
	eyeShadeVortex.x = pupilX
	eyePupilVortex.x = pupilX
	eyeBallVortex.y = pupilY
	eyeShadeVortex.y = pupilY
	eyePupilVortex.y = pupilY
	if player.section == 2 then
		vortex:draw{
			priority = -99,
			sceneCoords = true
		}
	elseif player.section == 3 then
		for i=0,8 do
			for j=0,6 do
				if i % 2 == 0 and j % 2 == 0 then
					tile1.x = i * 100
					tile1.y = j * 100
					tile1:draw{priority = -99}
				elseif i % 2 == 1 and j % 2 == 1 then
					tile2.x = i * 100
					tile2.y = j * 100
					tile2:draw{priority = -99}
				end
			end
		end
	elseif player.section > 5 then
		if not(flowerGone) and player.section < 11 then
			flowerVortex1:draw{
				priority = -99,
				sceneCoords = true
			}
			flowerVortex2:draw{
				priority = -99,
				sceneCoords = true
			}
			flowerVortex3:draw{
				priority = -99,
				sceneCoords = true
			}
		end
	end

	if player:mem(0x15E, FIELD_WORD) == 15 and player:mem(0x15C, FIELD_WORD) ~= 0 and ceroFlash == 0 then
		ceroFlash = 1
		soundPlay("trans")
		Defines.earthquake = 8
	elseif ceroFlash == 1 and flashOp > 0 then
		screenFlash(0.74, 0.93, 0.7)
	elseif ceroFlash == 1 then
		ceroFlash = 0
		flashOp = 1
	end

	if player:mem(0x15E, FIELD_WORD) == 2 and player:mem(0x15C, FIELD_WORD) ~= 0 and firstFlash == 0 then
		firstFlash = 1
		soundPlay("trans")
		Defines.earthquake = 8
	elseif firstFlash == 1 and flashOp > 0 then
		screenFlash(0.93, 0.87, 0.7)
	elseif firstFlash == 1 then
		firstFlash = 0
		flashOp = 1
	end
	
	if flowerGot and finalFlash == 0 then
		finalFlash = 1
		soundPlay("trans")
		Defines.earthquake = 8
	elseif finalFlash == 1 and flashOp > 0 then
		screenFlash(0.93, 0.7, 0.81)
	elseif finalFlash == 1 then
		finalFlash = 0
		flashOp = 1
		flowerGot = false
	end
	
	if player.section ~= 5 and player.section ~= 2 and player.section ~= 9 then
		Graphics.drawImageToSceneWP(bottomlessPit, camera.x, camera.y, -99)
	else
		Graphics.drawImageToSceneWP(warpEff, camera.x, camera.y, 0)
	end
	
	if player.section == 2 then
		Graphics.drawImageToSceneWP(warpEff2, camera.x, camera.y, 0)
	end
	
	Graphics.drawImageToSceneWP(messageIMG, camera.x + 43, camera.y + camera.height * 0.65, 0, 0, 714, 94, textOp, 20)
	
	Graphics.drawImageWP(cutsceneIMG, 0, topC, 20)
	Graphics.drawImageWP(cutsceneIMG, 0, bottomC, 20)

	if finalFlashTimer > 0 and player.section < 11 then
		eyeBallVortex:draw{
			priority = -90,
			sceneCoords = true
		}
		eyeShadeVortex:draw{
			priority = -89,
			sceneCoords = true
		}
		eyePupilVortex:draw{
			priority = -88,
			sceneCoords = true
		}
		if ((spawnTimer < 300 and spawnTimer > 275) or
		   (spawnTimer < 250 and spawnTimer > 225) or
		   (spawnTimer < 200 and spawnTimer > 175) or
		   (spawnTimer < 150 and spawnTimer > 125) or
		   (spawnTimer < 100 and spawnTimer > 90) or
		   (spawnTimer < 80 and spawnTimer > 70) or
		   (spawnTimer < 60 and spawnTimer > 50) or
		   (spawnTimer < 45 and spawnTimer > 40) or
		   (spawnTimer < 35 and spawnTimer > 30) or
		   (spawnTimer < 25 and spawnTimer > 20) or
		   (spawnTimer < 15 and spawnTimer > 10) or
		   (spawnTimer < 5 and spawnTimer > 0)) and
		   not(cutscene) then
			Graphics.drawImageToSceneWP(negativePupilIMG, pupilX - 56, pupilY - 56, -87)
		end
	else
		if natureGottaWait < 0.5 then
			if endOp < 1 then
				endOp = endOp + 0.05
			else
				natureGottaWait = -1
			end
		end
	end
	if player.section == 11 and natureGottaWait == -1 and endOp > 0 then
		endOp = endOp - 0.025
	end
	if player.section == 11 then
		Graphics.drawImageToSceneWP(bananas, 15840, bananaY, 0, bananaFrame * 327, 309, 327, 1, -26)
		Graphics.drawImageToSceneWP(starCoin, 19552, 19712, 0, coinFrame * 46, 46, 46, 1, -45)
		if flashOp < 0.0125 then
			cutscene = false
			hud(true)
		end
		if not(cutscene) then
			if topC ~= -64 then
				topC = topC - 2
				bottomC = bottomC + 2
				doNotMove = false
			end
		end
	end
end

function onEvent(eventname)
	if eventname == "end" then
		cutscene = true
		vend = true
	end
end

function onInputUpdate()
	if doNotMove then
		--The following for loop makes sure that when doNotMove is true all player input is nullified.
		for k, _ in pairs(player.keys) do
			player.keys[k] = false
		end
	end
end

function soundPlay(var)
	if var == "fire" then
		SFX.play(82)
	elseif var == "trans" then
		SFX.play(Misc.resolveFile("transition.ogg"))
		SFX.play(43)
		SFX.play(43)
	end
end

function platformShow(var)
	if var == 1 then
		if Layer.get("starP1").isHidden then
			Layer.get("starP1"):show(true)
			starCount = starCount + 1
		end
	elseif var == 2 then
		if Layer.get("starP2").isHidden then
			Layer.get("starP2"):show(true)
			starCount = starCount + 1
		end
	elseif var == 3 then
		if Layer.get("starP3").isHidden then
			Layer.get("starP3"):show(true)
			starCount = starCount + 1
		end
	elseif var == 4 then
		if Layer.get("starP4").isHidden then
			Layer.get("starP4"):show(true)
			starCount = starCount + 1
		end
	elseif var == 5 then
		if Layer.get("starP5").isHidden then
			Layer.get("starP5"):show(true)
			starCount = starCount + 1
		end
	elseif var == 6 then
		if Layer.get("starP6").isHidden then
			Layer.get("starP6"):show(true)
			starCount = starCount + 1
		end
	elseif var == 7 then
		if Layer.get("starP7").isHidden then
			Layer.get("starP7"):show(true)
			starCount = starCount + 1
		end
	elseif var == 8 then
		if Layer.get("starP8").isHidden then
			Layer.get("starP8"):show(true)
			starCount = starCount + 1
		end
	elseif var == 9 then
		if Layer.get("starP9").isHidden then
			Layer.get("starP9"):show(true)
			starCount = starCount + 1
		end
	else
		if Layer.get("starP10").isHidden then
			Layer.get("starP10"):show(true)
			starCount = starCount + 1
		end
	end
end

function screenFlash(r, g, b)
	Graphics.drawScreen{
		color = {r, g, b, flashOp},
		priority = 19
	}
	if not(stay) then
		if player.section ~= 11 then
			flashOp = flashOp - 0.025
		else
			flashOp = flashOp - 0.00625
		end
	end
end

function starCoinGet()
	for i = 1, 10 do
		if SaveData._basegame.starcoin[Level.filename()][i] ~= nil then
			if SaveData._basegame.starcoin[Level.filename()][i] > 0 then
				platformShow(i)
			end
		end
	end
end

function onLoadSection11()
	starCoinGet()
end

function onNPCKill(a, b, c)
	--The following conditional checks if the flower npc has been obtained.
	if b.id == 178 then
		flowerGot = true
		cutscene = true
		doNotMove = true
	elseif b.id == 310 then
		starCoinGet()
	end
end