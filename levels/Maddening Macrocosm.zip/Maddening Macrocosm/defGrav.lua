local defGrav = {}
 
function defGrav.onInitAPI()
    registerEvent(defGrav, "onTick")
end
 
defGrav.blockLowerA = 105
defGrav.blockLowerB = 183
defGrav.blockNormalA = 107
defGrav.blockNormalB = 1237
defGrav.blockHigherA = 106
defGrav.blockHigherB = 1115
 
function defGrav.onTick()
    for k,v in ipairs(Block.getIntersecting(player.x, player.y, player.x + player.width, player.y + player.height)) do
        if v.id == defGrav.blockLowerA or v.id == defGrav.blockLowerB then
			Defines.jumpheight = 40
			Defines.jumpheight_bounce = 40
			Defines.player_grav = 0.2
			Defines.gravity = 6
		elseif v.id == defGrav.blockNormalA or v.id == defGrav.blockNormalB then
			Defines.jumpheight = 20
			Defines.jumpheight_bounce = 20
			Defines.player_grav = 0.4
			Defines.gravity = 12
		elseif v.id == defGrav.blockHigherA or v.id == defGrav.blockHigherB then
			Defines.jumpheight = 10
			Defines.jumpheight_bounce = 10
			Defines.player_grav = 0.8
			Defines.gravity = 24
		elseif v.id == 128 then
			if player:mem(0x112, FIELD_WORD) == 4 then
				player:mem(0x112, FIELD_WORD, 2)
			end
		elseif v.id == 127 then
			if player:mem(0x112, FIELD_WORD) == 5 then
				player:mem(0x112, FIELD_WORD, 2)
			end
			if player:mem(0x158, FIELD_WORD) == 34 or player:mem(0x158, FIELD_WORD) == 169 then
				player:mem(0x158, FIELD_WORD, 9)
			end
        end
    end
end
 
return defGrav