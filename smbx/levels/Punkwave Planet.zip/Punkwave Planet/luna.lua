local sz = require("sz")
local ground = Graphics.loadImage("img_ground.png")
local rng = require("rng")
local particles = require("particles")

function onTick()
	for _,b in ipairs(BGO.get(170)) do
		for _,v in NPC.iterateIntersecting(b.x, b.y, b.x + b.width, b.y + b.height) do
			if v.id == 30 and not v.cantBeKilled then
				v:kill()
			end
		end
	end
end

function onTickEnd()
	for _,v in ipairs(NPC.get(88,player.section)) do
		if lunatime.tick() % rng.randomInt(32,64) == 0 then
			Animation.spawn(80,v.x+rng.random(0,20),v.y+rng.random(0,32))
		end
	end
end

function onDraw()
	for _,v in ipairs(Block.get({3,6,7,15,17,40,46,55,59,192,193,276,672})) do
		local data = v.data
		if data.vectable == nil then
			data.vectable = {}
		end
		if data.textable == nil then
			if v.id == 55 then
				data.textable = {(2/3),0, 1,0, (2/3),1, 1,1}
			elseif v.id == 672 then
				data.textable = {(1/3),0, (2/3),0, (1/3),1, (2/3),1}
			else
				data.textable = {0,0, (1/3),0, 0,1, (1/3),1}
			end
		end
		----Vectors
		--TopLeft
		data.vectable[1] = vector.v2((camera.x+400)-v.x,(camera.y+300)-v.y)
		--TopRight
		data.vectable[2] = vector.v2((camera.x+400)-v.x+32,(camera.y+300)-v.y)
		--BottomLeft
		data.vectable[3] = vector.v2((camera.x+400)-v.x,(camera.y+300)-v.y+32)
		--BottomRight
		data.vectable[4] = vector.v2((camera.x+400)-v.x+32,(camera.y+300)-v.y+32)
		----Drawing
		if v.x > camera.x - 64 and v.x < camera.x + 832 and v.y > camera.y - 64 and v.y < camera.y + 632 then
			--Top and Bottom
			if v.y >= camera.y + 300 then
				Graphics.glDraw{primitive=Graphics.GL_TRIANGLE_STRIP, texture=ground, sceneCoords=true, textureCoords=data.textable, priority=-96, vertexCoords={
				v.x, v.y,
				v.x+32, v.y,
				v.x+(data.vectable[1].x/32), v.y+(data.vectable[1].y/32),
				v.x+32+(data.vectable[2].x/32), v.y+(data.vectable[2].y/32)}}
			else
				Graphics.glDraw{primitive=Graphics.GL_TRIANGLE_STRIP, texture=ground, sceneCoords=true, textureCoords=data.textable, priority=-96, vertexCoords={
				v.x, v.y+32,
				v.x+32, v.y+32,
				v.x+(data.vectable[3].x/32), v.y+32+(data.vectable[3].y/32),
				v.x+32+(data.vectable[4].x/32), v.y+32+(data.vectable[4].y/32)}}
			end
			--Right and Left
			if v.x <= camera.x + 400 then
				Graphics.glDraw{primitive=Graphics.GL_TRIANGLE_STRIP, texture=ground, sceneCoords=true, textureCoords=data.textable, priority=-96, vertexCoords={
				v.x+32, v.y,
				v.x+32, v.y+32,
				v.x+32+(data.vectable[2].x/32), v.y+(data.vectable[2].y/32),
				v.x+32+(data.vectable[4].x/32), v.y+32+(data.vectable[4].y/32)}}
			else
				Graphics.glDraw{primitive=Graphics.GL_TRIANGLE_STRIP, texture=ground, sceneCoords=true, textureCoords=data.textable, priority=-96, vertexCoords={
				v.x, v.y,
				v.x, v.y+32,
				v.x+(data.vectable[1].x/32), v.y+(data.vectable[1].y/32),
				v.x+(data.vectable[3].x/32), v.y+32+(data.vectable[3].y/32)}}
			end
		end
		----Particles
		if v.id == 672 then
			if data.hurt == nil then
				data.hurt = particles.Emitter(0, 0, Misc.resolveFile("part_hurtblock.ini"))
				data.hurt:Attach(v)
			end
			data.hurt:Draw(-64)
		elseif v.id == 55 then
			if data.cube == nil then
				data.cube = particles.Emitter(0, 0, Misc.resolveFile("part_cube.ini"))
				data.cube:Attach(v)
			end
			data.cube:Draw(-96.5)
		end
	end
end

