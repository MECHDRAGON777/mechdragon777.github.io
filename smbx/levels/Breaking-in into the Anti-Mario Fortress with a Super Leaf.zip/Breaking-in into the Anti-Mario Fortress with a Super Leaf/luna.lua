local sz = require("sz")

local flightLeaf = Sprite{
	image = Graphics.loadImageResolved("npc-273.png"),
	x = 0,
	y = 0,
	align = Sprite.align.CENTER
}

function onDraw()
	flightLeaf:rotate(1)
	for _,npc in ipairs(NPC.get()) do
		if npc.id == 57 or npc.id == 273 then
			npc:mem(0xE4, FIELD_WORD, -1000)
			if npc.id == 273 then
				flightLeaf.x = npc.x + npc.width * 0.5
				flightLeaf.y = npc.y + npc.height * 0.5
				if player.powerup == PLAYER_LEAF then
					flightLeaf:draw{
						priority = -24,
						sceneCoords = true
					}
				end
			end
		end
	end
end

function onNPCKill(event, npc, harm)
	if npc.id == 273 and player.powerup == PLAYER_LEAF then
		SFX.play(6)
		player:mem(0x16E, FIELD_BOOL, true)
		player:mem(0x170, FIELD_WORD, 320)
	end
end