local npcManager = require("npcManager")

local TwoUp = {}
local npcID = NPC_ID
npcManager.registerDefines(npcID, {NPC.COLLECTIBLE})

local TwoUpSettings = {
	id = npcID,
	width = 30, 
	height = 32, 
	frames = 1,
	framestyle = 1,
	framespeed = 8,
	score = 2,
	speed = 1,
	playerblock=false,
	playerblocktop=false,
	npcblock=false,
	npcblocktop=false,
	spinjumpsafe=false,
	nowaterphysics=false,
	noblockcollision=true,
	cliffturn=false,
	nogravity = true,
	nofireball=false,
	noiceball=true,
	noyoshi=false,
	iswaternpc=false,
	iscollectablegoal=false,
	isvegetable=false,
	isvine=false,
	isbot=false,
	iswalker=false,
	grabtop = false,
	grabside = false,
	foreground=false,
	isflying=false,
	iscoin=false,
	isshoe=false,
	nohurt = false,
	jumphurt = false,
	isinteractable=true,
	iscoin=false
}
npcManager.registerDefines(npcID, {NPC.UNHITTABLE})

npcManager.setNpcSettings(TwoUpSettings)

function TwoUp.onInitAPI()
	registerEvent(TwoUp, "onNPCKill")
end

function TwoUp.onNPCKill(eventObj, v)
	if v.id == npcID then
		if mem(0x00B2C5AC, FIELD_FLOAT) > 97 then
			mem(0x00B2C5AC, FIELD_FLOAT, 99)
		else
			mem(0x00B2C5AC, FIELD_FLOAT, (mem(0x00B2C5AC, FIELD_FLOAT) + 2))
		end
	Effect.spawn(79, player.x, player.y, 12)
	Audio.playSFX(Misc.resolveFile("3up.ogg"))
	end
end

return TwoUp