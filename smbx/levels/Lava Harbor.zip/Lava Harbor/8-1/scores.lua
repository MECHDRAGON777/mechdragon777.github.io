local scores = {}

--------------------------------------------------------------------------------------------------------------------------------
--APIs used
--------------------------------------------------------------------------------------------------------------------------------
local inputs2 = API.load("inputs2");
local imagic = API.load("imagic");
local npcParse
if not isOverworld then
	npcParse = API.load("npcParse");
end
local colliders = API.load("colliders")
--------------------------------------------------------------------------------------------------------------------------------
--Variables for custimization (level)
--------------------------------------------------------------------------------------------------------------------------------
scores.HUD = default
scores.HiScore = false
scores.displayHiScore = false
scores.lifeGen = false
scores.lifeDefault = true
scores.starCoins = false
scores.starCounter = false
scores.stars = false
scores.demoCounter = false
--------------------------------------------------------------------------------------------------------------------------------
--Variables for customization (world map)
--------------------------------------------------------------------------------------------------------------------------------
scores.worldScore = true
scores.displayWorldHiScore = true
scores.worldStarCoins = true
scores.worldStarCounter = true
scores.worldDemoCounter = true
scores.worldShowFlag = true
scores.worldWindow = true
scores.displayWorldTime = true

scores.worldLevelSlots = 8
scores.worldMaxStarCoins = 3
scores.worldMaxStars = 21
scores.worldScoreDigits = 7
scores.worldDeathDigits = 4
scores.worldTimeDigits = 12
--------------------------------------------------------------------------------------------------------------------------------
--Local Variables
--------------------------------------------------------------------------------------------------------------------------------
local worldCount = 1
local maxWorldPlayed = 1
local worldNumber = 1
local TrueWinState = nil
local hasDied = false
local runTimer = true
local levelTimer = 0
local displayTime = 0

local menuInitialized = false

local mainBox = nil
local worldNameBox = nil
local MENUPOS = {}

local constantImagicObjects = {}
local levelDrawing = {}

local levelSlotHeight = 56
--------------------------------------------------------------------------------------------------------------------------------
--Variables for menues
--------------------------------------------------------------------------------------------------------------------------------
local scoreStr = tostring(SaveData["Total"])
local scoreLen = string.len(scoreStr)
local menu = 0

local MENUCOL = {MAIN  = 0x0860A8FF, 
                 LIGHT = 0x2B8CDBFF,
                 DARK  = 0x053B68FF}
--------------------------------------------------------------------------------------------------------------------------------
--Graphics Loading
--------------------------------------------------------------------------------------------------------------------------------
local tsc = Graphics.loadImage(Misc.resolveFile("transparent star coin.png"))
local sc = Graphics.loadImage(Misc.resolveFile("star coin.png"))
local menuBackDrop = Graphics.loadImage(Misc.resolveFile("menu.png"))
local si = Graphics.loadImage(Misc.resolveFile("star icon.png"))
local sih = Graphics.loadImage(Misc.resolveFile("star icon hollow.png"))
local nc = Graphics.loadImage(Misc.resolveFile("Not Clear.png"))
local c = Graphics.loadImage(Misc.resolveFile("Clear.png"))
local transparentsStar = Graphics.loadImage(Misc.resolveFile("star icon hollow.png"))
local star = Graphics.loadImage(Misc.resolveFile("star icon.png"))
local StarCoin = Graphics.loadImage(Misc.resolveFile("Star Coin (2).png"))

local roundBoxImg   = Graphics.loadImage(Misc.resolveFile("scores/rndBox.png"))
local messageBoxImg = Graphics.loadImage(Misc.resolveFile("scores/msgBox.png"))

local starImg       = Graphics.loadImage(Misc.resolveFile("scores/star.png"))
local noStarImg     = Graphics.loadImage(Misc.resolveFile("scores/noStar.png"))
local coinImg       = Graphics.loadImage(Misc.resolveFile("scores/coin.png"))
local noCoinImg     = Graphics.loadImage(Misc.resolveFile("scores/noCoin.png"))
local crownImg      = Graphics.loadImage(Misc.resolveFile("scores/crown.png"))
local deathImg      = Graphics.loadImage(Misc.resolveFile("scores/death.png"))
local clockImg      = Graphics.loadImage(Misc.resolveFile("scores/clock.png"))
local flagImg       = Graphics.loadImage(Misc.resolveFile("scores/flag.png"))
local leftImg       = Graphics.loadImage(Misc.resolveFile("scores/leftArrow.png"))
local noLeftImg     = Graphics.loadImage(Misc.resolveFile("scores/noLeftArrow.png"))
local rightImg      = Graphics.loadImage(Misc.resolveFile("scores/rightArrow.png"))
local noRightImg    = Graphics.loadImage(Misc.resolveFile("scores/noRightArrow.png"))
--------------------------------------------------------------------------------------------------------------------------------
--Tables
--------------------------------------------------------------------------------------------------------------------------------
local scoreMap = {}

if scores.lifeDefault then
scoreMap[10000]=1
scoreMap[20000]=1
scoreMap[40000]=1
scoreMap[80000]=2
scoreMap[120000]=2
scoreMap[200000]=3
scoreMap[300000]=3
scoreMap[400000]=4
scoreMap[500000]=4
scoreMap[750000]=5
scoreMap[1000000]=5
scoreMap[2000000]=5
scoreMap[3000000]=5
scoreMap[4000000]=5
scoreMap[5000000]=5
scoreMap[6000000]=6
scoreMap[7000000]=7
scoreMap[8000000]=8
scoreMap[9000000]=9
scoreMap[9999990]=10
end

scores.worlds = {}

scores.levelData = {}

local gotStarCoin = {0, 0, 0}
local gotStar = {0, 0, 0}

local shells = {5, 7, 24, 73, 113, 114, 115, 116, 172, 174, 195}

local scoins = {274, 310}
--------------------------------------------------------------------------------------------------------------------------------
--Utility Functions
--------------------------------------------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------------------------------------------
--Event Handerlers
--------------------------------------------------------------------------------------------------------------------------------
function scores.onInitAPI()
	registerEvent(scores, "onStart", "onStart", true);
	registerEvent(scores, "onHUDDraw", "onHUDDraw", true);
	registerEvent(scores, "onTick", "onTick", true);
	registerEvent(scores, "onTickEnd", "onTickEnd", true);
	registerEvent(scores, "onDraw", "onDraw", true);
	registerEvent(scores, "onInputUpdate", "onInputUpdate", true);
	registerEvent(scores, "onExitLevel", "onExitLevel", false);
	registerEvent(scores, "onNPCKill", "onNPCKill", true)
	
end

function scores.onStart()
    if isOverworld then
		menu = 0
		for worldNumber, world in ipairs(scores.worlds) do
			for _, filename in ipairs(world.levels) do
				if SaveData[filename .. " Played"] == true then
					maxWorldPlayed  = worldNumber
				end
			end
		end
	else
	SaveData[Level.filename() .. " Played"] = true
		if SaveData[Level.filename() .. "HiScore"] == nil then
			SaveData[Level.filename() .. "HiScore"] = 0
		end
		if scores.HiScore == true then
			SaveData._basegame.hud.score = 0
		end
		if SaveData["totalDeaths"] == nil then
			SaveData["totalDeaths"] = 0
		end
		if SaveData[Level.filename() .. "-deaths"] == nil then
			SaveData[Level.filename() .. "-deaths"] = 0
		end
		SaveData[Level.filename() .. " Played"] = 1
		--[[local c = NPC.get(192)[1];
		if(player.x > c.x - 32 and player.x < c.x + c.width + 32 and player.y < c.y -32 and player.y > c.y+c.height+128) then
			runTimer = false
			local levelTimer = 23076923
		end]]
	end
	initMenu()
end

function scores.onHUDDraw()
	if scores.demoCounter then
		Text.print("DEMOS", 100, 25)
		Text.print(tostring(SaveData[Level.filename() .. "-deaths"]) .. " / " .. tostring(SaveData["totalDeaths"]), 3, 100, 45)
	end
end

function scores.onInputUpdate()
	if isOverworld then
		if inputs2.state[1].dropitem == inputs2.PRESS and menu <= 0 then
			menu = 1
			inputs2.locked[1].jump = true
			inputs2.locked[1].left = true
			inputs2.locked[1].right = true
			inputs2.locked[1].up = true
			inputs2.locked[1].down = true
		elseif inputs2.state[1].dropitem == inputs2.PRESS and menu >= 1 then
			menu = 0
			inputs2.locked[1].jump = false
			inputs2.locked[1].left = false
			inputs2.locked[1].right = false
			inputs2.locked[1].up = false
			inputs2.locked[1].down = false
		end
		if menu == 1 and maxWorldPlayed > 1 and inputs2.state[1].left == inputs2.PRESS then 
			menu = maxWorldPlayed
			player.leftKeyPressing = false
		elseif menu == maxWorldPlayed and inputs2.state[1].right == inputs2.PRESS then
			menu = 1
			player.rightKeyPressing = false
		elseif menu >=1 and maxWorldPlayed ~= 1 and inputs2.state[1].right == inputs2.PRESS then
			menu = menu + 1
			player.rightKeyPressing = false
		elseif menu <= maxWorldPlayed and menu ~= 1 and maxWorldPlayed ~= 1 and menu > 0 and inputs2.state[1].left == inputs2.PRESS then
			menu = menu - 1
			player.leftKeyPressing = false
		end
	end
end

function scores.onDraw()
    if isOverworld then
        if menu >= 1 then
            DisplayWorldProgress(menu)
        end
    else
        if Defines.player_hasCheated or hasDied then
			levelTimer = 23076923
		end
		if runTimer == true and (Level.winState() == 0 or Level.winState() == nil) then
			levelTimer = levelTimer + 1
		elseif Level.winState() > 0 then
			if SaveData[Level.filename() .. "Time"] == nil then
				SaveData[Level.filename() .. "Time"] = levelTimer
			elseif SaveData[Level.filename() .. "Time"] ~= nil then
				if levelTimer < SaveData[Level.filename() .. "Time"] then
					SaveData[Level.filename() .. "Time"] = levelTimer
				end
			end
		end
		if scores.starCoins then
			if SaveData["HUD Type"]  == "A" then
				for i=1,3 do
					Graphics.drawImageWP(tsc , (394 + (26 * i)), 20, 4.99)
				end
				for i=1,3 do
					if gotStarCoin[i] == 1 then
						Graphics.drawImageWP(sc , (394 + (26 * id)), 20, 5)
					end
				end
			elseif SaveData["HUD Type"] == "B" then
				for id=1,3 do
					if SaveData._basegame.starcoin[Level.filename()] ~= nil then
						if SaveData._basegame.starcoin[Level.filename()][id] == 1 or SaveData._basegame.starcoin[Level.filename()][id] == 2 or 	SaveData._basegame.starcoin[Level.filename()][id] == 3 then
							Graphics.drawImageWP(StarCoin , (456 + (18 * id)), 20, 5)
						end
					end
				end
			end
		end
		if scores.stars then
			for i=1,scores.levelStarCount do
				Graphics.drawImageWP(transparentsStar , (586 + (26 * i)), 48, 4.99)
			end
			for i=1,3 do
				if gotStar[i] == 1 then
					Graphics.drawImageWP(star , (586 + (26 * i)), 48, 5)
				end
			end
		end
		--[[if player:mem(0x122,FIELD_WORLD) == 3 then
			for k,v in ipairs(Warp.getIntersectingEntrance(player.x,player.y,player.x+player.width,player.y+player.height)) do
				if v:mem(0x84, FIELD_WORD) == 1 then
					runTimer = false
					if levelTimer < score:get(level.filename .. "Time") then
						score:set(level.filename .. "Time", levelTimer)
					end
					score:save()
				end
			end
		end]]
    end
end

function scores.onTick()
	if isOverworld then
		if scores.worldScore == true then
			if Player.count() == 1 then
				if SaveData["Total"] == nil then
					Text.printWP("0", 1, 191 - 0 * 18, 46, 10)
				else
					if scoreLen < 3 then
						Text.printWP(scoreStr, 3, 191 - (scoreLen - 1) * 18, 46, 5)
					elseif scoreLen > 2 then
						Text.printWP(scoreStr, 3, 191 - (scoreLen - 2) * 18, 46, 5)
					end
				end
			else
				if SaveData["Total"] == nil then
					Text.printWP("0", 238 - 0 * 18, 46, 10)
				else
					if scoreLen < 3 then
						Text.printWP(scoreStr, 3, 238 - (scoreLen - 1) * 18, 46, 5)
					elseif scoreLen > 2 then
						Text.printWP(scoreStr, 3, 238 - (scoreLen - 2) * 18, 46, 5)
					end
				end
			end
		end
	else
	--updateCollectibleIDs()
    local foo,_,bar = colliders.collideNPC(shells,scoins)
    if foo then
        for _,v in ipairs(bar) do
            if math.abs(v[1].speedX) > 5 then
                v[2]:kill(9)
                Audio.playSFX(Misc.resolveFile("dragon-coin.ogg"))
				mem(0x00B2C5A8,FIELD_WORD, (mem(0x00B2C5A8,FIELD_WORD) + 1))
				if SaveData._basegame.starcoin[Level.filename()][v[2].ai2] == 0 then
					SaveData._basegame.starcoin[Level.filename()][v[2].ai2] = 3
				end
				while mem(0x00B2C5A8,FIELD_WORD) >= 100 do
					mem(0x00B2C5A8,FIELD_WORD, (mem(0x00B2C5A8,FIELD_WORD) - 100))
					mem(0x00B2C5AC,FIELD_FLOAT, math.min(99,mem(0x00B2C5AC,FIELD_FLOAT) + 1))
					Audio.playSFX(Misc.resolveFile("1-up.ogg"))
				end
            end
        end
    end
	local newScore = SaveData._basegame.hud.score
		if SaveData["Total"] == nil then
			SaveData["Total"] = 0
		end
		if SaveData._basegame.hud.score > SaveData[Level.filename() .. "HiScore"] then
			if scores.lifeGen == true then
				for scoreThreshold, value in pairs(scoreMap) do
					if (scoreThreshold > SaveData[Level.filename() .. "HiScore"]) and (scoreThreshold <= SaveData._basegame.hud.score) then
						mem(0x00B2C5AC,FIELD_FLOAT, (mem(0x00B2C5AC,FIELD_FLOAT) + value))
						Audio.playSFX(Misc.resolveFile("1up.ogg"))
					end
				end
			end
			SaveData[Level.filename() .. "HiScore"] = SaveData._basegame.hud.score
		end
		if SaveData[Level.filename() .. "HiScore"] > 9999990 then
			SaveData[Level.filename() .. "HiScore"] = 9999990
		end
		if scores.displayHiScore == true then
			if scores.HUD == default then
				if Player.count() == 1 then
					Text.printWP("/" .. (SaveData[Level.filename() .. "HiScore"]), 3, 572, 47, 6)
				elseif Player.count() == 2 then
					Text.printWP("/" .. (SaveData[Level.filename() .. "HiScore"]), 3, 612, 47, 6)
				end
			end
		end

		if player:mem(0x13C, FIELD_DWORD) ~= 0 and not hasDied then
			SaveData[Level.filename() .. "-deaths"] = SaveData[Level.filename() .. "-deaths"] + 1
			SaveData["totalDeaths"] = SaveData["totalDeaths"] + 1
			hasDied = true
		end
	end
	if SaveData["extendedLives"] ~= nil then
		if mem(0x00B2C5AC,FIELD_FLOAT) > 94 and SaveData["extendedLives"] <= 899 then
			mem(0x00B2C5AC,FIELD_FLOAT, mem(0x00B2C5AC,FIELD_FLOAT) - 1)
			SaveData["extendedLives"] = SaveData["extendedLives"] + 1
		end
		if SaveData["extendedLives"] > 0 and hasDied == false and player:mem(0x13C, FIELD_DWORD) ~= 0 then
			mem(0x00B2C5AC,FIELD_FLOAT, 98)
			SaveData["extendedLives"] = SaveData["extendedLives"] - 1
		end
	end
end

function scores.onNPCKill(eventObj, killedNPC, killReason)
	if (killReason == 9) and (killedNPC.id == 192) or (killedNPC.id == 400) then
		if levelTimer < 5 then 
			levelTimer = 23076923
			runTimer = false
		end
	end
end

function scores.onTickEnd()
	if not isOverworld then
		TrueWinState = Level.winState()
	end
end

function scores.onExitLevel()
    if isOverworld then
	else
		if Level.winState() > 0 or player:mem(0x13C, FIELD_DWORD) == 0 then
			SaveData[Level.filename() .. " Beat"] = true
			if SaveData[Level.filename() .. "Time"] == nil and player:mem(0x13C, FIELD_DWORD) ~= 0 then
				SaveData[Level.filename() .. "Time"] = levelTimer
			elseif SaveData[Level.filename() .. "Time"] ~= nil and player:mem(0x13C, FIELD_DWORD) ~= 0 then
				if levelTimer < SaveData[Level.filename() .. "Time"] then
					SaveData[Level.filename() .. "Time"] = levelTimer
				end
			end
		end
		if SaveData[Level.filename() .. "Time"] == nil then
			SaveData[Level.filename() .. "Time"] = levelTimer
		elseif SaveData[Level.filename() .. "Time"] ~= nil then
			if levelTimer < SaveData[Level.filename() .. "Time"] then
				SaveData[Level.filename() .. "Time"] = levelTimer
			end
		end
		SaveData["Total"] = (SaveData._basegame.hud.score + SaveData["Total"])
		if Level.winState() == 6 then
			SaveData[Level.filename() .. "Star " .. tostring(1)] = true
		end
	end
end
--------------------------------------------------------------------------------------------------------------------------------
--Functions
--------------------------------------------------------------------------------------------------------------------------------
local function formatTime(t)
	realMiliseconds = math.floor(t*15.6);
	miliseconds = realMiliseconds%1000;
	realSeconds = math.floor(realMiliseconds/1000);
	seconds = realSeconds%60;
	realMinutes = math.floor(realSeconds/60);
	minutes = realMinutes%60;
	hours = math.floor(realMinutes/60);

	if hours < 10 then
		hours = "0"..tostring(hours);
	end

	if minutes < 10 then
		minutes = "0"..tostring(minutes);
	end

	if seconds < 10 then
		seconds = "0"..tostring(seconds);
	end

	if miliseconds < 10 then
		miliseconds = "00"..tostring(miliseconds);
	elseif miliseconds < 100 then
		miliseconds = "0"..tostring(miliseconds);
	end
	displayTime = tostring(tostring(hours) .. ":" .. tostring(minutes) .. ":" .. tostring(seconds) .. "." .. tostring(miliseconds))
	return displayTime
end

function initMenu()
	-- Determine the size, scale and reference points based on the enabled elements
	MENUPOS = {X=400,Y=300, W=0, H=48+scores.worldLevelSlots*levelSlotHeight}

	coinsWidth,starsWidth,scoreWidth,deathsWidth = 0,0,0,0

	if  scores.worldStarCoins        then  coinsWidth  = 6  + 18*scores.worldMaxStarCoins;    end;
	if  scores.worldStarCounter      then  starsWidth  = 6  + 18*scores.worldMaxStars;        end;
	if  scores.displayWorldHiScore   then  scoreWidth  = 24 + 18*scores.worldScoreDigits;     end;
	if  scores.worldDemoCounter      then  deathsWidth = 24 + 18*scores.worldDeathDigits;     end;
	if  scores.displayWorldTime      then  timeWidth   = 28 + 18*scores.worldTimeDigits;      end;
	
	MENUPOS.W = MENUPOS.W + 48 + coinsWidth + starsWidth + scoreWidth + deathsWidth + timeWidth;

	MENUPOS.LEFT   = MENUPOS.X - 0.5*MENUPOS.W
	MENUPOS.RIGHT  = MENUPOS.X + 0.5*MENUPOS.W
	MENUPOS.TOP    = MENUPOS.Y - 0.5*MENUPOS.H
	MENUPOS.BOTTOM = MENUPOS.Y + 0.5*MENUPOS.H
	MENUPOS.INW    = MENUPOS.W - 24

	-- Main window
	if  scores.worldWindow  then
		mainBox    = imagic.Box{x=400, y=300, z=9,
		                        width=MENUPOS.W, height=MENUPOS.H, align=imagic.ALIGN_CENTER,
		                        color=MENUCOL.MAIN, bordertexture=messageBoxImg, bordercolor=0xFFFFFFFF, borderwidth=4}
	else
		mainBox    = imagic.Box{x=400, y=300, z=9,
		                        width=900, height=700, align=imagic.ALIGN_CENTER,
		                        color=MENUCOL.MAIN, bordertexture=messageBoxImg, bordercolor=0xFFFFFFFF, borderwidth=4}
	end

	-- World name
	worldNameBox = imagic.Box{x=400, y=MENUPOS.TOP+18, z=mainBox.z+1,
                              width=MENUPOS.INW-64, height=20, align=imagic.ALIGN_CENTER,
                              color=MENUCOL.DARK, bordertexture=roundBoxImg,   bordercolor=MENUCOL.DARK, borderwidth=4}


	-- Loop through and create the imagic boxes for each level slot
	for i=1,scores.worldLevelSlots do
		local topPos  = MENUPOS.TOP + 48 + levelSlotHeight*(i-1)
		local leftPos = MENUPOS.LEFT + 12

		levelDrawing[i] = {}

		levelDrawing[i].top = topPos
		levelDrawing[i].left = leftPos
		levelDrawing[i].coinX = leftPos
		levelDrawing[i].starX = leftPos
		levelDrawing[i].scoreX = leftPos
		levelDrawing[i].deathX = leftPos
		levelDrawing[i].timeX = leftPos

		-- Coin slot panel
		if  scores.worldStarCoins  then
			levelDrawing[i].coinBox = imagic.Box{x=leftPos, y=topPos+18, z=10, 
			                                     width=coinsWidth, height=20, align=imagic.ALIGN_TOPLEFT,
			                                     color=MENUCOL.LIGHT, bordertexture=roundBoxImg,  bordercolor=MENUCOL.LIGHT, borderwidth=4}
			leftPos = leftPos + coinsWidth + 8
			levelDrawing[i].starX  = leftPos
			levelDrawing[i].scoreX = leftPos
			levelDrawing[i].deathX = leftPos
			levelDrawing[i].timeX = leftPos
		end

		-- Star slot panel
		if  scores.worldStarCounter  then
			levelDrawing[i].starBox = imagic.Box{x=leftPos, y=topPos+18, z=10, 
                                                 width=starsWidth, height=20, align=imagic.ALIGN_TOPLEFT,
                                                 color=MENUCOL.LIGHT, bordertexture=roundBoxImg,  bordercolor=MENUCOL.LIGHT, borderwidth=4}
			leftPos = leftPos + starsWidth + 8
			levelDrawing[i].scoreX = leftPos
			levelDrawing[i].deathX = leftPos
			levelDrawing[i].timeX = leftPos
		end

		-- Score panel
		if  scores.displayWorldHiScore  then
			levelDrawing[i].scoreBox = imagic.Box{x=leftPos, y=topPos+18, z=10, 
                                                  width=scoreWidth, height=20, align=imagic.ALIGN_TOPLEFT,
                                                  color=MENUCOL.LIGHT, bordertexture=roundBoxImg,  bordercolor=MENUCOL.LIGHT, borderwidth=4}
			leftPos = leftPos + scoreWidth + 8
			levelDrawing[i].deathX = leftPos
			levelDrawing[i].timeX = leftPos
		end

		-- Deaths panel
		if  scores.worldDemoCounter  then
			levelDrawing[i].deathBox = imagic.Box{x=leftPos, y=topPos+18, z=10, 
                                                  width=deathsWidth, height=20, align=imagic.ALIGN_TOPLEFT,
                                                  color=MENUCOL.LIGHT, bordertexture=roundBoxImg,  bordercolor=MENUCOL.LIGHT, borderwidth=4}
			leftPos = leftPos + deathsWidth + 8
			levelDrawing[i].timeX = leftPos
		end
		
		-- Time panel
		if  scores.displayWorldTime  then
			levelDrawing[i].timeBox = imagic.Box{x=leftPos, y=topPos+18, z=10, 
                                                  width=timeWidth, height=20, align=imagic.ALIGN_TOPLEFT,
                                                  color=MENUCOL.LIGHT, bordertexture=roundBoxImg,  bordercolor=MENUCOL.LIGHT, borderwidth=4}
			leftPos = leftPos + timeWidth + 8
		end
	end

	constantImagicObjects = {mainBox, worldNameBox}

	menuInitialized = true
end


function DisplayWorldProgress(worldNumber)
	if  not menuInitialized  then  return;  end;

	-- Determine level name cutoff point
	local levelNameSpace = MENUPOS.W - 64
	if  scores.worldShowFlag  then  levelNameSpace = levelNameSpace-64;  end;
	local levelNameChars = math.floor(levelNameSpace/18)

	-- Draw the constant imagic objects
	for k,v in pairs(constantImagicObjects)  do
		v:Draw{z=v.z, color=v.color, bordercolor=v.bordercolor}
	end

	-- Determine world name cutoff point
	local worldNameSpace = MENUPOS.INW - 68
	local worldNameChars = math.floor(worldNameSpace/18) - 9

	-- World name
	local worldNameStr = ""
	local fullWorldStr = "W"..tostring(worldNumber)

	if  MENUPOS.W > 200  then
		fullWorldStr = "WORLD "..tostring(worldNumber)
	end
	if  MENUPOS.W > 300  then
		worldNameStr = scores.worlds[worldNumber].name  or  "Unnamed World"
		if  worldNameChars < worldNameStr:len()  then
			worldNameStr = string.sub(worldNameStr, 1, worldNameChars-3) .. "..."
		end
		fullWorldStr = fullWorldStr..": "..worldNameStr
	end
	Graphics.draw {type=RTYPE_TEXT, text=fullWorldStr, fontType=4, x=MENUPOS.LEFT+52, y=MENUPOS.TOP+10, priority=11}

	-- World arrows
	if  worldNumber > 1  then
		Graphics.draw {type=RTYPE_IMAGE, image=leftImg, x=MENUPOS.LEFT+14, y=MENUPOS.TOP+10, priority=11}
	else
		Graphics.draw {type=RTYPE_IMAGE, image=noLeftImg, x=MENUPOS.LEFT+14, y=MENUPOS.TOP+10, priority=11}
	end

	if  worldNumber < maxWorldPlayed  then
		Graphics.draw {type=RTYPE_IMAGE, image=rightImg, x=MENUPOS.RIGHT-32, y=MENUPOS.TOP+10, priority=11}
	else
		Graphics.draw {type=RTYPE_IMAGE, image=noRightImg, x=MENUPOS.RIGHT-32, y=MENUPOS.TOP+10, priority=11}
	end


	for levelNum,filename in pairs(scores.worlds[worldNumber].levels)  do

		local k,v = levelNum,levelDrawing[levelNum]

		-- Draw the boxes
		if  type(v) == "table"  then
			for  k2,v2 in pairs(levelDrawing[k])  do
				if  type(v2) == "table"  then
					v2:Draw{z=v2.z, color=v2.color, bordercolor=v2.bordercolor}
				end
			end
		end

		-- Draw the level name text
		if  MENUPOS.W > 300  then
			local levelNameStr = "???"
			if SaveData[filename .. " Played"] == true then
				levelNameStr = scores.levelData[filename].name
			end
			if  levelNameChars <= levelNameStr:len()  then
				levelNameStr = string.sub(levelNameStr, 1, levelNameChars-3) .. "..."
			end
			Graphics.draw {type=RTYPE_TEXT, text=levelNameStr, fontType=4, x=v.left, y=v.top, priority=11}
		end

		-- Draw the flag graphic
		if  scores.worldShowFlag  and  SaveData[filename .. " Beat"] == true  then
			Graphics.draw {type=RTYPE_IMAGE, image=flagImg, x=MENUPOS.RIGHT-28, y=v.top, priority=11}
		end

		-- Draw the coin graphics
		--[[if  scores.worldStarCoins  then
			local numCoinsInLevel = scores.levelData[filename].starcoins  or  0
			for i=1,numCoinsInLevel  do
				if  SaveData._basegame.starcoin[Level.fileame][i]  then
					Graphics.draw {type=RTYPE_IMAGE, image=coinImg, x=v.coinX + 4 + 18*(i-1), y=v.top+20, priority=11}
				else
					Graphics.draw {type=RTYPE_IMAGE, image=noCoinImg, x=v.coinX + 4 + 18*(i-1), y=v.top+20, priority=11}
				end
			end
		end]]

		-- Draw the star graphics
		if  scores.worldStarCounter  then
			for i=1,scores.levelData[filename].stars  do
				if  SaveData[filename .. "Star " .. tostring(i)]  then
					Graphics.draw {type=RTYPE_IMAGE, image=starImg, x=v.starX + 4 + 18*(i-1), y=v.top+20, priority=11}
				else
					Graphics.draw {type=RTYPE_IMAGE, image=noStarImg, x=v.starX + 4 + 18*(i-1), y=v.top+20, priority=11}
				end
			end
		end

		-- Draw the crown and score text
		if  scores.displayWorldHiScore  then
			local scoreVal = SaveData[filename .. "HiScore"]  or  0
			Graphics.draw {type=RTYPE_IMAGE, image=crownImg, x=v.scoreX+4, y=v.top+20, priority=11}
			Graphics.draw {type=RTYPE_TEXT, text=string.format("%"..tostring(scores.worldScoreDigits).."d", scoreVal), fontType=4, x=v.scoreX+24, y=v.top+20, priority=11}
		end

		-- Draw the death icon and text
		if  scores.worldDemoCounter  then
			local deathsVal = SaveData[filename .. "-deaths"]  or  0
			Graphics.draw {type=RTYPE_IMAGE, image=deathImg, x=v.deathX+4, y=v.top+20, priority=11}
			Graphics.draw {type=RTYPE_TEXT, text=string.format("%"..tostring(scores.worldDeathDigits).."d", deathsVal), fontType=4, x=v.deathX+24, y=v.top+20, priority=11}
		end
		
		-- Draw the clock and time text
		if  scores.displayWorldTime  then
			local timeVal = SaveData[filename .. "Time"]  or  23076923
			Graphics.draw {type=RTYPE_IMAGE, image=clockImg, x=v.timeX+4, y=v.top+20, priority=11}
			Graphics.draw {type=RTYPE_TEXT, text=tostring(formatTime(timeVal)), fontType=4, x=v.timeX+24, y=v.top+20, priority=11}
		end
	end
end


function DisplayWorldProgressOld(worldNumber)
	Graphics.drawImageWP(menuBackDrop, 0, 0, 5.1)
	for levelNum,filename in ipairs(scores.worlds[worldNumber]) do
        local data = scores.levelData[filename]
        local sct = {}
		for i = 1,3 do
			sct[i] = SaveData[filename .. "Star Coin " .. tostring(i)]
		end
		local st = {}
		if scores.levelData[filename].stars >= 1 then
			for i = 1,scores.levelData[filename].stars do
				st[i] = SaveData[filename .. "Star " .. tostring(i)]
			end
		end
		if SaveData[filename .. " Played"] == 1 then
			Graphics.drawImageWP(nc, 612, (0 + 66 * levelNum), 5.11)
			if SaveData[filename .. " Beat"] == 1 then
				Graphics.drawImageWP(c, 612, (0 + 66 * levelNum), 5.2)
			end
			Text.printWP("World " .. worldNumber, 42, 22, 5.11)
			Text.printWP(string.sub(scores.levelData[filename].name, 1, 40), 42, (-28 + 70 * levelNum), 5.2)
			if scores.displayWorldHiScore then
				if SaveData[filename .. "HiScore"] == nil then
					Text.printWP(string.format("%07d", 0), 632, (-2 + 66 * levelNum), 5.2)
				else
					Text.printWP(string.format("%07d", SaveData[filename .. "HiScore"]), 632, (-2 + 66 * levelNum), 5.2)
				end
			end
			if scores.worldStarCoins == true then
				Graphics.drawImageWP(tsc, 42, (-8 + 68 * levelNum), 5.11)
				Graphics.drawImageWP(tsc, 68, (-8 + 68 * levelNum), 5.11)
				Graphics.drawImageWP(tsc, 94, (-8 + 68 * levelNum), 5.11)
				for i=1,3 do
					if sct[i] then
						Graphics.drawImageWP(sc, 42 + (i-1) * 26, (-8 + 68 * levelNum), 5.2)
					end
				end
				if scores.worldStarCounter == true then
					if scores.levelData[filename].stars >= 1 then
						for i=1,scores.levelData[filename].stars do
							Graphics.drawImageWP(sih, 42 + (i-1) * 26, (18 + 68 * levelNum), 5.11)
							if st[i] then
								Graphics.drawImageWP(si, 42 + (i-1) * 26, (18 + 68 * levelNum), 5.2)
							end
						end
					end
				end
			end
		end
    end
end

return scores