local PeachSpin = {} --Package table

local myTailSound = Audio.SfxOpen(Misc.resolveFile("tail.ogg"))

function PeachSpin.onInitAPI() --Is called when the api is loaded by loadAPI.
	registerEvent(PeachSpin, "onInputUpdate", "onInputUpdate", true);
end

function PeachSpin.onInputUpdate()
	if player.altJumpKeyPressing == true and player.character == CHARACTER_PEACH and player:isGroundTouching() then
		player:mem(0x50, FIELD_WORD, -1)
		Audio.sounds[1].sfx = myTailSound
	end
	if player.jumpKeyPressing == true then
		Audio.sounds[1].sfx = nil
	end
end

return PeachSpin --Return the package when the api is getting loaded.