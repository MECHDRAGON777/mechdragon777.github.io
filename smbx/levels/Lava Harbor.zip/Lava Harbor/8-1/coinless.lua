-- api table --
local coinless = {}



-- locals for speed --
local Mem = mem
local coins = SaveData.GlobalCoins + 0

local BLUE_COIN_ID = 258 -- coins --
local SMB2_COIN_ID = 138
local SMB1_COIN_ID = 88
local SMW_COIN_ID = 33
local COIN_ID = 10
local RED_COIN_ID = 103
local COIN_ID_TABLE = {BLUE_COIN_ID,SMB2_COIN_ID,SMB1_COIN_ID,SMW_COIN_ID,RED_COIN_ID,COIN_ID} -- for coins --



-- register event(s) --
function coinless.onInitAPI()
    registerEvent(coinless, "onTick")
end



-- to execute every frame --
function coinless.onTick()
    if SaveData.GlobalCoins ~= coins then
        player:kill()
    end
end





-- and presto its kirb --
return coinless