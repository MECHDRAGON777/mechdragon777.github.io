Player.setCostume(CHARACTER_TOAD, "toadette")
local pm = require("playerManager")
local scores = require("scores")
if Level.filename() ~= 'intro.lvl' and SaveData["Mode"] == 4 then
	_G["animclock"] = require("animclock")
end
if Level.filename() ~= 'intro.lvl' and SaveData["Mode"] == 5 then
	_G["coinlessScript"] = require("coinless")
end
scores.starCoins = true
scores.StarCounter = true
scores.HiScore = true
scores.displayHiScore = false
scores.demoCounter = false


-- local functions for speed --
local toString = tostring
local toNumber = tonumber
local mathfloor = math.floor
local loadImage = Graphics.loadImage



-- for time management --
local t = 0                                     -- number of ticks elapsed
local realMiliseconds, realSeconds, realMinutes -- time elapsed in real life
local miliseconds, seconds, minutes, hours      -- game time

local peachspin = require("peachspin")
local nsmbwalls = require("nsmbwalls")
local wahMoves = require("wahMoves")
--[[local walljumps = API.load("walljumps")
walljumps.delayTime = 0.15
walljumps.slideSpeed = 2.5
walljumps.jumpIntensityX = 5.6
walljumps.jumpIntensityY = -10.1
]]
local displayTime = 0
--local phoenixSuit = API.load("phoenixSuit")
--phoenixSuit.randomGen(false)
local hasDied = false
local t = 0
local coinT = 0

local HUD = loadImage(Misc.resolveFile("HUD/Level.png"))
local heartNul = loadImage(Misc.resolveFile("HUD/HUD 2/emptySlot.png"))
local heart = loadImage(Misc.resolveFile("HUD/HUD 2/heart.png"))
local Clock = loadImage(Misc.resolveFile("HUD/Clock.png"))
local Crown = loadImage(Misc.resolveFile("HUD/Crown.png"))
local Skull = loadImage(Misc.resolveFile("HUD/death.png"))
local sMushroom = loadImage(Misc.resolveFile("HUD/HUD 2/Mushroom.png"))
local sFireFlower = loadImage(Misc.resolveFile("HUD/HUD 2/Fire Flower.png"))
local sLeaf = loadImage(Misc.resolveFile("HUD/HUD 2/Leaf.png"))
local sTanookie = loadImage(Misc.resolveFile("HUD/HUD 2/Tanooki Suit.png"))
local sHammer = loadImage(Misc.resolveFile("HUD/HUD 2/Hammer Suit.png"))
local sIce = loadImage(Misc.resolveFile("HUD/HUD 2/Ice Flower.png"))
local sPhoenix = loadImage(Misc.resolveFile("HUD/HUD 2/Phoenix.png"))

local HUD2 = loadImage(Misc.resolveFile("HUD/HUD 2/HUD 1P.png"))
local reserveBox = loadImage(Misc.resolveFile("HUD/HUD 2/HUD 1P Reserve.png"))
local Skull2 = loadImage(Misc.resolveFile("HUD/HUD 2/HUD 1P Deaths.png"))
local StarCoinTracker = loadImage(Misc.resolveFile("HUD/HUD 2/Star Coin Base.png"))
local coinlessMedal = loadImage(Misc.resolveFile("HUD/HUD 2/Coinless.png"))
local lunaMedal = loadImage(Misc.resolveFile("HUD/HUD 2/Luna.png"))
local DifficultyIcon
local coinless = true
local int = false
local LCC = mem(0x00B2C5A8,FIELD_WORD)
SaveData.Coins = SaveData.Coins or 0
SaveData["SpentCoins"] = SaveData["SpentCoins"] or 0
SaveData["GlobalCoins"] = SaveData["GlobalCoins"] or 0
local textplus = require('textplus')
local B7Sfont = textplus.loadFont("HUD/6.ini")



local playerLiveDisplay
if player.character == CHARACTER_MARIO then
	playerLiveDisplay = loadImage(Misc.resolveFile("HUD/MarioL.png"))
elseif player.character == CHARACTER_LUIGI then
	playerLiveDisplay = loadImage(Misc.resolveFile("HUD/LuigiL.png"))
elseif player.character == CHARACTER_PEACH then
	playerLiveDisplay = loadImage(Misc.resolveFile("HUD/PeachL.png"))
elseif player.character == CHARACTER_TOAD then
	playerLiveDisplay = loadImage(Misc.resolveFile("HUD/ToadL.png"))
elseif player.character == CHARACTER_KLONOA or player.character == CHARACTER_LINK then
	playerLiveDisplay = loadImage(Misc.resolveFile("HUD/KlonoaL.png"))
end
function rumble()
	Audio.playSFX(Misc.resolveFile("water.ogg"))
	for i=1, 150 do
		Defines.earthquake = 2
		Routine.waitFrames(1)
	end
end
local timer1 = 0
local timer2 = 0
local waittime1 = false
local waittime2 = false

function onStart()
	pm.setCostume(CHARACTER_KLONOA, "SMW2-Yoshi")
	pm.setCostume(1, "Modern")
	pm.setCostume(3, "Modern")
	if player.character == CHARACTER_LINK then
		player.character = CHARACTER_KLONOA
	end
	if SaveData["HUD Type"] ~= "A" or SaveData["HUD Type"] ~= "B" then
		SaveData["HUD Type"] = "B"
	end
	if SaveData["GlobalTime"] == nil then
		SaveData["GlobalTime"] = 0
	end
	if Level.filename() == 'intro.lvl' then
	elseif Level.filename() ~= 'intro.lvl' then
		if SaveData["Difficulty"] == 1 then
			DifficultyIcon = loadImage(Misc.resolveFile("HUD/HUD 2/Easy.png"))
		elseif SaveData["Difficulty"] == 2 then
			DifficultyIcon = loadImage(Misc.resolveFile("HUD/HUD 2/Normal.png"))
		elseif SaveData["Difficulty"] == 3 then
			DifficultyIcon = loadImage(Misc.resolveFile("HUD/HUD 2/Hard.png"))
		elseif SaveData["Difficulty"] == 4 then
			DifficultyIcon = loadImage(Misc.resolveFile("HUD/HUD 2/Lunatic.png"))
		elseif SaveData["Difficulty"] == 5 then
			DifficultyIcon = loadImage(Misc.resolveFile("HUD/HUD 2/Lunatic.png"))
		end
		if SaveData["Difficulty"] == nil then
			SaveData["Difficulty"] = 2
		end
		if Layer.get("Difficulty " .. toString(SaveData["Difficulty"])) ~= nil then
			Layer.get("Difficulty " .. (SaveData["Difficulty"])):show(true)
		elseif Layer.get("Difficulty " .. toString(toNumber(SaveData["Difficulty"])) - 1) ~= nil then
			Layer.get("Difficulty " .. toString(toNumber(SaveData["Difficulty"])) - 1):show(true)
		end
	end
	if SaveData["Mode"] == nil or SaveData["Mode"] == 0 then
		SaveData["Mode"] = 2
	end
	if SaveData["Deaths"] == nil then
		SaveData["Deaths"] = "Show"
	end
	if SaveData["extendedLives"] == nil then
		SaveData["extendedLives"] = 0 
	end
	if player.character == CHARACTER_PEACH then
		Defines.player_runspeed = 7
	else
		Defines.player_runspeed = 6
	end
	if SaveData["G_Princess_Float"] == nil then
		SaveData["G_Princess_Float"] = 0
	end
	Graphics.activateHud(false)
	if SaveData[Level.filename() .. "moon"] == true then
		for k, moon in ipairs(NPC.get(188, -1)) do
			moon:kill()
		end
	elseif SaveData[Level.filename() .. "moon"] == nil then
		SaveData[Level.filename() .. "moon"] = false
	end
end

function onNPCKill(eventObj, killedNPC, killReason)
	if (killedNPC.id == 188) then
		SaveData[Level.filename() .. "moon"] = true
	end
	if (killReason == 9) and ((killedNPC.id == 192) or (killedNPC.id == 400)) then
		if coinT < 5 then 
			coinless = false
		end
	end
end

local function formatTime(t, m)
	realMiliseconds = mathfloor(t*15.6);
	miliseconds = realMiliseconds%1000;
	realSeconds = mathfloor(realMiliseconds*0.001);
	seconds = realSeconds%60;
	realMinutes = mathfloor(realSeconds*0.0166666667);
	minutes = realMinutes%60;
	hours = mathfloor(realMinutes*0.0166666667);

	if hours < 10 then
		hours = "0"..toString(hours);
	end

	if minutes < 10 then
		minutes = "0"..toString(minutes);
	end

	if seconds < 10 then
		seconds = "0"..toString(seconds);
	end

	if miliseconds < 10 then
		miliseconds = "00"..toString(miliseconds);
	elseif miliseconds < 100 then
		miliseconds = "0"..toString(miliseconds);
	end
	
	if m == 1 then
		displayTime = toString(hours) .. ":" .. toString(minutes) .. ":" .. toString(seconds) .. "." .. toString(miliseconds)
	elseif m == 2 then
		displayTime = toString(hours) .. ":" .. toString(minutes) .. ":" .. toString(seconds)
	elseif m == 3 then
		displayTime = toString(minutes) .. ":" .. toString(seconds) .. "." .. toString(string.format("%02d", mathfloor(miliseconds*0.1)))
	end
	return displayTime
end

local function onDifficultyChange()
	if Layer.get("Difficulty 1") ~= nil then Layer.get("Difficulty 1"):hide(true) end
	if Layer.get("Difficulty 2") ~= nil then Layer.get("Difficulty 2"):hide(true) end
	if Layer.get("Difficulty 3") ~= nil then Layer.get("Difficulty 3"):hide(true) end
	if Layer.get("Difficulty 4") ~= nil then Layer.get("Difficulty 4"):hide(true) end
	if Layer.get("Difficulty 5") ~= nil then Layer.get("Difficulty 5"):hide(true) end
	if Layer.get("Difficulty " .. toString(SaveData["Difficulty"])) ~= nil then
		Layer.get("Difficulty " .. (SaveData["Difficulty"])):show(true)
	elseif Layer.get("Difficulty " .. toString(toNumber(SaveData["Difficulty"])) - 1) ~= nil then
		Layer.get("Difficulty " .. toString(toNumber(SaveData["Difficulty"])) - 1):show(true)
	end
end

function onDraw()
	textplus.print{plaintext=true, text="Aあいうえお", x=0, y=0, xscale=2, yscale=2, priority = 11, font = B7Sfont}
	if int == false then
		local LCC = mem(0x00B2C5A8,FIELD_WORD)
		int = true
	else
		if Misc.inEditor() then
			--[[if SaveData["Difficulty"] == 1 and DifficultyIcon ~= Graphics.loadImage(Misc.resolveFile("HUD/HUD 2/Easy.png")) then
				DifficultyIcon = Graphics.loadImage(Misc.resolveFile("HUD/HUD 2/Easy.png"))
				onDifficultyChange()
			elseif SaveData["Difficulty"] == 2 and DifficultyIcon ~= Graphics.loadImage(Misc.resolveFile("HUD/HUD 2/Normal.png")) then
				DifficultyIcon = Graphics.loadImage(Misc.resolveFile("HUD/HUD 2/Normal.png"))
				onDifficultyChange()
			elseif SaveData["Difficulty"] == 3 and DifficultyIcon ~= Graphics.loadImage(Misc.resolveFile("HUD/HUD 2/Hard.png")) then
				DifficultyIcon = Graphics.loadImage(Misc.resolveFile("HUD/HUD 2/Hard.png"))
				onDifficultyChange()
			elseif SaveData["Difficulty"] == 4 and DifficultyIcon ~= Graphics.loadImage(Misc.resolveFile("HUD/HUD 2/Lunatic.png"))then
				DifficultyIcon = Graphics.loadImage(Misc.resolveFile("HUD/HUD 2/Lunatic.png"))
				onDifficultyChange()
			elseif SaveData["Difficulty"] == 5 and DifficultyIcon ~= Graphics.loadImage(Misc.resolveFile("HUD/HUD 2/Lunatic.png"))then
				DifficultyIcon = Graphics.loadImage(Misc.resolveFile("HUD/HUD 2/Lunatic.png"))
				onDifficultyChange()
			end]]
		end
		if SaveData["Difficulty"] == nil then
			SaveData["Difficulty"] = 4
		end
		coinT = coinT + 1
		if SaveData["Total"] > 999999999990 then
			SaveData["Total"] = 999999999990
		end
		if LCC ~= mem(0x00B2C5A8,FIELD_WORD) then--or Defines.player_hasCheated then
			coinless = false
		end
		if Level.filename() ~= 'intro.lvl' then
			SaveData["GlobalTime"] = SaveData["GlobalTime"] + 1
			if SaveData["HUD Type"]  == "A" then
				if SaveData["Difficulty"] == 1 then
					Text.printWP("Easy", 0, 0, 5)
				elseif SaveData["Difficulty"] == 2 then
					Text.printWP("Normal", 0, 0, 5)
				elseif SaveData["Difficulty"] == 3 then
					Text.printWP("Hard", 0, 0, 5)
				elseif SaveData["Difficulty"] == 4 then
					Text.printWP("Lunatic", 0, 0, 5)
				elseif SaveData["Difficulty"] == 5 then
					Text.printWP("Overdrive", 0, 0, 5)
				end
			elseif SaveData["HUD Type"]  == "B" then
				if DifficultyIcon ~= nil then
					Graphics.drawImageWP(DifficultyIcon, 114, 36, 4.9999)
				end
			end
			if SaveData["Mode"] == 2 then
				if Level.winState() == nil or Level.winState() == 0 then
					t = t + 1
				end
				if SaveData["HUD Type"]  == "A" then
					Text.printWP(formatTime(toNumber(t), 1), 548, 2, 5)
				elseif SaveData["HUD Type"]  == "B" then
					if t <= 230769 then
						Text.printWP(formatTime(toNumber(t), 3), 542, 16, 5)
					else
						Text.printWP(formatTime(toNumber(t), 2), 542, 16, 5)
					end
				end
			elseif SaveData["Mode"] == 3 then

				if SaveData["HUD Type"]  == "A" then
					Text.printWP(formatTime(SaveData["GlobalTime"], 1), 550, 2, 5)
				elseif SaveData["HUD Type"]  == "B" then
					if SaveData["GlobalTime"] <= 230769 then
						Text.printWP(formatTime(toNumber(SaveData["GlobalTime"]), 3), 542, 16, 5)
					else
						Text.printWP(formatTime(toNumber(SaveData["GlobalTime"]), 2), 542, 16, 5)
					end
				end
			elseif SaveData["Mode"] == 1 then
				if SaveData["HUD Type"]  == "A" then
					Text.printWP(string.format("%012d", (SaveData["Total"] + SaveData._basegame.hud.score)), 550, 2, 5)
				elseif SaveData["HUD Type"]  == "B" then
					Text.printWP(string.format("%08d", (SaveData["Total"] + SaveData._basegame.hud.score)), 542, 16, 5)
				end
			end
			if SaveData["GlobalTime"] ~= nil and SaveData["Goal"] ~= 2 then
				SaveData["GlobalTime"] = SaveData["GlobalTime"] + 1
			end
			if SaveData["G_Princess_Float"] == nil or SaveData["G_Princess_Float"] == 0 then
				player:mem(0x18, FIELD_BOOL, false)
			end
			if SaveData["HUD Type"]  == "A" then
				Graphics.drawImageWP(HUD, 0, 0, 4.9999)
				Graphics.drawImageWP(playerLiveDisplay, 208, 2, 4.9999)
				if (SaveData["Mode"] == 2 or SaveData["Mode"] == 3) and (Level.filename() ~= 'Intro.lvl') then
					Graphics.drawImageWP(Clock, 508, 2, 4.9999)
				elseif (SaveData["Mode"]) == 1 and Level.filename() ~= 'Intro.lvl' then
					Graphics.drawImageWP(Crown, 508, 2, 4.9999)
					--Text.printWP(string.format("%\12d", score:get("Total")), 548, 2, 4.9999)
				end
				-- Lives
				Text.printWP((string.format("%03d", toString(toNumber(mem(0x00B2C5AC,FIELD_FLOAT))) + (toNumber(SaveData["extendedLives"])))), 258, 2, 5)
				-- Stars
				Text.printWP(string.format("%03d", mem(0x00B251E0,FIELD_WORD)), 258, 22, 5)
				-- Coins
				Text.printWP(string.format("%02d", mem(0x00B2C5A8,FIELD_WORD)), 466, 2, 5)
			elseif SaveData["HUD Type"]  == "B" then
				Graphics.drawImageWP(HUD2, 0, 0, 4.9999)
				Graphics.drawImageWP(StarCoinTracker, 0,2, 4.9999)
				if SaveData[Level.filename() .. "coinless"] == true then
					Graphics.drawImageWP(coinlessMedal, 484, 2, 4.9999)
				end
				if SaveData[Level.filename() .. "moon"] == true then
					Graphics.drawImageWP(lunaMedal, 500, 2, 4.9999)
				end
				-- Lives
				Text.printWP((string.format("%03d", toString(toNumber(mem(0x00B2C5AC,FIELD_FLOAT))) + (toNumber(SaveData["extendedLives"])))), 260, 18, 5)
				-- Stars
				--Text.printWP(string.format("%03d", mem(0x00B251E0,FIELD_WORD)), 258, 22, 5)
				-- Coins
				Text.printWP(string.format("%06d", (mem(0x00B2C5A8,FIELD_WORD)+SaveData.Coins)), 516, 48, 5)
				if player.character < 3 then
					Graphics.drawImageWP(reserveBox, 0, 0, 4.9999)
					if player.reservePowerup == 9 or player.reservePowerup == 184 or player.reservePowerup == 185 then
						Graphics.drawImageWP(sMushroom, 384, 28, 5)
					elseif player.reservePowerup == 14 or player.reservePowerup == 182 or player.reservePowerup == 183 then
						Graphics.drawImageWP(sFireFlower, 384, 28, 5)
					elseif player.reservePowerup == 34 then
						Graphics.drawImageWP(sLeaf, 384, 28, 5)
					elseif player.reservePowerup == 169 then
						Graphics.drawImageWP(sTanookie, 384, 28, 5)
					elseif player.reservePowerup == 170 then
						Graphics.drawImageWP(sHammer, 384, 28, 5)
					elseif player.reservePowerup == 264 or player.reservePowerup == 277 then
						Graphics.drawImageWP(sIce, 384, 28, 5)
					elseif player.reservePowerup == 279 then
						Graphics.drawImageWP(sPhoenix, 384, 28, 5)
					end
				end
			end
			if player.character > 2 then
				for i = 1, 3 do
					Graphics.drawImageWP(heartNul, (((i-1)*34)+350), 26, 5)
				end
				for i = 0, player:mem(0x16, FIELD_WORD) do
					if i > 0 then
						Graphics.drawImageWP(heart, (((i-1)*34)+350), 26, 5)
					end
				end
			end
			if SaveData["Deaths"] == "Show" then
				if SaveData[Level.filename() .. "-deaths"] == nil then
					SaveData[Level.filename() .. "-deaths"] = 0
				end
				if SaveData["totalDeaths"] == nil then
					SaveData["totalDeaths"] = 0
				end			
				if SaveData["HUD Type"]  == "A" then
					Graphics.drawImageWP(Skull, 508, 20, 5)
					Text.printWP(SaveData[Level.filename() .. "-deaths"] .. "/" .. SaveData["totalDeaths"], 548, 20, 5)
				elseif SaveData["HUD Type"]  == "B" then
					Graphics.drawImageWP(Skull2, 0, 0, 5)
					if SaveData["totalDeaths"] < 1000 then
						Text.printWP(string.format("%03d", SaveData["totalDeaths"]), 260, 44, 5)
					else
						Text.printWP(string.format("%04d", SaveData["totalDeaths"]), 260, 44, 5)
					end
				end
			end
		end
	end
	if coinless == true and Level.winState() > 0 then
		SaveData[Level.filename() .. "coinless"] = true
	end
	if mem(0x00B2C5A8,FIELD_WORD) > 60 then
		SaveData.Coins = mem(0x00B2C5A8,FIELD_WORD) + SaveData.Coins
		mem(0x00B2C5A8,FIELD_WORD, 0)
	end
	if (SaveData.Coins + SaveData["SpentCoins"]) ~= SaveData["GlobalCoins"] then
		 SaveData["GlobalCoins"] = SaveData.Coins + SaveData["SpentCoins"]
	end
end

function onTick()
--Text.printWP(mem(0x00B2C5AC,FIELD_FLOAT), 500, 484, 10)
--Text.printWP(SaveData["Mode"], 500, 500, 10)
--Text.printWP(coinless, 0, 0, 10)
--Text.printWP(LCC, 0, 16, 10)
--Text.printWP(mem(0x00B2C5A8,FIELD_WORD), 0, 32, 10)
	if mem(0x00B2C5AC,FIELD_FLOAT) == 94 and SaveData["extendedLives"] <= 899 then
		mem(0x00B2C5AC,FIELD_FLOAT, mem(0x00B2C5AC,FIELD_FLOAT) - 1)
		SaveData["extendedLives"] = SaveData["extendedLives"] + 1
	elseif SaveData["extendedLives"] >= 1 and player:mem(0x13C, FIELD_DWORD) ~= 0 and not hasDied then
		SaveData["extendedLives"] = SaveData["extendedLives"] - 1
		if mem(0x00B2C5AC,FIELD_FLOAT) == 92 then
			mem(0x00B2C5AC,FIELD_FLOAT, mem(0x00B2C5AC,FIELD_FLOAT) + 1)
		end
		hasDied = true
		Misc.saveGame()
	end
end



function onLevelExit()

end