local timeCoin = {} -- api table


-- load scripts--
local npcManager = require("npcManager")
local colliders = require("colliders")

-- set defines --
npcManager.setNpcSettings({id=NPC_ID,gfxheight=48,gfxwidth=48,width=44,height=48,gfxoffsetx=0,gfxoffsety=0,frames=16,framestyle=0,framespeed=3,speed=0,npcblock=false,npcblocktop=false,playerblock=false,playerblocktop=false,nohurt=true,nogravity=true,noblockcollision=true,nofireball=true,noiceball=true,noyoshi=false,nowaterphysics=true,jumphurt=true,spinjumpsafe=false,harmlessgrab=false,harmlessthrown=false})
npcManager.registerDefines(NPC_ID, {NPC.COLLECTIBLE}) -- make act like coin



-- register events --
function timeCoin.onInitAPI()
    registerEvent(timeCoin,"onStart")
    registerEvent(timeCoin,"onTick")
    registerEvent(timeCoin,"onNPCKill")
end



function timeCoin.onStart()
    if SaveData["mode"] ~= 4 then -- if not in panic mode
        for _,npc in ipairs(NPC.get(NPC_ID)) do
            npc:kill()
        end
    end
end

function timeCoin.onTick()
    if SaveData["mode"] ~= 4 then
        for _,p in ipairs(Player.get()) do
            for _,npc in ipairs(NPC.get(NPC_ID,p.section)) do
                if colliders.collide(npc,p) then
                    npc:kill()
                end
            end
        end
    end
end

function timeCoin.onNPCKill(event, npc, reason)
    if npc.id == NPC_ID and SaveData["mode"] == 4 then
        Audio.playSFX(14)
        Animation.spawn(79,npc.x+8,npc.y+14)
        animclock.seconds = animclock.seconds + 100
        animclock.secondsLeft = animclock.secondsLeft + 100
    end
end


return timeCoin