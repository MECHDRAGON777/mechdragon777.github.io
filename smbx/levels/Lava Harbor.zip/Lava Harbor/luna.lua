Player.setCostume(CHARACTER_TOAD, "toadette")
function onStart()
	player:transform(CHARACTER_TOAD)
end