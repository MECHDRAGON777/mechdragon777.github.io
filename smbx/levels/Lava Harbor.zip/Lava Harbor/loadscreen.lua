local BG = Graphics.loadImage("loading/"..readmem(0xB2C5A4, FIELD_STRING).."Loading.png")

function onDraw()
    if BG == nil then
        local BG = Graphics.loadImage("loading/"..readmem(0xB2C5A4, FIELD_STRING).."Loading.png")
    end
    if BG ~= nil then
        Graphics.drawImage(BG, 0, 0)
    end
end