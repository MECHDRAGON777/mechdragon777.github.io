--------------------------------------------------------------------------
--			  _  _   __   __    __      __  _  _  _  _  ____ 			--
--			 / )( \ / _\ (  )  (  )   _(  )/ )( \( \/ )(  _ \			--
--			 \ /\ //    \/ (_/\/ (_/\/ \) \) \/ (/ \/ \ ) __/			--
--			 (_/\_)\_/\_/\____/\____/\____/\____/\_)(_/(__)      		--
--		  __ _  __  ___  _  _  ____  _  _   __   ____  ____  ____ 		--
--		 (  ( \(  )/ __)/ )( \(_  _)( \/ ) / _\ (  _ \(  __)/ ___)		--
--		 /    / )(( (_ \) __ (  )(  / \/ \/    \ )   / ) _) \___ \		--
--		 \_)__)(__)\___/\_)(_/ (__) \_)(_/\_/\_/(__\_)(____)(____/		--
--																		--
--							 --B y   F u y u--							--
--																		--
--------------------------------------------------------------------------

--------------------------------------------------------------------------
--							 L I B R A R I E S							--
--------------------------------------------------------------------------
local walljump = require("wahMoves") --By Sturg
local rooms = require("rooms") --By Mr.DoubleA
local warpTransition = require("warpTransition") --By Mr.DoubleA

--------------------------------------------------------------------------
--		 M R . D O U B L E  A ' S    W A R P    S E T T I N G S			--
--------------------------------------------------------------------------
warpTransition.levelStartTransition = warpTransition.TRANSITION_NONE
warpTransition.sameSectionTransition = warpTransition.TRANSITION_SWIRL
warpTransition.musicFadeOut = false

--------------------------------------------------------------------------
--								I M A G E S								--
--------------------------------------------------------------------------
local skullHead = Graphics.loadImage(Misc.resolveFile("images/skullHead.png"))
local skullMouth = Graphics.loadImage(Misc.resolveFile("images/skullMouth.png"))
local skullEyes = Graphics.loadImage(Misc.resolveFile("images/skullEyes.png"))
local placeholder = Graphics.loadImage(Misc.resolveFile("images/placeholder.png"))
local cinema = Graphics.loadImage(Misc.resolveFile("images/cutscene.png"))

local liness = Graphics.loadImage(Misc.resolveFile("images/lines.png"))
local skip = Graphics.loadImage(Misc.resolveFile("images/skip.png"))

local deathlessIMG = Graphics.loadImage(Misc.resolveFile("images/deathless.png"))
local reverseIMG = Graphics.loadImage(Misc.resolveFile("images/reverse.png"))
local clockIMG = Graphics.loadImage(Misc.resolveFile("images/clock.png"))

local st = Graphics.loadImage(Misc.resolveFile("images/starCoins.png"))

--------------------------------------------------------------------------
--								 A U D I O								--
--------------------------------------------------------------------------
local hbSFX = Misc.resolveFile("sfx/heartbeat.ogg")
local msg1SFX = Misc.resolveFile("sfx/message1.ogg")
local msg2SFX = Misc.resolveFile("sfx/message2.ogg")
local msg3SFX = Misc.resolveFile("sfx/message3.ogg")
local msg4SFX = Misc.resolveFile("sfx/message4.ogg")
local pr1SFX = Misc.resolveFile("sfx/prologue1.ogg")
local pr2SFX = Misc.resolveFile("sfx/prologue2.ogg")
local pr3SFX = Misc.resolveFile("sfx/prologue3.ogg")
local pr4SFX = Misc.resolveFile("sfx/prologue4.ogg")
local pr5SFX = Misc.resolveFile("sfx/prologue5.ogg")
local pr6SFX = Misc.resolveFile("sfx/prologue6.ogg")

--------------------------------------------------------------------------
--							 V A R I A B L E S							--
--------------------------------------------------------------------------
local heartbeatTimer = 128
local cutscene = false
local dialogueStart = false
local dialogue1T = 672
local dialogue2T = 640
local dialogue3T = 704
local dialogue4T = 800
local dialogue5T = 352
local dialogue6T = 576
local dialogueT = 3744
local smY = -202190
local talk = false
local eyeOp = 0
local skipOp = 0
local musicTime = false
local topY = -32
local bottomY = 600
local currentLine = 0
local lipSyncTimer = table.map{
	3744,
	3710,
	3685,
	3650,
	3600,
	3570,
	3540,
	3515,
	3430,
	3410,
	3395,
	3355,
	3325,
	3300,
	3250,
	3215,
	3175,
	3060,
	3030,
	2975,
	2940,
	2925,
	2900,
	2875,
	2845,
	2810,
	2720,
	2690,
	2660,
	2600,
	2570,
	2530,
	2445,
	2410,
	2305,
	2265,
	2230,
	2145,
	2110,
	2075,
	1955,
	1885,
	1840,
	1730,
	1710,
	1675,
	1630,
	1585,
	1495,
	1470,
	1445,
	1395,
	1350,
	1295,
	1275,
	1240,
	1130,
	1032,
	930,
	875,
	835,
	785,
	735,
	710,
	670,
	567,
	535,
	515,
	475,
	440,
	425,
	335,
	265,
	205,
	140
}
local dialogueSpeeds = {
	[3744] = 2,
	[1955] = 1,
	[1900] = 2,
	[1840] = 1,
	[1800] = 2,
	[1130] = 1,
	[930] = 2,
	[335] = 1
}
local dialogueSpeed = 2
local spikeLayerT = 128
local movementWait = 0
local up = false
local down = false
local deathless = false
local cheatOrder = 0
local deathCount = 0
local t = 0
local int = false
local wait = 0
local hasCounted = false
local st1 = 0
local st2 = 0
local st3 = 0
local st4 = 0
local st5 = 0

--------------------------------------------------------------------------
--							 F U N C T I O N S							--
--------------------------------------------------------------------------
function onStart()
	hud(false)
	Cheats.register("ihatemyself", {
		onActivate = function()
			deathless = not deathless
			Layer.get("Deathless"):show(true)
			return true
		end,
		activateSFX = Misc.resolveFile("sfx/ihatemyself.ogg")
	})
	Cheats.register("backwardsrave", {
		onActivate = function()
			for index, myWarp in ipairs(Warp.get(1)) do
				Layer.get("Reverse"):show(true)
				Layer.get("Normal"):hide(true)
				Layer.get("NormalExit"):hide(true)
				Layer.get("Deathless"):hide(true)
				if deathless then
					deathless = not deathless
				end
				myWarp.entranceX = player.x
				myWarp.entranceY = player.y
				wait = 116
				return true
			end
		end,
		activateSFX = Misc.resolveFile("sfx/backwardsrave.ogg")
	})
	starCoinGet()
end

function onTick()
    local room = rooms.rooms[rooms.currentRoomIndex]

    if room ~= nil then
        local col = room.collider
        
        for _,npc in NPC.iterateIntersecting(col.x,col.y,col.x+col.width,col.y+col.height) do
            if not npc.isHidden then
                npc.despawnTimer = 180
                npc:mem(0x124,FIELD_BOOL,true)
            end
        end
    end
end

function onRoomEnter(idx)
	if idx > 4 then
		Cheats.deregister("ihatemyself")
		Cheats.deregister("backwardsrave")
	else
		Cheats.register("ihatemyself", {
			onActivate = function()
				deathless = not deathless
				Layer.get("Deathless"):show(true)
				return true
			end,
			activateSFX = Misc.resolveFile("sfx/ihatemyself.ogg")
		})
		Cheats.register("backwardsrave", {
			onActivate = function()
				for index, myWarp in ipairs(Warp.get(1)) do
					Layer.get("Reverse"):show(true)
					Layer.get("Normal"):hide(true)
					Layer.get("NormalExit"):hide(true)
					Layer.get("Deathless"):hide(true)
					if deathless then
						deathless = not deathless
					end
					myWarp.entranceX = player.x
					myWarp.entranceY = player.y
					wait = 116
					return true
				end
			end,
			activateSFX = Misc.resolveFile("sfx/backwardsrave.ogg")
		})
	end
	if reverseM then
		Layer.get("Reverse"):show(true)
		Layer.get("Normal"):hide(true)
	elseif deathless then
		Layer.get("NormalExit"):hide(true)
	end
end

function onReset(fromDespawn)
	if reverseM then
		Layer.get("Reverse"):show(true)
		Layer.get("Normal"):hide(true)
		Layer.get("NormalExit"):hide(true)
	elseif deathless then
		Layer.get("NormalExit"):hide(true)
		t = 0
		SaveData._basegame.starcoin[Level.filename()][1] = 0
		SaveData._basegame.starcoin[Level.filename()][2] = 0
		SaveData._basegame.starcoin[Level.filename()][3] = 0
		SaveData._basegame.starcoin[Level.filename()][4] = 0
		SaveData._basegame.starcoin[Level.filename()][5] = 0
		st1 = 0
		st2 = 0
		st3 = 0
		st4 = 0
		st5 = 0
		starCoinGet()
		Layer.get("Deathless"):show(true)
	else
		Layer.get("NormalExit"):show(true)
		Layer.get("Deathless"):hide(true)
	end
	hasCounted = false
end

function onDraw()
	if musicTime then
		if not(deathless) then
			Text.printWP("DEATHS: "..math.floor(deathCount), 600, 568, 5)
		end
		if wait > 0 then
			wait = wait - 1
		else
			if int ~= true then
				t = 1
				int = true
			else
				if Level.winState() == nil or Level.winState() == 0 then
					t = t + 1
				end
			end
		end
		if not(reverseM) then
			Graphics.drawImageWP(st, 342, 546, 0, st1, 16, 16, 1, 5)
			Graphics.drawImageWP(st, 362, 546, 0, st2, 16, 16, 1, 5)
			Graphics.drawImageWP(st, 382, 546, 0, st3, 16, 16, 1, 5)
			Graphics.drawImageWP(st, 402, 546, 0, st4, 16, 16, 1, 5)
			Graphics.drawImageWP(st, 422, 546, 0, st5, 16, 16, 1, 5)
		end
		Text.printWP(formatTime(t), 320, 568, 5)
		Graphics.drawImageWP(clockIMG, 284, 560, 5)
	end

    for k,v in ipairs(Block.getIntersecting(player.x, player.y, player.x + player.width, player.y + player.height)) do
		if v.id == 1092 and not(musicTime) then
			heartbeatTimer = 256
			musicTime = true
			Layer.get("music"):toggle(true)
			heartbeatStop = true
			if player.x < -190272 then
				Defines.earthquake = 12
				SFX.play(37)
				if not(deathless) then
					Audio.MusicChange(0, "Walljump Nightmares Redux/Umineko - The Executioner.ogg")
				else
					Audio.MusicChange(0, "Walljump Nightmares Redux/Funk Fiction - Miniboss.ogg")
				end
			else
				Audio.MusicChange(0, "Walljump Nightmares Redux/Funk Fiction - Where Desire Lies (feat. Andy Studer).ogg")
				reverseM = true
				Layer.get("Reverse"):show(true)
				Layer.get("Normal"):hide(true)
				Layer.get("NormalExit"):hide(true)
			end
		elseif v.id == 1143 and musicTime then
			musicTime = false
			triggerEvent("bummer")
			heartbeatStop = false
			Audio.MusicChange(0, 0)
			deathCount = 0
		end
	end
	
	if player:mem(0x13E, FIELD_BOOL) and not(hasCounted) then
		hasCounted = true
		deathCount = deathCount + 1
	end
	
	Graphics.drawImageWP(cinema, 0, topY, 0)
	Graphics.drawImageWP(cinema, 0, bottomY, 0)

	if cutscene then
		if topY < 0 and bottomY > 568 then
			topY = topY + 0.5
			bottomY = bottomY - 0.5
		end
		if player.x < -190646 and player.y < -201984 then
			player.speedX = 2
		elseif player.speedX == 0 then
			dialogueStart = true
		end
	else
		if topY > -32 and bottomY < 600 then
			topY = topY - 0.5
			bottomY = bottomY + 0.5
		end
		dialogue1T = 672
		dialogue2T = 640
		dialogue3T = 704
		dialogue4T = 800
		dialogue5T = 352
		dialogue6T = 576
		dialogueT = 3744
		smY = -202190
	end

	if dialogueT > 0 then
		Graphics.drawImageToSceneWP(placeholder, -190752, -201984, -46)
	end

	if eyeOp < 1 and dialogueT < 1000 then
		eyeOp = eyeOp + 0.002
	elseif dialogueT > 1000 then
		eyeOp = 0
	end

	if dialogueStart then
		if skipOp < 100 then
			skipOp = skipOp + 1
		end
		if lipSyncTimer[dialogueT] then
			talk = true
		end
		if dialogueT > 0 then
			Graphics.drawImageWP(liness, 177, 576, 0, currentLine * 16, 446, 16, 1, 0)
			Graphics.drawImageWP(skip, 580, 8, 0, 0, 156, 16, skipOp / 100, 0)
			dialogueT = dialogueT - 1
		elseif dialogueT == 0 then
			for x = -5959, -5955 do --x
				for y = -6312, -6311 do --y
					Animation.spawn(1, x * 32, y * 32)
				end
			end
			SFX.play(4)
			Layer.get("platform"):hide(true)
			dialogueT = -1
		elseif dialogueT == -1 then
			dialogueStart = false
			if heartbeatStop then
				cutscene = false
			end
		end
		if dialogueT > 3430 then
			currentLine = 0
		elseif dialogueT > 3060 then
			currentLine = 1
		elseif dialogueT > 2720 then
			currentLine = 2
		elseif dialogueT > 2445 then
			currentLine = 3
		elseif dialogueT > 1730 then
			currentLine = 4
		elseif dialogueT > 1495 then
			currentLine = 5
		elseif dialogueT > 1295 then
			currentLine = 6
		elseif dialogueT > 1130 then
			currentLine = 7
		elseif dialogueT > 930 then
			currentLine = 8
		elseif dialogueT > 567 then
			currentLine = 9
		elseif dialogueT > 0 then
			currentLine = 10
		end
		if dialogue1T == 672 then
			currentsfx = SFX.play(pr1SFX)
			dialogue1T = dialogue1T - 1
		elseif dialogue1T < 1 and dialogue2T == 640 then
			currentsfx = SFX.play(pr2SFX)
			dialogue2T = dialogue2T - 1
		elseif dialogue2T < 1 and dialogue3T == 704 then
			currentsfx = SFX.play(pr3SFX)
			dialogue3T = dialogue3T - 1
		elseif dialogue3T < 1 and dialogue4T == 800 then
			currentsfx = SFX.play(pr4SFX)
			dialogue4T = dialogue4T - 1
		elseif dialogue4T < 1 and dialogue5T == 352 then
			currentsfx = SFX.play(pr5SFX)
			dialogue5T = dialogue5T - 1
		elseif dialogue5T < 1 and dialogue6T == 576 then
			currentsfx = SFX.play(pr6SFX)
			dialogue6T = dialogue6T - 1
		end
		if dialogue1T > 0 and dialogue1T < 672 then
			dialogue1T = dialogue1T - 1
		elseif dialogue2T > 0 and dialogue2T < 640 then
			dialogue2T = dialogue2T - 1
		elseif dialogue3T > 0 and dialogue3T < 704 then
			dialogue3T = dialogue3T - 1
		elseif dialogue4T > 0 and dialogue4T < 800 then
			dialogue4T = dialogue4T - 1
		elseif dialogue5T > 0 and dialogue5T < 352 then
			dialogue5T = dialogue5T - 1
		elseif dialogue6T > 0 and dialogue6T < 576 then
			dialogue6T = dialogue6T - 1
		end
	else
		skipOp = 0
	end

	if skipping then
		currentsfx:stop()
		dialogueT = 0
		skipping = false
	end

	if not(heartbeatStop) then
		if heartbeatTimer > 0 then
			heartbeatTimer = heartbeatTimer - 1
		else
			heartbeatTimer = 256
		end
	end
	
	if heartbeatTimer == 64 or heartbeatTimer == 32 then
		SFX.play(hbSFX)
		Defines.earthquake = 6
	end
	
	if dialogueStart then
		if smY > -202190 and not(talk) then
			smY = smY - dialogueSpeed
		elseif smY < -202142 and talk then
			smY = smY + 8
		else
			talk = false
		end
	end
	
	Graphics.drawImageToSceneWP(skullHead, -190740, -202446, -48)
	Graphics.drawImageToSceneWP(skullMouth, -190704, smY, -47)
	Graphics.drawImageToSceneWP(skullEyes, -190740, -202446, 0, 0, 264, 384, eyeOp, -46)
	
	dialogueSpeed = dialogueSpeeds[dialogueT] or dialogueSpeed
	
	if deathless then
		Graphics.drawImageWP(deathlessIMG, 24, 560, 5)
		rooms.neverUseRespawnBGOs = true
		Graphics.drawScreen{
			color = {0.74, 0.12, 0.13, 0.1},
			priority = -23
		}
	elseif reverseM then
		Graphics.drawImageWP(reverseIMG, 24, 558, 5)
		Graphics.drawScreen{
			color = {0.58, 0.57, 0.74, 0.1},
			priority = -23
		}
	else
		rooms.neverUseRespawnBGOs = false
	end
end

function onEvent(eventname)
	--The following plays the whispers in the intro + start the skull cutscene
	if eventname == "message1" then
		SFX.play(msg1SFX)
	elseif eventname == "message2" then
		SFX.play(msg2SFX)
	elseif eventname == "message3" then
		SFX.play(msg3SFX)
	elseif eventname == "message4" then
		SFX.play(msg4SFX)
	elseif eventname == "startCutscene" then
		cutscene = true
	elseif eventname == "movementStart" then
		up = true
	end
end

function onInputUpdate()
	if player.keys.altJump and skipOp > 50 and dialogueT > 0 then
		skipping = true
	end
	
	if cutscene then
		for k, _ in pairs(player.keys) do
			player.keys[k] = false
		end
	end
end

function formatTime(t)
    realMiliseconds = math.floor(t*15.6);
    miliseconds = realMiliseconds%1000;
    realSeconds = math.floor(realMiliseconds/1000);
    seconds = realSeconds%60;
    realMinutes = math.floor(realSeconds/60);
    minutes = realMinutes%60;
    realHours = math.floor(realMinutes/60);
    hours = realHours%24;
    days = math.floor(realHours/24)

    if hours < 10 then
        hours = "0"..tostring(hours);
    end

    if minutes < 10 then
        minutes = "0"..tostring(minutes);
    end

    if seconds < 10 then
        seconds = "0"..tostring(seconds);
    end

    if miliseconds < 10 then
        miliseconds = "00"..tostring(miliseconds);
    elseif miliseconds < 100 then
        miliseconds = "0"..tostring(miliseconds);
    end
    
    displayTime = tostring(minutes) .. ":" .. tostring(seconds) .. "." .. tostring(miliseconds)
    return displayTime
end

function onNPCKill(a, b, c)
	if b.id == 310 then
		starCoinGet()
	end
end

function starCoinGet()
	for i = 1, 10 do
		if SaveData._basegame.starcoin[Level.filename()][i] ~= nil then
			if SaveData._basegame.starcoin[Level.filename()][i] > 0 then
				if i == 1 then
					st1 = 16
				elseif i == 2 then
					st2 = 16
				elseif i == 3 then
					st3 = 16
				elseif i == 4 then
					st4 = 16
				elseif i == 5 then
					st5 = 16
				end
			end
		end
	end
end
--------------------------------------------------------------------------
--							 	 E N D				    				--
--------------------------------------------------------------------------