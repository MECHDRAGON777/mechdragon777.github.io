local wahMoves = {};

local inputs2 = loadSharedAPI("inputs2")
local colliders = API.load("colliders")

local toadCheckmate = (player:mem(0xF0, FIELD_WORD) == 4)

local animationWait = 4
local jumpReady = false
local hasJumpedTimer = 0
wahMoves.animationBuffer = 0

local sfxJump = Misc.resolveFile("megaJump.WAV") or Misc.resolveFile("worlds/WAH SQUAD/resources/megaJump.WAV")

local playerIsInLocation = nil
local levelSection = nil
local topBoundary = nil
local leftBoundary = nil
local rightBoundary = nil
local bottomBoundary = nil
local cornerBox = nil
local playerisLocated = player.section

function wahMoves.onInitAPI()
	registerEvent(wahMoves,"onTick","onTick")
	registerEvent(wahMoves,"onInputUpdate", "onInputUpdate")
	registerEvent(wahMoves,"onStart","onStart")
	registerEvent(wahMoves,"onDraw","onDraw")
end
---Touching Left Wall
function wahMoves.leftHug()
	return player:mem(0x148, FIELD_WORD) > 0
end
---Touching Right Wall
function wahMoves.rightHug()
	return player:mem(0x14C, FIELD_WORD) > 0
end
---Restrictions; no bottom state, not underwater, not death animation, and is Toad.
function wahMoves.bottomTouch()
	return player:mem(0x146, FIELD_WORD) < 2 and player:mem(0x36, FIELD_WORD) ~= -1 and player:mem(0x13E, FIELD_WORD) == 0
end
--- sliding animation and movement; cancel spinjump; jump off timer
function wahMoves.wallSlide()
	if wahMoves.leftHug() or wahMoves.rightHug() then
		playerLeftField = player:mem(0x148,FIELD_WORD)
		playerRightField = player:mem(0x14C, FIELD_WORD)
		if animationWait == 4 then
			Animation.spawn(74, player.x + 0.55*(player.width) + (playerLeftField*(-1*player.width/2.3)) + (playerRightField*(1*player.width/4)), player.y + player.height/2 + 6)
			animationWait = 0
		else
			animationWait = animationWait + 1
		end
		player:mem(0x50, FIELD_WORD, 0)
		wahMoves.animationBuffer = 1
		if player.speedY < 2 then
			player.speedY = player.speedY + 0.05
		else
			player.speedY = 2
		end
	elseif hasJumpedTimer > 0 then
		hasJumpedTimer = hasJumpedTimer - 1
		if playerDirection == 1 then
			player:mem(0xF6, FIELD_WORD, -1)
			playerDirection = -1
		elseif playerDirection == -1 then
			player:mem(0xF8, FIELD_WORD, -1)
		end
	else
		wahMoves.animationBuffer = 0
		wahMoves.animationBuffer = 0
	end
end

function wallSafety()
	if wahMoves.leftHug() then
		playerDirection = 1
	elseif wahMoves.rightHug() then
		playerDirection = -1
	end
end
---section fields for preventing walljumping off section borders
local function wallUpdate()
	playerIsInLocation = player.section
	levelSection = Section(playerIsInLocation)	
	topBoundary = levelSection.boundary.top
	leftBoundary = levelSection.boundary.left
	rightBoundary = levelSection.boundary.right
	bottomBoundary = levelSection.boundary.bottom
	leftCornerBox = colliders.Box(leftBoundary, topBoundary, 2, bottomBoundary - topBoundary)
	rightCornerBox = colliders.Box(rightBoundary - 2, topBoundary, 2, bottomBoundary - topBoundary)
end

function wahMoves.onStart()
	wallUpdate();
end
--- Checks if not touching section borders
local function sectionBorderTouch()
	return not colliders.collide(leftCornerBox, player) and not colliders.collide(rightCornerBox, player)
end

function wahMoves.onTick()
	if playerIsInLocation ~= player.section then	
		wallUpdate();
	end
	--Walljump start here
	if wahMoves.bottomTouch() and sectionBorderTouch() then
		if wahMoves.leftHug() or wahMoves.rightHug() then 
			jumpReady = true
		end
	elseif jumpReady then 
		jumpReady = false
	end
	
	if jumpReady then
		wahMoves.wallSlide();
	end
	
	wallSafety();
	
	playerDirection = player:mem(0x106,FIELD_WORD)
end

function wahMoves.onInputUpdate() 	
	if jumpReady then
		if wahMoves.leftHug() or wahMoves.rightHug() then
			inputs2.locked[1].down = true
			inputs2.locked[1].altrun = true
			if inputs2.state[1].jump == inputs2.PRESS and not inputs2.state[1].altjump ~= inputs2.PRESS then
				if wahMoves.bottomTouch() and math.abs(player.speedX ) == 0.2 then
					player:mem(0x11C, FIELD_WORD, 20)
					player.speedX = playerDirection*-4
					Animation.spawn(75, player.x + 0.55*(player.width)*player:mem(0x106, FIELD_WORD), player.y + player.height/3)
					SFX.play(2)	
					hasJumpedTimer = 1
					wahMoves.animationBuffer = 0
				end
			
			elseif inputs2.state[1].run == inputs2.HOLD and wahMoves.bottomTouch() then
				if playerDirection == -1 then
					player.leftKeyPressing = true
					player.rightKeyPressing = false
				elseif playerDirection == 1 then
					player.rightKeyPressing = true
					player.leftKeyPressing = false
				end
			end
		else
			inputs2.locked[1].down = false
			inputs2.locked[1].altrun = false
		end
	end
end

function wahMoves.onDraw()
	if jumpReady then
		if wahMoves.animationBuffer == 1 then
			--player:mem(0x114, FIELD_WORD, 32)
			if player.powerup == PLAYER_SMALL then
				player:setCurrentSpriteIndex(4, 5, false)
			else
				player:setCurrentSpriteIndex(4, 3, false)
			end
		end
	end
end

return wahMoves