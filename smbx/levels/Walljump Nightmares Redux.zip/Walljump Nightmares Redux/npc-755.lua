local npcManager = require("npcManager")
local particles = require("particles")

local sentinel = {}
local npcID = NPC_ID

local sentinelSettings = {
	id = npcID,
	gfxheight = 32,
	gfxwidth = 32,
	width = 32,
	height = 32,
	gfxoffsetx = 0,
	gfxoffsety = 0,
	frames = 8,
	framestyle = 0,
	framespeed = 8,
	speed = 1,
	npcblock = false,
	npcblocktop = false,
	playerblock = false,
	playerblocktop = false,
	nohurt=false,
	nogravity = false,
	noblockcollision = false,
	nofireball = false,
	noiceball = false,
	noyoshi= false,
	nowaterphysics = false,
	jumphurt = false,
	spinjumpsafe = false,
	harmlessgrab = false,
	harmlessthrown = false,
	grabside=false,
	grabtop=false,
}

npcManager.setNpcSettings(sentinelSettings)

function sentinel.onInitAPI()
	npcManager.registerEvent(npcID, sentinel, "onTickNPC")
	npcManager.registerEvent(npcID, sentinel, "onDrawNPC")
end

function sentinel.onTickNPC(v)
	if Defines.levelFreeze then return end
	
	local data = v.data
	
	if v:mem(0x12A, FIELD_WORD) <= 0 then
		data.initialized = false
		return
	end

	if not data.initialized then
		data.initialized = true
		local settings = data._settings
		data.pattern = settings.behaviour or 0
		data.circleRad = settings.circlingRadius or 1
		data.straightSpeed = settings.straightMovement or 3
		data.straightTimer = 32
		data.swValue = settings.straightWait or 32
		data.straightWait = 0
		data.angleChanger = 0
		data.angle = settings.circleAngle or 0
		data.realAngle = 0
		data.direction = v.direction
	end
	
	if data.pattern == 0 then
		v.speedX = 0
		v.speedY = 0
	elseif data.pattern == 1 then
		if data.angle % 90 == 0 then
			data.direction = data.direction
		end
		if data.direction == -1 then
			data.angle = data.angle + 3
		else
			data.angle = data.angle - 3
		end
		if data.circleRad == 1 then
			data.realAngle = math.rad(data.angle)
			v.speedX = math.cos(data.realAngle) * data.direction * 1.7
			v.speedY = math.sin(data.realAngle) * -1.7
		elseif data.circleRad == 3 then
			data.realAngle = math.rad(data.angle)
			v.speedX = math.cos(data.realAngle) * data.direction * 3.4
			v.speedY = math.sin(data.realAngle) * -3.4
		elseif data.circleRad == 5 then
			data.realAngle = math.rad(data.angle)
			v.speedX = math.cos(data.realAngle) * data.direction * 5
			v.speedY = math.sin(data.realAngle) * -5
		else
			data.realAngle = math.rad(data.angle)
			v.speedX = math.cos(data.realAngle) * data.direction * 6.65
			v.speedY = math.sin(data.realAngle) * -6.65
		end
	elseif data.pattern == 2 then
		if data.angle % 90 == 0 then
			data.direction = data.direction
		end
		if data.direction == -1 then
			data.angle = data.angle + 3
		else
			data.angle = data.angle - 3
		end
		if data.circleRad == 1 then
			data.realAngle = math.rad(data.angle)
			v.speedX = math.cos(data.realAngle) * data.direction * 1.7
			v.speedY = math.sin(data.realAngle) * 1.7
		elseif data.circleRad == 3 then
			data.realAngle = math.rad(data.angle)
			v.speedX = math.cos(data.realAngle) * data.direction * 3.4
			v.speedY = math.sin(data.realAngle) * 3.4
		elseif data.circleRad == 5 then
			data.realAngle = math.rad(data.angle)
			v.speedX = math.cos(data.realAngle) * data.direction * 5
			v.speedY = math.sin(data.realAngle) * 5
		else
			data.realAngle = math.rad(data.angle)
			v.speedX = math.cos(data.realAngle) * data.direction * 6.65
			v.speedY = math.sin(data.realAngle) * 6.65
		end
	elseif data.pattern == 3 then
		if data.straightWait == 0 then
			if data.straightTimer > 0 then
				v.speedY = data.straightSpeed * data.direction
				data.straightTimer = data.straightTimer - 1
			else
				data.straightWait = data.swValue
				data.straightTimer = 32
				data.direction = -data.direction
				v.speedY = 0
			end
		else
			data.straightWait = data.straightWait - 1
		end
	elseif data.pattern == 4 then
		if data.straightWait == 0 then
			if data.straightTimer > 0 then
				v.speedX = data.straightSpeed * data.direction
				data.straightTimer = data.straightTimer - 1
			else
				data.straightWait = data.swValue
				data.straightTimer = 32
				data.direction = -data.direction
				v.speedX = 0
			end
		else
			data.straightWait = data.straightWait - 1
		end
	elseif data.pattern == 5 then
		if data.straightWait == 0 then
			if data.straightTimer > 0 then
				v.speedY = -data.straightSpeed * data.direction
				v.speedX = data.straightSpeed * data.direction
				data.straightTimer = data.straightTimer - 1
			else
				data.straightWait = data.swValue
				data.straightTimer = 32
				data.direction = -data.direction
				v.speedX = 0
				v.speedY = 0
			end
		else
			data.straightWait = data.straightWait - 1
		end
	else
		if data.straightWait == 0 then
			if data.straightTimer > 0 then
				v.speedY = data.straightSpeed * data.direction
				v.speedX = data.straightSpeed * data.direction
				data.straightTimer = data.straightTimer - 1
			else
				data.straightWait = data.swValue
				data.straightTimer = 32
				data.direction = -data.direction
				v.speedX = 0
				v.speedY = 0
			end
		else
			data.straightWait = data.straightWait - 1
		end
	end
end

return sentinel