local player_has_died = false

function onStart()
    player.powerup = 1
    -- restart music where it left off
    local last_audio_pos = GameData.volatile.musicpos
    if last_audio_pos then
      Routine.run(function()
        Routine.waitFrames(2)
        Audio.MusicSetPos(last_audio_pos)
      end)
    end
    for _,c in ipairs(Checkpoint.get()) do
        c.powerup = nil
    end
end

function onTick()
    -- detect player death
    if player:mem(0x13E, FIELD_WORD) > 0 and not player_has_died then
        player_has_died = true
        -- save last audio position in this section on death
        GameData.volatile.musicpos = Audio.MusicGetPos()
    end
    -- npc destroyers
    for _,bgo in ipairs(BGO.get(22)) do
        if not bgo.isHidden then
            for k,v in ipairs(NPC.get()) do
                if Colliders.collide(bgo, v) then
                    v:kill(HARM_TYPE_VANISH)
                    --SFX.play(36)
                    --Animation.spawn(10, v.x, v.y)
                end
            end
        end
    end
end