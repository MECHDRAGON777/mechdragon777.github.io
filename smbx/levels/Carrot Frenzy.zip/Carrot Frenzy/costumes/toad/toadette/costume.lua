-- Toad Costume - Super Mario Maker 2 Toadette (SMW)
-- SpoonyBardOL


local panim = require("playeranim")



local costume = {}

local doswim = 10

function costume.onInit()
	registerEvent(costume, "onTickEnd");
	registerEvent(costume, "onDraw");
end

function costume.onTickEnd()
	doswim = doswim + 1
	local fireball = player:mem(0x160, FIELD_WORD)
	local tail = player:mem(0x164, FIELD_WORD)
	if player.WaterStrokeTimer ~= nil then
		if player.WaterStrokeTimer >= 12 then
			doswim = 0
		end
	end		
	if doswim >= 100 then
		doswim = 30
	end
	if player.IsInWater == -1 and fireball < 30 and tail <= 0 then
		if player.holdingNPC ~= nil then
			if doswim <= 8 then
				panim.setFrame(player,46);
			else
				panim.setFrame(player,45);
			end
		else
			if doswim <= 8 then
				panim.setFrame(player,42);
			elseif doswim >= 9 and doswim <= 16 then
				panim.setFrame(player,43);
			elseif doswim >= 17 and doswim <= 24 then
				panim.setFrame(player,44);
			else
				panim.setFrame(player,41);
			end
		
		end
	end
end

function costume.onDraw()
	for _,v in ipairs(Animation.get(130)) do
		v.width = 60;
		v.height = 46;
	end
end

return costume