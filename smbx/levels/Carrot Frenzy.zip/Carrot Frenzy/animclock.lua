local animatedClock = {}

local imagic = API.load("imagic")

animatedClock.enabled = true
local playerDead = false
local levelComplete = false
animatedClock.seconds = 100
animatedClock.secondsLeft = 100
local frameCount = 0
local x = 170
local y = 18
local handG = Graphics.loadImage(Misc.resolveFile("animclock/hand.png"))
local hand = imagic.Box{x = x+16, y = y+16, width = 2, height = 12, texture = handG}
local clock = Graphics.loadImage(Misc.resolveFile("animclock/clock.png"))
function animatedClock.onInitAPI()
    registerEvent(animatedClock, "onStart", "onStart")
    registerEvent(animatedClock, "onTick", "onTick")
    registerEvent(animatedClock, "onDraw", "onDraw")
end
function animatedClock.onStart()
    hand:Rotate(180)
end
function animatedClock.onTick()
    if levelComplete == false and playerDead == false then
        local newseconds = animatedClock.seconds - math.floor((lunatime.tick()*15.6)/1000)
        if newseconds ~= animatedClock.secondsLeft then
            hand:Rotate(-360/animatedClock.seconds)
        end
        animatedClock.secondsLeft = animatedClock.seconds - math.floor((lunatime.tick()*15.6)/1000)
    end
    if player2 then
        if player2:mem(0x13E,FIELD_WORD) > 0 and player:mem(0x13E,FIELD_WORD) > 0 then
            playerDead = true
        end
    elseif player:mem(0x13E,FIELD_WORD) > 0 then
        playerDead = true
    end
    if animatedClock.secondsLeft == 0 and playerDead == false then
        playerDead = true
        player:kill()
        if player2 then
            player2:kill()
        end
    end
    if Level.winState() > 0 then
        levelComplete = true
    end
end

function animatedClock.onDraw()
    Graphics.drawImageWP(clock, x, y, 5)
    hand:Draw(5)
    Text.print(animatedClock.secondsLeft,  x+16-(string.len(tostring(animatedClock.secondsLeft))*16+(string.len(tostring(animatedClock.secondsLeft))-1))/2, 54)
end
return animatedClock