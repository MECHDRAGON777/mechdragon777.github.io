--[[

||||  O    ||||
|||| /     ||||   walljumps.lua
||||/      ||||
||||\      ||||   By PixelPest
||||/      ||||

]]--

local eventu = API.load("eventu");

local walljumps = {};

walljumps.slideSpeed = 3; --speed when sliding down walls
walljumps.jumpIntensityX = 3; --absolute speed of how fast the player travels along the horizontal axis after walljumping
walljumps.jumpIntensityY = -9; --speed of how fast the player travels along the vertical axis after walljumping
walljumps.delayTime = 0.25 --time (in seconds) that the player has to wait to walljump after making contact with the wall

local isWallSlidingRight = false;
local isWallSlidingLeft = false;
local isWallJumping;
walljumps.canJump = false;
local timerIsSet;

function walljumps.onInitAPI()
	registerEvent(walljumps, "onInputUpdate", "onInputUpdate", false);
end

function walljumps.onInputUpdate()
	if ((isWallSlidingRight) or
	(isWallSlidingLeft)) and
	(player.jumpKeyPressing) and
	(not player.downKeyPressing) and
	(walljumps.canJump) and
	(player:mem(0x34, FIELD_WORD) ~= 2) then
		playSFX(2);
		player.speedY = walljumps.jumpIntensityY;
		isWallJumping = true;
		walljumps.canJump = false;
	
		if isWallSlidingRight then
			player.speedX = (-1)*walljumps.jumpIntensityX;
			Animation.spawn(75, player.x + 0.5*(player.width), player.y + player.height - 16);
		elseif isWallSlidingLeft then
			player.speedX = walljumps.jumpIntensityX;
			Animation.spawn(75, player.x - 0.5*(player.width), player.y + player.height - 16);
		end
	end
	
	if (player:mem(0x146, FIELD_WORD) == 0) and
	(player:mem(0x14A, FIELD_WORD) == 0) and
	(((player:mem(0x148, FIELD_WORD) == 2) or
	(player:mem(0x14C, FIELD_WORD) == 2)) or
	((player:mem(0x148, FIELD_WORD) == 2) and
	(player:mem(0x14C, FIELD_WORD) == 2))) and
	((player.rightKeyPressing) or
	(player.leftKeyPressing)) and
	(not player.downKeyPressing) and
	(player:mem(0x34, FIELD_WORD) ~= 2) and --is not underwater/quicksand
	(player:mem(0x50, FIELD_BOOL) ~= true) and --is not spinjumping
	(not jumpKeyPressing) then
		if (not isWallSlidingLeft) and (not isWallSlidingRight) and (not timerIsSet) then
			eventu.setTimer(walljumps.delayTime, reset, false);
			timerIsSet = true;
			walljumps.canJump = false;
		end
			
		if player:mem(0x148, FIELD_WORD) == 2 then
			isWallSlidingLeft = true;
			isWallSlidingRight = false;
	
			if player.speedY > 0 then
				Animation.spawn(74, player.x - 8, player.y + 0.5*(player.height + 8));
			end
		elseif player:mem(0x14C, FIELD_WORD) == 2 then
			isWallSlidingRight = true;
			isWallSlidingLeft = false;

			if player.speedY > 0 then
				Animation.spawn(74, player.x + player.width, player.y + 0.5*(player.height + 8));
			end
		end
	
		if (player.speedY > 0) and (not player.downKeyPressing) then
			player.speedY = walljumps.slideSpeed;
		end
	else
		isWallSlidingRight = false;
		isWallSlidingLeft = false;
	end

	if player:mem(0x146, FIELD_WORD) == 2 then
		isWallJumping = false;
		walljumps.canJump = false;
	end
end

function reset()
	timerIsSet = false;
	walljumps.canJump = true;
end

return walljumps