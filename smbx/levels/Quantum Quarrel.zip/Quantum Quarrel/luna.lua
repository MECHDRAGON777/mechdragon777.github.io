--By Novarender, for MECHDRAGON

local lightningEdge = require("lightningEdge")
local backgroundcode = require("backgroundcode")
local tilesetShader = require("tilesetShader")
-- local falseWrap = require("falseWrap")

function onStart()
	if player.powerup == 1 then
		player.powerup = 2
	end
end
--CHANGE THESE: ------------------

local waveH --Horizontal screen waving effect
local waveV --Horizontal screen waving effect
local doAutoscroll

function onTick()
	local section = player.section+1 --0 based
	
	if section == 1 then
		waveH = false
		waveV = true
		doAutoscroll = false
	elseif section == 2 then
		waveH = true
		waveV = false
		doAutoscroll = false
	else 
		waveH = false
		waveV = false
		doAutoscroll = true
	end
	--So on...
end

-- ==== ## %$% ## ==== --

local directions = {
	[191] = vector(0, -1),
	[192] = vector(0, 1),
	[193] = vector(-1, 0),
	[194] = vector(1, 0),
	[195] = vector(-1, -1),
	[196] = vector(1, -1),
	[197] = vector(1, 1),
	[198] = vector(-1, 1)
}
local forcedStatesPass = table.map{0,3,6,7,9,10}
local noWrapEffects = table.map{3, 5, 9, 129, 130, 134}

local wave = 1.5*math.pi
local cameraData = {}


local function move(obj, distX, distY)
	obj.x = obj.x + distX
	obj.y = obj.y + distY
end
local function moveAll(class, args)
	for _,v in ipairs(class.getIntersecting(args.x, args.y, args.x2, args.y2)) do
		move(v, args.distX, args.distY)
	end
end
local function moveBlocks(args)
	for _,v in Block.iterateIntersecting(args.x, args.y, args.x2, args.y2) do
		for _,n in NPC.iterateIntersecting(v.x, v.y - 2, v.x + v.width, v.y) do
			if not NPC.config[n.id].nogravity then
				move(n, args.distX, args.distY)
				n.spawnX = n.spawnX + args.distX
				n.spawnY = n.spawnY + args.distY
			end
		end
		v:translate(args.distX, args.distY)
	end
end
local function moveNPCs(args)
	for _,v in NPC.iterateIntersecting(args.x, args.y, args.x2, args.y2) do
		if not NPC.config[v.id].nogravity then
			for _,b in Block.iterateIntersecting(v.x, v.y + v.height, v.x + v.width, v.y + v.height + 2) do
				b:translate(args.distX, args.distY)
			end
		end
		move(v, args.distX, args.distY)
		v.spawnX = v.spawnX + args.distX
		v.spawnY = v.spawnY + args.distY
	end
end
local function moveEffects(args)
	for _,v in ipairs(Animation.getIntersecting(args.x, args.y, args.x2, args.y2)) do
		if not noWrapEffects[v.id] then
			move(v, args.distX, args.distY)
		end
	end
end
local function moveWarps(args)
    for _,v in ipairs(Warp.getIntersectingEntrance(args.x, args.y, args.x2, args.y2)) do
        v.entranceX = v.entranceX + args.distX
        v.entranceY = v.entranceY + args.distY
    end
    for _,v in ipairs(Warp.getIntersectingExit(args.x, args.y, args.x2, args.y2)) do
        v.exitX = v.exitX + args.distX
        v.exitY = v.exitY + args.distY
    end
end

local function moveSectionContent(args) --Moves all blocks, npcs, BGOs, liquids, warps, etc. in the area given to the other side of the section and resets section boundary as appropriate.
	moveBlocks(args)
	moveNPCs(args)
	moveAll(BGO, args)
	moveAll(Player, args)
	moveAll(Liquid, args)
	moveEffects(args)
	moveWarps(args)
end

local function checkForMove (cam, section)
	local origBounds = section.origBoundary
	local bounds = section.boundary
	local sectionWidth = bounds.right - bounds.left
	local sectionHeight = bounds.bottom - bounds.top

	local modX = 0
	local modY = 0

	if cam.x + cam.width > origBounds.right then
		modX = cam.x + cam.width - origBounds.right
	end
	if cam.y + cam.height > origBounds.bottom then
		modY = cam.y + cam.height - origBounds.bottom
	end

	bounds.left = origBounds.left + modX
	bounds.right = origBounds.right + modX
	bounds.top = origBounds.top + modY
	bounds.bottom = origBounds.bottom + modY
	section.boundary = bounds

	if section.wrapH then
		x = bounds.left - cam.width - 32
		y = origBounds.top
		moveSectionContent {
			x = x, y = y,
			x2 = cam.width + x + 32, y2 = sectionHeight + cam.height + y,
			distX = sectionWidth, distY = 0
		}
		x = bounds.right + 32
		moveSectionContent {
			x = x, y = y,
			x2 = cam.width + x + 32, y2 = sectionHeight + cam.height + y,
			distX = -sectionWidth, distY = 0
		}
	end
	if section.wrapV then
		x = origBounds.left
		y = bounds.top - cam.height - 32
		moveSectionContent {
			x = x, y = y,
			x2 = sectionWidth + cam.width + x, y2 = cam.height + y + 32,
			distX = 0, distY = sectionHeight
		}
		y = bounds.bottom + 32
		moveSectionContent {
			x = x, y = y,
			x2 = sectionWidth + cam.width + x, y2 = cam.height + y + 32,
			distX = 0, distY = -sectionHeight
		}
	end
end
-- ////////// --------- ////#//// ----

function onCameraUpdate()
	if Misc.isPaused() then return end
	local cameraMove = forcedStatesPass[player.forcedState] --Freeze the camera while transforming...

	--Init ---
	if not cameraData[camera] then 
		cameraData[camera] = {
			section = player.section,
			oldX = camera.x, oldY = camera.y,
			scrollX = camera.x, scrollY = camera.y,
			scrollDir = directions[194],
			scrollSpeed = 1
		} 
		wave = 1.5*math.pi
	end
	local d = cameraData[camera]

	if player.section ~= d.section then
		cameraData[camera] = nil
		return
	end

	if doAutoscroll then
		--Do camera movement -

		local totalDir = vector(0, 0)
		local changed = false
		for _,b in ipairs(BGO.get{191,192,193,194,195,196,197,198,199,221,222}) do --Accepting redirector input
			local db = b.data
			if b.layerName == "cameraStart" then
				if not db.alreadySnapped then
					d.scrollX = b.x + b.width/2
					d.scrollY = b.y + b.height/2
					db.alreadySnapped = true
				end
			else
				-- if b.x == -159904 then Misc.dialog(d.scrollX, d.scrollY, d.scrollSpeed, b.x, b.y, b.width, b.height, d.scrollX > b.x + 15.5 - d.scrollSpeed, d.scrollX < b.x + b.width - 15.5 + d.scrollSpeed, d.scrollY > b.y + 15.5 - d.scrollSpeed, d.scrollY < b.y + b.height - 15.5 + d.scrollSpeed) end
				if d.scrollX > b.x + 15.5 - d.scrollSpeed and d.scrollX < b.x + b.width - 15.5 + d.scrollSpeed and 
					d.scrollY > b.y + 15.5 - d.scrollSpeed and d.scrollY < b.y + b.height - 15.5 + d.scrollSpeed
				then
					if not db.alreadySnapped then
						d.scrollX = b.x + b.width/2
						d.scrollY = b.y + b.height/2
						db.alreadySnapped = true
					end

					local dir = directions[b.id]
					if dir then
						totalDir = totalDir + dir
						changed = true
					elseif b.id == 221 then --Speed up
						d.scrollSpeed = d.scrollSpeed + 0.12
					elseif b.id == 222 then
						d.scrollSpeed = d.scrollSpeed - 0.12
						-- if d.scrollSpeed < 0 then d.scrollSpeed = 0 end --Can enable if you want
					elseif b.id == 199 then --Stop
						scroll = vector(0, 0)
						break
					end
				else
					db.alreadySnapped = false
				end
			end
		end
		-- for _,b in BGO.iterateIntersecting(d.scrollX, d.scrollY, d.scrollX + 1, d.scrollY + 1) do --Accepting redirector input
		-- 	local dir = directions[b.id]
		-- 	if dir then
		-- 		totalDir = totalDir + dir
		-- 		changed = true
		-- 	elseif b.id == 221 then --Speed up
		-- 		d.scrollSpeed = d.scrollSpeed + 0.01
		-- 	elseif b.id == 222 then
		-- 		d.scrollSpeed = d.scrollSpeed - 0.01
		-- 	elseif b.id == 199 then --Stop
		-- 		scroll = vector(0, 0)
		-- 		break
		-- 	end
		-- end
		--if player.keys.down then Misc.dialog(d.scrollSpeed) end
		-- for _,b in BGO.iterateIntersecting(d.scrollX, d.scrollY, d.scrollX + 1, d.scrollY + 1) do --Accepting redirector input
			
			
			
		-- end
		if changed then d.scrollDir = totalDir:normalise() end

		if cameraMove then
			d.scrollX = d.scrollX + d.scrollDir.x*d.scrollSpeed
			d.scrollY = d.scrollY + d.scrollDir.y*d.scrollSpeed
		end
	end

	if cameraMove then	wave = wave + 0.004  end
	local wFact = 0
	local wH = 0
	local wV = 0
	if waveH then 
		wFact = wFact + 400
		wH = math.sin(wave) + 1
	end
	if waveV then 
		wFact = wFact + 300
		wV = math.sin(wave) + 1
	end

	if doAutoscroll then
		camera.x = d.scrollX + wH*wFact
		camera.y = d.scrollY + wV*wFact
	else
		if waveH then
			camera.x = d.scrollX + wH*wFact
		else
			camera.x = player.x + player.width/2 - 400
			d.scrollX = camera.x
		end
		if waveV then
			camera.y = d.scrollY + wV*wFact
		else
			camera.y = player.y + player.height - 32 - 300
			d.scrollY = camera.y
		end
	end
	
	drawCameraWrapped(camera, player.sectionObj)
	trapPlayer(player, camera)
end

function drawCameraWrapped(cam, section)
	local bounds = section.origBoundary
	local wrapH = section.wrapH
	local wrapV = section.wrapV
	local sectionWidth = bounds.right - bounds.left
	local sectionHeight = bounds.bottom - bounds.top

	local d = cameraData[cam] 
	
	if camera.x < bounds.left then
		if wrapH then
			camera.x = camera.x + sectionWidth
			d.scrollX = d.scrollX + sectionWidth
		else
			camera.x = bounds.left
			d.scrollX = bounds.left
		end
	elseif wrapH then
		if camera.x > bounds.right then --Accounting for extended boundary
			camera.x = camera.x - sectionWidth
			d.scrollX = d.scrollX - sectionWidth
		end
	else
		if camera.x + camera.width > bounds.right then
			camera.x = bounds.right - camera.width
			d.scrollX = bounds.right - camera.width
		end
	end
	-- Misc.dialog("boundary:", bounds)
	if camera.y < bounds.top then
		-- Misc.dialog("top")
		if wrapV then
			camera.y = camera.y + sectionHeight
			d.scrollY = d.scrollY + sectionHeight
		else
			camera.y = bounds.top
			d.scrollY = bounds.top
		end
	elseif wrapV then
		if camera.y > bounds.bottom then --Accounting for extended boundary
			camera.y = camera.y - sectionHeight
			d.scrollY = d.scrollY - sectionHeight
		end
	else
		if camera.y + camera.height > bounds.bottom then --Accounting for extended boundary
			camera.y = bounds.bottom - camera.height
			d.scrollY = bounds.bottom - camera.height
		end
	end

	checkForMove(cam, section)
end

function trapPlayer(p, cam)
	local d = cameraData[camera]

	if p.x < cam.x then					 --Left boundary
		p.x = cam.x
		p.speedX = math.max(d.scrollDir.x*d.scrollSpeed, p.speedX)
		p:mem(0x148, 2, 1) --Left collision
	end
	if p.x + p.width > cam.x + cam.width then  --Right boundary
		p.x = cam.x + cam.width - p.width
		p.speedX = math.min(d.scrollDir.x*d.scrollSpeed, p.speedX)
		p:mem(0x14C, 2, 1) --Right collision
	end
	if p.y < cam.y then					 --Top boundary
		p.y = cam.y
		p.speedY = math.max(d.scrollDir.y*d.scrollSpeed, p.speedY)
		p:mem(0x14A, 2, 1) --Top collision
	end
	if p.y + p.height > cam.y + cam.height then  --Bottom boundary
		p.y = cam.y + cam.height - p.height
		p.speedY = math.min(d.scrollDir.y*d.scrollSpeed, p.speedY)
		p:mem(0x146, 2, 1) --Bottom collision
	end
end