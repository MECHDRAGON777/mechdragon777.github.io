local lightningEdge = {}

--By Novarender for MECHDRAGON

function lightningEdge.onInitAPI()
	registerEvent(lightningEdge, "onDraw")
end


local sprite = {}
local frameTimer = 0
for i = 1, 8 do
	sprite[i] = Graphics.loadImageResolved("lightning".. i ..".png")
end

local gfx = {}
local killH
local killV


--CHANGE THE FOLLOWING: --=====
local marginX = -12 --Pixel gap between the lightning and the screen edge
local marginY = -12

local function doChecks(section)
	local oldKH, oldKV, oldMX, oldMY = killH, killV, marginX, marginY

	if section == 1 then
		killH = false
		killV = true
	elseif section == 2 then
		killH = true
		killV = false
	elseif section == 3 then
		killH = true
		killV = true
	end
	

	if killH ~= oldKH or killV ~= oldKV or oldMX ~= marginX or oldMY ~= marginY then
		lightningEdge.assembleGFX(killH, killV, marginX, marginY)
	end	
end

local playerDead = {}

local function kill(p) 
	if not playerDead[p] then 
		p:kill()
		playerDead[p] = true
	end
end

local function drawTo(target, posX, posY, width, height, texture, frame)
    local y = frame/2
	local y2 = y+0.5

	Graphics.drawBox{
		x = posX, y = posY, width = width, height = height,
		textureCoords={0,y,1,y,1,y2,0,y2},
        target = target, texture = texture
    }
end

function lightningEdge.onDraw()
	doChecks(player.section+1) --Offset by 1 because player.section uses 0 indexing

	local p = player
	local cam = camera
	local offsetX = marginX+14 --To account for the lighning graphics themselves
	local offsetY = marginY+14

	if killH then
		if p.x < cam.x + offsetX then					 --Left boundary
			if p.deathTimer == 0 then kill(p) end
		end
		if p.x + p.width > cam.x + cam.width - offsetX then  --Right boundary
			if p.deathTimer == 0 then kill(p) end
		end
	end
	if killV then
		if p.y < cam.y + offsetY then					  --Top boundary
			if p.deathTimer == 0 then kill(p) end
		end
		if p.y + p.height > cam.y + cam.height - offsetY then  --Bottom boundary
			if p.deathTimer == 0 then kill(p) end
		end
	end

	local frame = math.floor(frameTimer/12)%2+1
	Graphics.drawBox{texture=gfx[frame], x=0,y=0,width=camera.width,height=camera.height}

	frameTimer = frameTimer + 1
end

function lightningEdge.assembleGFX(h, v, marginX, marginY) --Blocks is the number of blocks that it WILL be away from the screen, the rest will be a partial amount
	local blocksX = marginX/32
	local blocksY = marginY/32
	local LEFT_EDGE = marginX
	local RIGHT_EDGE = camera.width - marginX - 32
	local TOP_EDGE = marginY
	local BOTTOM_EDGE = camera.height - marginY - 32

	for i = 1, 2 do --Number of frames
		local scr = Graphics.CaptureBuffer(camera.width, camera.height)
		
		local modX = math.ceil(blocksX)*-32 --Sides' start offset
		local modY = math.ceil(blocksY)*-32
		local amountX = math.ceil(camera.width/32 + blocksX)*32
		local amountY = math.ceil(camera.height/32 + blocksY)*32
		local scaleX = 1
		local scaleY = 1

		if h then
			if v then --Corner case: draws the corners lol
				drawTo(scr, LEFT_EDGE,  TOP_EDGE,  32, 32, sprite[8], i-1)
				drawTo(scr, RIGHT_EDGE, TOP_EDGE,  32, 32, sprite[2], i-1)
				drawTo(scr, RIGHT_EDGE, BOTTOM_EDGE, 32, 32, sprite[4], i-1)
				drawTo(scr, LEFT_EDGE,  BOTTOM_EDGE, 32, 32, sprite[6], i-1)

				modX = 32 --To account for the corners
				modY = 32
				amountX = RIGHT_EDGE - LEFT_EDGE - modX*2 --modX*2 to account for both margins
				amountY = BOTTOM_EDGE - TOP_EDGE - modY*2

				local aX = math.floor(amountX/32)*32
				local aY = math.floor(amountY/32)*32
				scaleX = (amountX - aX)/aX + 1 --Simplified from: remainder of a block that's leftover from rounding, divided by the total number of blocks that will stretch -> to get the # of pixels needed from stretching per block, /32 to convert that to a scale
				scaleY = (amountY - aY)/aY + 1
			end
		end

		if h then
			local start = TOP_EDGE + modY
			
			for y = start, start + amountY + 0.001, scaleY*32 do --Compensating for rounding errors
				drawTo(scr, LEFT_EDGE,  y, 32, scaleY*32, sprite[7], i-1)
				drawTo(scr, RIGHT_EDGE, y, 32, scaleY*32, sprite[3], i-1)
			end
		end
		if v then
			local start = LEFT_EDGE + modX
			for x = start, start + amountX + 0.001, scaleX*32 do
				drawTo(scr, x, TOP_EDGE,    scaleX*32, 32, sprite[1], i-1)
				drawTo(scr, x, BOTTOM_EDGE, scaleX*32, 32, sprite[5], i-1)
			end
		end

		gfx[i] = scr
	end
end

return lightningEdge