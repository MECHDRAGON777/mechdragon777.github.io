--Made by Core
--Improved by Novarender

local npcManager = require("npcManager")
local imagic = require("imagic")
local npcutils = require("npcs/npcutils")

local npc = {credits="Core, Novarender", special="Celeste Bubbles"}
local npcID = NPC_ID

local npcSettings = {
	id = npcID,
	gfxheight = 64,
	gfxwidth = 64,
	gfxoffsetx = 0,
	gfxoffsety = 16,	
	width = 32,
	height = 32,
	frames = 2,
	framestyle = 0,
	framespeed = 8,
	speed = 1,
	nohurt=true,
	nogravity = true,
	noblockcollision = false,
	nofireball = true,	
    noiceball = true,
	noyoshi= true,
	nowaterphysics = true,
	jumphurt=true,
	score = 0,
	foreground=1,
	timer = 80
}
local config = npcManager.setNpcSettings(npcSettings)

npcManager.registerDefines(npcID, {NPC.HITTABLE})

function npc.onInitAPI()
	npcManager.registerEvent(npcID, npc, "onDrawNPC")	
end

local function death(v)
	SFX.play("orb_end.wav")	
	local data = npc.checkData(v)
	if not data then return end
	
	for _,p in ipairs(data.c) do
        if data.yV <= 0 then 
		    p:mem(0x11C,FIELD_WORD,-1)
		    p.speedY = -7 
		end;
    end	
    data.s:stop()
	Defines.earthquake = 8
	local i = 0
	repeat
	    i = i + 1
	    Effect.spawn(752, data.realX + v.width/math.random(4,2), data.realY + v.height/math.random(4,2))
    until i > 4	
    v:kill()    
end

-- function npc.popFromPlayer(p) --Embrace the jank :gdicloudigit:
-- 	for _,v in ipairs(npcID) do
-- 		if v.data.c[1] == p then
-- 			death(v)
-- 			return
-- 		end
-- 	end
-- end

local function respawn(v)
	local x,y,width,height, section = v:mem(0xA8, FIELD_DFLOAT), v:mem(0xB0, FIELD_DFLOAT), v.width, v.height, v:mem(0x146, FIELD_WORD)
	
	Effect.spawn(753, x-(width/2.15), y-(height/2.15))
	Routine.waitSeconds(2)
	SFX.play("orb_spawn.wav")
	local i = 0
	repeat
	    i = i + 1
	    Effect.spawn(752, x + width/math.random(4,2), y + height/math.random(4,2))
    until i > 4	
	local respawned = NPC.spawn(NPC_ID,x,y,section)
	respawned.ai1 = 0
    respawned.direction = -1
end

function npc.initBubble(p, v)
	local data = v.data
	Defines.earthquake = 7
	SFX.play("orb_enter.wav")
	v.ai1 = 1
	v.ai5 = p.direction*0.5+1.5 --Default direction is player facing direction
	data.realX = v.x
	data.realY = v.y
	data.wobble = vector(p.speedX, p.speedY):normalise()
	data.wS = 0
	table.insert(data.c,p)
end

function npc.runMain(v)
	local data = npc.checkData(v)
	if not data then return end

	if data.wobble then
		data.realX = data.realX + data.xV
		data.realY = data.realY + data.yV
		v.x = data.realX + data.wobble.x*math.sin(data.wS)*16
		v.y = data.realY + data.wobble.y*math.sin(data.wS)*16
		data.wS = data.wS*0.97 + 0.2
	else
		data.realX = v.x
		data.realY = v.y
	end
	
	if v.ai1 == 0 then
    	for _,p in ipairs(Player.getIntersecting(v.x,v.y,v.x+v.width,v.y+v.height)) do
			npc.initBubble(p, v)
			break
	    end
	end
	
	if v.ai1 == 1 then
	    v.ai3 = v.ai3 + 3
	    if v.ai3 < 50 then
	        v.ai2 = v.ai2 + 0.04
		elseif v.ai3 > 50 and v.ai2 > 1.5 then
	        v.ai2 = v.ai2 - 0.06	
		elseif v.ai3 > config.timer then
		    SFX.play("orb_dash.wav")
			data.s = SFX.play("orb_loop.wav",1,0)
			Defines.earthquake = 5
			local i = 0
		    repeat
	            i = i + 1
	            Effect.spawn(752, data.realX + v.width/math.random(4,2), data.realY + v.height/math.random(4,2))
            until i > 3	
            Routine.run(respawn, v)			
			v.ai1 = 2
		end
		if v.ai2 < 1.5 then
		    v.ai2 = 1.5
		end
	    for _,p in ipairs(data.c) do
            if p.keys.left == true and p.keys.up == false and p.keys.down == false  then
				v.ai5 = 1 				
			elseif p.keys.right == true and p.keys.up == false and p.keys.down == false then
			    v.ai5 = 2
			elseif p.keys.down == true and p.keys.left == false and p.keys.right == false then
			    v.ai5 = 3
			elseif p.keys.up == true and p.keys.left == false and p.keys.right == false then
			    v.ai5 = 0
            elseif p.keys.left == true and p.keys.up == KEYS_DOWN then
				v.ai5 = 4
            elseif p.keys.left == true and p.keys.down == KEYS_DOWN then
				v.ai5 = 6
            elseif p.keys.right == true and p.keys.up == KEYS_DOWN then
				v.ai5 = 5
            elseif p.keys.right == true and p.keys.down == KEYS_DOWN then
				v.ai5 = 7				
			end
		end			
	elseif v.ai1 == 2 then
		Effect.spawn(751, data.realX + v.width/math.random(4,0.5), data.realY + v.height/math.random(4,0.5))
		
	    if v.ai5 == 0 then
		    data.yV = -7.5 * config.speed
		elseif v.ai5 == 1 then
		    data.xV = -7.5 * config.speed	
		elseif v.ai5 == 2 then
		    data.xV = 7.5 * config.speed
		elseif v.ai5 == 3 then
		    data.yV = 7.5 * config.speed
		elseif v.ai5 == 4 then
		    data.yV = -7.5 * config.speed
			data.xV = -7.5 * config.speed
		elseif v.ai5 == 5 then
		    data.yV = -7.5 * config.speed
			data.xV = 7.5 * config.speed
		elseif v.ai5 == 6 then
		    data.yV = 7.5 * config.speed
			data.xV = -7.5 * config.speed
		elseif v.ai5 == 7 then
		    data.yV = 7.5 * config.speed
			data.xV = 7.5 * config.speed 		
        end		
        if v.collidesBlockUp or v.collidesBlockBottom or v.collidesBlockLeft or v.collidesBlockRight then
			Routine.run(death, v)			
		end	
		if v.data.c[1]:mem(0x146, FIELD_DFLOAT) ~= 0 then --Hackiest way ever to test for any player collision (uses DFLOAT to cover all 4 mem offsets for block collision)
			Routine.run(death, v)			
		end

		local sec = Section.get(v:mem(0x146, 2)+1)
		local secB = sec.boundary		--I don't really care about making spaghetti code because I mean, look around you
		if data.realX + v.width < secB.left then
			if sec.wrapH then
				data.realX = secB.right
			else
				Routine.run(death, v)	
			end
		elseif data.realX > secB.right then
			if sec.wrapH then
				v.realX = secB.left - v.width
			else
				Routine.run(death, v)	
			end
		end
		if data.realY + v.height < secB.top then
			if sec.wrapV then
				data.realY = secB.bottom
			else
				Routine.run(death, v)	
			end
		elseif data.realY > secB.bottom then
			if sec.wrapV then
				data.realY = secB.top - v.height
			else
				Routine.run(death, v)	
			end
		end

        v.ai4 = v.ai4 + 12
	    for _,p in ipairs(data.c) do
            if (p.keys.jump) or (p.keys.altJump) then
				SFX.play("orb_dash.wav")	
                Routine.run(death, v)	               				
			elseif v.collidesBlockBottom then
			    Routine.run(death, v)
				p.y=p.y-p.height/0.75	
			end
			if p:mem(0x13E,FIELD_WORD) > 0 then	
			    Routine.run(death, v)
			end
        end		
        for k,n in ipairs(Colliders.getColliding{
        a = v.id,
        atype = Colliders.NPC,
        b = v.id,
        btype = Colliders.NPC
        }) do
		    local a = n[1]
            if a.ai1 > 1 then
				Routine.run(death, v)		
				npc.initBubble(data.c[1], a)
			end
        end	
        for k,n in ipairs(Colliders.getColliding{
        a = v.id,
        atype = Colliders.NPC,
        b = 457,
        btype = Colliders.NPC
        }) do
		    local a = n[1]
            if a.ai1 > 1 then
			    if a.ai5 == 7 or a.ai5 == 6 or a.ai5 == 3 then
				    a.ai5 = 0
                end				
			end
        end		
        for k,n in ipairs(Colliders.getColliding{
        a = v.id,
        atype = Colliders.NPC,
        b = 458,
        btype = Colliders.NPC
        }) do
		    local a = n[1]
            if a.ai1 > 1 then
			    if a.ai5 == 2 then
				    a.ai5 = 1
                elseif a.ai5 == 1 then
                    a.ai5 = 2
				elseif a.ai5 == 5 then 
				    a.ai5 = 4
				elseif a.ai5 == 4 then
				    a.ai5 = 5
				elseif a.ai5 == 6 then
				    a.ai5 = 7
				elseif a.ai5 == 7 then
				    a.ai5 = 6
                end				
			end
        end	
    elseif v.ai1 == 0 then
        v:mem(0x12A,FIELD_WORD, 180)
	end
	
	for _,p in ipairs(data.c) do
	    p.x = data.realX
		p.y = data.realY
		p.frame = -48
	end
end

function npc.onDrawNPC(v)
	if not Misc.isPaused() then npc.runMain(v) end
    if (v:mem(0x128, FIELD_BOOL)) then return end
	
	local data = npc.checkData(v)
	if not data then return end

	imagic.Draw{texture = Graphics.loadImage("npc-751.png"),
	sourceWidth = 64,
	sourceHeight = 64,
	sourceY = config.gfxheight * v.animationFrame,
	width = config.gfxwidth * math.sin(v.ai2),
	height = config.gfxheight * math.sin(v.ai2),
	x = v.x+v.width/2,
	y = v.y+v.height/2,
	scene = true,
	align = imagic.ALIGN_CENTRE,
	priority = -5}
	--Draw "player"
	if v.ai1 > 0 then
	    imagic.Draw{texture = Graphics.loadImage("npc-751.png"),
	    sourceWidth = 64,
	    sourceHeight = 64,
	    sourceY = config.gfxheight * (config.frames + 1),
	    width = config.gfxwidth * math.sin(v.ai2),
	    height = config.gfxheight * math.sin(v.ai2),
	    x = v.x+v.width/2,
	    y = v.y+v.height/2,
	    scene = true,
	    rotation = v.ai4 * v.direction,
	    align = imagic.ALIGN_CENTRE,
	    priority = -4}		
	end
	npcutils.hideNPC(v)	
end

function npc.checkData(v)
	local data = v.data
	if v:mem(0x12A, FIELD_WORD) <= 0 then
		data.initialized = false
		return false
	end
	
	if not data.initialized then
	    v.ai1 = 0
		v.ai2 = 1.5
		v.ai3 = 1
		v.ai4 = 0
		v.ai5 = 0
		data.c = {}
		data.s = {}
		data.xV = 0
		data.yV = 0
		data.initialized = true
	end

	return data
end

return npc