local backgroundcode = {}

local base = Graphics.loadImage(Misc.resolveFile("background base.png"))
local bg1 = Graphics.loadImage(Misc.resolveFile("background 1.png"))
local bg2 = Graphics.loadImage(Misc.resolveFile("background 2.png"))
local offset = 0


function backgroundcode.onDraw()
	offset = offset + 1
	Graphics.drawImageWP(base, 0, 0, -100)
	Graphics.drawImageWP(bg1, ((offset%800)-800), 0, -99.9)
	Graphics.drawImageWP(bg2, ((-1*(offset%800))), 0, -99.9)
end

function backgroundcode.onInitAPI()
	registerEvent(backgroundcode, "onDraw")
end

return backgroundcode