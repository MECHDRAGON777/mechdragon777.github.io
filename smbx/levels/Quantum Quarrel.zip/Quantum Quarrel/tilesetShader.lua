local tilesetShader = {}

local effectShader = Shader()
effectShader:compileFromFile(nil,Misc.resolveFile("effectThing.frag"))

local frontBuffer = Graphics.CaptureBuffer(800,600)
local backBuffer  = Graphics.CaptureBuffer(800,600)

local effectImages = {}
for i=1,2 do
    effectImages[i] = Graphics.loadImageResolved("effect".. i.. ".png")
end

function tilesetShader.onCameraDraw(camIdx)
    if camIdx ~= 1 then return end

    frontBuffer:captureAt(-64)
    backBuffer:captureAt(-66)

    for index,texture in ipairs(effectImages) do
        local offset = vector(lunatime.tick()/8)

        if (index%2) == 0 then
            offset = -offset
        end

        offset = offset + vector(camera.x,camera.y)

        offset.x = (offset.x%texture.width )
        offset.y = (offset.y%texture.height)

        local x = -offset.x
        while (x < 800) do
            local y = -offset.y

            while (y < 600) do
                Graphics.drawBox{
                    texture = texture,target = backBuffer,priority = -66,
                    x = x,y = y,
                }

                y = y + texture.height
            end

            x = x + texture.width
        end
    end

    --Graphics.drawScreen{texture = effectBuffer,priority = 5}
    Graphics.drawScreen{
        priority = -64,
        shader = effectShader,
        uniforms = {
            front = frontBuffer,
            back = backBuffer,
        }
    }
end

function tilesetShader.onInitAPI()
	registerEvent(tilesetShader, "onCameraDraw")
end

return tilesetShader