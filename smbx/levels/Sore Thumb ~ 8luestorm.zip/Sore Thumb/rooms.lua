--[[

    rooms.lua
    by MrDoubleA


    Thanks to Enjl for a bit of help on making respawning NPCs actually work


    TO DO:
    - Fix oddly spawning reserve items

]]

local checkpoints = require("checkpoints")
local switch = require("blocks/ai/synced")

local rooms = {}

-- Declare constants
rooms.TRANSITION_TYPE_NONE     = 0
rooms.TRANSITION_TYPE_CONSTANT = 1
rooms.TRANSITION_TYPE_SMOOTH   = 2

rooms.RESPAWN_EFFECT_FADE    = 0
rooms.RESPAWN_EFFECT_MOSAIC  = 1
rooms.RESPAWN_EFFECT_DIAMOND = 2

rooms.CAMERA_STATE_NORMAL     = 0
rooms.CAMERA_STATE_TRANSITION = 1

rooms.rooms = {}

rooms.currentRoomIndex = nil
rooms.enteredRoomPos = nil
rooms.startPos = nil

rooms.cameraInfo = {
    state = rooms.CAMERA_STATE_NORMAL,
    startPos = nil,transitionPos = nil,
}

rooms.respawnTimer = nil
rooms.resetTimer = 0

rooms.npcRespawnExceptions = {[192] = true,[400] = true,[430] = true}

rooms.snakeBlocks = {[344] = true}

local colBox = Colliders.Box(0,0,0,0)

local blockInfoFields = {"layerName","contentID","isHidden","id","x","y"}
rooms.savedBlockInfo = {}

local function boundCamToRoom(room)
    return math.clamp(camera.x,room.collider.x,room.collider.x+room.collider.width-camera.width),math.clamp(camera.y,room.collider.y,room.collider.y+room.collider.height-camera.height)
end

local function resetDefeatedNPCs()
    for _,v in ipairs(NPC.get()) do
        if not v.isGenerator then
            local roomData = v.data._rooms

            if roomData then
                roomData.defeated = false
            end
        end
    end
end

local function resetNPC(v)
    if v:mem(0xDC,FIELD_WORD) == 0 then return end -- Cancel for enemies that don't respawn

    v.id = v.spawnId

    v.x,v.y = v.spawnX,v.spawnY
    v.width,v.height = v.spawnWidth,v.spawnHeight
    v.speedX,v.speedY = v.spawnSpeedX,v.spawnSpeedY

    v.direction = v.spawnDirection
    
    v.ai1,v.ai2 = v.spawnAi1,v.spawnAi2
    v.ai3,v.ai4,v.ai5 = 0,0,0

    v.collidesBlockLeft = false
    v.collidesBlockRight = false
    v.collidesBlockUp = false
    v.collidesBlockBottom = false

    v.animationFrame,v.animationTimer = 0,0

    v:mem(0x138,FIELD_WORD,0)

    if v:mem(0x12C,FIELD_WORD) > 0 then
        Player(v:mem(0x12C,FIELD_WORD)):mem(0x154,FIELD_WORD,0)

        v:mem(0x12C,FIELD_WORD,0)
    end
end

local buffer = Graphics.CaptureBuffer(800,600)

local mosaicShader = Shader()
mosaicShader:compileFromFile(nil,Misc.multiResolveFile("fuzzy_pixel.frag","shaders/npc/fuzzy_pixel.frag"))

function rooms.mosaicEffect(level,priority)
    buffer:captureAt(priority or 0)

    Graphics.drawScreen{
        texture = buffer,
        shader = mosaicShader,
        priority = priority or 0,
        uniforms = {pxSize = {camera.width/level,camera.height/level}}
    }
end

function rooms.warpToRoom(room,x,y)
    if type(room) == "number" then
        room = rooms.rooms[room]
    end
    if not room then error("Invalid room to warp to.") end

    local foundCount = 0
    local c

    for _,v in ipairs(BGO.getIntersecting(room.collider.x,room.collider.y,room.collider.x+room.collider.width,room.collider.y+room.collider.height)) do
        if rooms.respawnBGODirections[v.id] then
            if not y then
                foundCount = foundCount + 1

                if foundCount == x then
                    c = v
                    break
                end
            elseif not c or (math.abs(x-(v.x+(v.width/2)))+math.abs(y-(v.y+(v.width/2)))) < (math.abs(x-(c.x+(c.width/2)))+math.abs(y-(c.y+(c.width/2)))) then
                c = v
            end
        end
    end

    if c then
        player.x = (c.x+(c.width/2))-(player.width/2)
        player.y = (c.y+c.height-player.height)

        player.direction = rooms.respawnBGODirections[c.id]

        return
    end
end

function rooms.onInitAPI()
    registerEvent(rooms,"onTickEnd")
    registerEvent(rooms,"onStart")
    registerEvent(rooms,"onCameraUpdate")

    registerEvent(rooms,"onDraw")
    registerEvent(rooms,"onInputUpdate")

    registerEvent(rooms,"onNPCKill")
end

function rooms.onNPCKill(eventObj,v,killReason)
    if  rooms.quickRespawn
    and not eventObj.cancelled
    and not rooms.npcRespawnExceptions[v.id]
    and not (v.data and v.data._rooms and v.data._rooms.isDeathEffect)
    and (not NPC.COLLECTIBLE_MAP[v.id] or rooms.collectiblesRespawn)
    then
        if v.id <= 293 and ((killReason ~= HARM_TYPE_HELD and killReason ~= HARM_TYPE_PROJECTILE_USED) or (v:mem(0xDC,FIELD_WORD) > 0)) then
            -- Hacky work around to spawn death effects of legacy NPCs
            local w = NPC.spawn(v.id,v.x+(v.width/2),v.y+(v.height/2),v.section,false,true)

            w.data._rooms = w.data._rooms or {}
            w.data._rooms.isDeathEffect = true

            w:kill(killReason)
        elseif killReason == HARM_TYPE_SPINJUMP then
            -- Create spinjump effect
            Effect.spawn(76,v.x+(v.width/2),v.y+(v.height/2))
        end

        v.data._rooms = v.data._rooms or {}

        v.data._rooms.defeated = true

		-- Set to spawn point
		v:mem(0x124,FIELD_BOOL,false)
		v:mem(0x128,FIELD_BOOL,true)
        v:mem(0x12A,FIELD_WORD,0)
		
        resetNPC(v) -- Reset some other stuff
        
        if rooms.snakeBlocks[v.id] then
            -- Special case for snake blocks
            local data = v.data._basegame

            data.point,data.delta,data.vector = nil,nil,nil
            data.active,data.hidden = false,true

            v.isHidden = true
        end

		if v:mem(0xDC,FIELD_WORD) > 0 then
			eventObj.cancelled = true

			triggerEvent(v.deathEventName)
        end
	end
end

function rooms.onStart()
    -- Convert quicksand to rooms
    for _,v in ipairs(Liquid.get()) do
        if v.layerName == rooms.roomLayerName then
            local w = {collider = Colliders.Box(v.x,v.y,v.width,v.height),section = nil}

            if w.collider.height == 608 then
                -- Make it smaller to fit the size of the screen in case it's 608 pixels tall.
                w.collider.y = w.collider.y + 8
                w.collider.height = 600
            end

            if w.collider:collide(player) then
                rooms.currentRoomIndex = #rooms.rooms+1
                rooms.enteredRoomPos = {player.x+(player.width/2),player.y+(player.height/2)}
            end

            -- Find section of room
            for _,x in ipairs(Section.get()) do
                local b = x.boundary
                colBox.x,colBox.y = b.left,b.top
                colBox.width,colBox.height = b.right-b.left,b.bottom-b.top

                if w.collider:collide(colBox) then
                    w.section = x.idx
                    break
                end
            end

            table.insert(rooms.rooms,w)
        end
    end

    -- Hide the rooms layer
    local l = Layer.get(rooms.roomLayerName)
    if l then
        l:hide(false)
    end

    if rooms.quickRespawn then
        -- Mute death sound effect if quick respawn is active
        Audio.sounds[8].muted = true
    end

    for _,v in ipairs(Block.get()) do
        local info = {block = v,fields = {}}

        for _,w in ipairs(blockInfoFields) do
            info.fields[w] = v[w]
        end

        table.insert(rooms.savedBlockInfo,info)
    end

    rooms.startPos = {player.x+(player.width/2),player.y+player.height,direction = player.direction}
end

function rooms.onTickEnd()
    local collided

    for k,v in ipairs(rooms.rooms) do
        if v.collider:collide(player) then
            if collided then
                collided = nil
                break
            else
                collided = k
            end
        end
    end

    if collided and collided ~= rooms.currentRoomIndex then
        if rooms.transitionType ~= rooms.TRANSITION_TYPE_NONE and rooms.rooms[collided].section == rooms.rooms[rooms.currentRoomIndex].section then
            rooms.cameraInfo.state = rooms.CAMERA_STATE_TRANSITION

            if rooms.rooms[rooms.currentRoomIndex] then
                rooms.cameraInfo.startPos = {boundCamToRoom(rooms.rooms[rooms.currentRoomIndex])}
                rooms.cameraInfo.transitionPos = {boundCamToRoom(rooms.rooms[rooms.currentRoomIndex])}
            else
                rooms.cameraInfo.startPos = {camera.x,camera.y}
                rooms.cameraInfo.transitionPos = {camera.x,camera.y}
            end

            if rooms.jumpUpOnTransition then
                colBox.x = rooms.rooms[collided].collider.x
                colBox.y = rooms.rooms[collided].collider.y+rooms.rooms[collided].collider.height-24
                colBox.width = rooms.rooms[collided].collider.width
                colBox.height = 24

                if colBox:collide(player) then
                    player.speedY = -10
                end
            end

            resetDefeatedNPCs()

            Misc.pause()
        end

        rooms.currentRoomIndex = collided
        rooms.enteredRoomPos = {player.x+(player.width/2),player.y+(player.height/2)}
    end

    if rooms.quickRespawn then
        -- Code for quick respawn

        for _,v in ipairs(NPC.get()) do
            -- Prevent killed NPCs from properly respawning
            local roomData = v.data._rooms

            if roomData and roomData.defeated then
                v:mem(0x12A,FIELD_WORD,-1)
            end
        end

        if player.deathTimer > 0 and not rooms.respawnTimer then
            if rooms.deathSoundEffect then
                SFX.play(rooms.deathSoundEffect)
            end
            if rooms.deathEarthquake > 0 then
                Defines.earthquake = rooms.deathEarthquake
            end

            rooms.respawnTimer = 0

            if rooms.pauseOnRespawn then
                Misc.pause()
            end
        end
    end
end

local finished = false

function rooms.onDraw()
    if rooms.respawnTimer then
        local canReset = false
        finished = false

        local out = (rooms.resetTimer-rooms.respawnBlankTime)

        if rooms.respawnEffect == rooms.RESPAWN_EFFECT_FADE or rooms.respawnEffect == rooms.RESPAWN_EFFECT_MOSAIC then
            local o,m

            if rooms.respawnEffect == rooms.RESPAWN_EFFECT_FADE then
                if out > 0 then
                    o = (1-(out/16))
                else
                    o = (rooms.respawnTimer/16)
                end
            elseif rooms.respawnEffect == rooms.RESPAWN_EFFECT_MOSAIC then
                if out > 0 then
                    o = (1-(out/32))
                    m = (48-(out*2))
                else
                    o = (rooms.respawnTimer/32)
                    m = (rooms.respawnTimer*1.75)
                end
            end

            if o and o > 0 then
                Graphics.drawBox{
                    x = 0,y = 0,width = camera.width,height = camera.height,
                    color = Color.black.. o,priority = 5,
                }
            end
            if m and m > 1 then
                rooms.mosaicEffect(math.max(1,m),-54)
            end

            if o >= 1 then
                canReset = true
            elseif o <= 0 and out > 0 then
                finished = true
            end
        elseif rooms.respawnEffect == rooms.RESPAWN_EFFECT_DIAMOND then
            local s

            if out > 0 then
                s = (math.max(camera.width,camera.height)-(out*24))
            else
                s = (rooms.respawnTimer*24)
            end

            if s and s > 0 then
                Graphics.glDraw{
                    vertexCoords = {
                        (camera.width/2)  ,(camera.height/2)-s,
                        (camera.width/2)+s,(camera.height/2)  ,
                        (camera.width/2)  ,(camera.height/2)+s,
                        (camera.width/2)-s,(camera.height/2)  ,
                        (camera.width/2)  ,(camera.height/2)-s,
                    },
                    color = Color.black,primitive = Graphics.GL_TRIANGLE_STRIP,priority = 5,
                }
            end

            if s >= math.max(camera.width,camera.height) then
                canReset = true
            elseif s <= 0 and out > 0 then
                finished = true
            end
        end

        rooms.respawnTimer = rooms.respawnTimer + 1

        if canReset or rooms.resetTimer > 0 then
            rooms.resetTimer = (rooms.resetTimer or 0) + 1
        end

        if rooms.resetTimer == math.floor(rooms.respawnBlankTime/2)-1 then
            local currentCheckpoint = checkpoints.getActive()

            if rooms.rooms[rooms.currentRoomIndex] then
                rooms.warpToRoom(rooms.currentRoomIndex,rooms.enteredRoomPos[1],rooms.enteredRoomPos[2])
            elseif currentCheckpoint then
                player.x = ((currentCheckpoint.x)-(player.width/2))
                player.y = ((currentCheckpoint.y+32)-(player.height))

                if rooms.startPos then
                    player.direction = rooms.startPos.direction
                else
                    player.direction = DIR_RIGHT
                end
            elseif rooms.startPos then
                player.x = (rooms.startPos[1]-(player.width/2))
                player.y = (rooms.startPos[2]-player.height)
                player.direction = rooms.startPos.direction
            end

            player.speedX,player.speedY = 0,0
            player:mem(0x50,FIELD_BOOL,false)

            resetDefeatedNPCs()

            for _,v in ipairs(NPC.get()) do
                if not v.isGenerator then
                    if rooms.snakeBlocks[v.id] then
                        -- Special case for snake blocks
                        local data = v.data._basegame

                        data.point,data.delta,data.vector = nil,nil,nil
                        data.active = v.data._settings.active

                        v.isHidden = false

                        resetNPC(v)
                    else
                        v:mem(0x12A,FIELD_WORD,-1)
                        v:mem(0x124,FIELD_BOOL,false)

                        v:mem(0x12C,FIELD_WORD,0)

                        if v:mem(0xDC,FIELD_WORD) > 0 then
                            resetNPC(v)
                        else
                            v.friendly = false
                            v:kill(HARM_TYPE_OFFSCREEN)
                        end
                    end
                else
                    v.generatorTimer = 0
                end
            end
            for _,v in ipairs(Effect.get()) do
                v.x,v.y,v.speedX,v.speedY,v.timer = 0,0,0,0,0

                if v.kill then
                    v:kill()
                end
            end
            if rooms.blocksReset then
                local originallySpawnedIdxes = {}
                
                for _,v in ipairs(rooms.savedBlockInfo) do
                    if not v.block.isValid then
                        v.block = Block.spawn(v.fields.id,v.fields.x,v.fields.y) -- Create a new block if the old block was deleted
                    end

                    -- Restore saved fields
                    for _,w in ipairs(blockInfoFields) do
                        if w ~= "x" and w ~= "y" then
                            v.block[w] = v.fields[w]
                        end
                    end

                    originallySpawnedIdxes[v.block.idx] = true
                end

                for _,v in ipairs(Block.get()) do
                    if not originallySpawnedIdxes[v.idx] then
                        v:delete() -- Delete any blocks that have been spawned after the start of the level
                    end
                end

                if switch.state then switch.toggle() end -- Reset synced switches
            end

            EventManager.callEvent("onRespawnReset")
        elseif rooms.resetTimer == math.floor(rooms.respawnBlankTime/2)+1 then
            player.deathTimer = 0
            player.frame = 1

            for _,v in ipairs(NPC.get()) do
                if not v.isGenerator and v:mem(0xDC,FIELD_WORD) > 0 then
                    v:mem(0x12A,FIELD_WORD,-1)
                    v:mem(0x126,FIELD_BOOL,true)
                    v:mem(0x128,FIELD_BOOL,true)
                    v:mem(0x124,FIELD_BOOL,true)
                end
            end
        end

        if player.deathTimer > 0 then
            player.deathTimer = 1
        end
    end
end

function rooms.onInputUpdate() -- Unpausing should be done from onInputUpdate, apparently, so here we are.
    if rooms.respawnTimer and finished then
        finished = false

        player.deathTimer = 0

        rooms.respawnTimer = nil
        rooms.resetTimer = 0

        if rooms.pauseOnRespawn then
            Misc.unpause()
        end
    elseif rooms.resetTimer > 0 and rooms.resetTimer == math.floor(rooms.respawnBlankTime/2)-2 and rooms.pauseOnRespawn then
        Misc.unpause()
    elseif rooms.resetTimer > 0 and rooms.resetTimer == math.floor(rooms.respawnBlankTime/2)+1 and rooms.pauseOnRespawn then
        Misc.pause()
    end
end

function rooms.onCameraUpdate()
    local currentRoom = rooms.rooms[rooms.currentRoomIndex]

    if currentRoom then
        if rooms.cameraInfo.state == rooms.CAMERA_STATE_NORMAL then
            camera.x,camera.y = boundCamToRoom(currentRoom)
        elseif rooms.cameraInfo.state == rooms.CAMERA_STATE_TRANSITION then
            local goal = {boundCamToRoom(currentRoom)}

            if rooms.transitionType == rooms.TRANSITION_TYPE_CONSTANT or rooms.transitionType == rooms.TRANSITION_TYPE_SMOOTH then
                for i=1,2 do
                    local speed
                    if rooms.transitionType == rooms.TRANSITION_TYPE_CONSTANT then
                        speed = ((goal[i]-rooms.cameraInfo.startPos[i])*rooms.transitionSpeeds[rooms.transitionType])
                    elseif rooms.transitionType == rooms.TRANSITION_TYPE_SMOOTH then
                        speed = ((goal[i]-rooms.cameraInfo.transitionPos[i])*rooms.transitionSpeeds[rooms.transitionType])
                    end

                    if rooms.cameraInfo.transitionPos[i] > goal[i] then
                        rooms.cameraInfo.transitionPos[i] = math.max(goal[i],rooms.cameraInfo.transitionPos[i]+speed)
                    elseif rooms.cameraInfo.transitionPos[i] < goal[i] then
                        rooms.cameraInfo.transitionPos[i] = math.min(goal[i],rooms.cameraInfo.transitionPos[i]+speed)
                    end
                end
            end

            camera.x,camera.y = rooms.cameraInfo.transitionPos[1],rooms.cameraInfo.transitionPos[2]

            if (math.abs(goal[1]-rooms.cameraInfo.transitionPos[1])+math.abs(goal[2]-rooms.cameraInfo.transitionPos[2])) < 2 then
                rooms.cameraInfo.state = rooms.CAMERA_STATE_NORMAL

                rooms.cameraInfo.startPos,rooms.cameraInfo.transitionPos = nil,nil

                Misc.unpause()

                EventManager.callEvent("onRoomEnter",rooms.currentRoomIndex)
            end
        end
    end
end

---- SETTINGS BEYOND HERE ----

-- Quick respawn related stuff --

-- Quick respawn, like in Celeste.
rooms.quickRespawn = true
-- Whether or not collectibles (coins, mushrooms, 1-ups, etc) respawn after dying (only affects quick respawn).
rooms.collectiblesRespawn = true
-- Whether or not blocks reset themselves are dying (only affects quick respawn).
rooms.blocksReset = true

-- Sound effect to be played upon death. Set to nil for none, a number for a vanilla sound effect (see https://wohlsoft.ru/pgewiki/SFX_list_(SMBX64) for a list of IDs) or a string for a file.
rooms.deathSoundEffect = 38
-- How big the "earthquake" effect is upon death. Set to 0 for none.
rooms.deathEarthquake = 0
-- Whether or not the game is paused during the respawn transition.
rooms.pauseOnRespawn = true

-- The type of effect during the quick respawn transition. It can be "rooms.RESPAWN_EFFECT_FADE", "rooms.RESPAWN_EFFECT_MOSAIC" or "rooms.RESPAWN_EFFECT_DIAMOND".
rooms.respawnEffect = rooms.RESPAWN_EFFECT_MOSAIC
-- How long the screen is "blank" during the respawn transition. Should be at least 6 to work properly.
rooms.respawnBlankTime = 16

-- The direction that the player will face upon respawning on the BGO.
rooms.respawnBGODirections = {[851] = DIR_RIGHT,[852] = DIR_LEFT}


-- Room transition related stuff --

-- The type of effect used to transition between rooms. It can be "rooms.TRANSITION_TYPE_NONE", "rooms.TRANSITION_TYPE_CONSTANT" or "rooms.TRANSITION_TYPE_SMOOTH".
rooms.transitionType = rooms.TRANSITION_TYPE_SMOOTH
-- The speed of each room transition effect.
rooms.transitionSpeeds = {
    [rooms.TRANSITION_TYPE_CONSTANT] = 0.03,
    [rooms.TRANSITION_TYPE_SMOOTH]   = 0.125,
}
-- Whether or not to give the player upwards force when entering a room from the bottom.
rooms.jumpUpOnTransition = true


-- The name of the layer which rooms should be placed on.
rooms.roomLayerName = "Rooms"


return rooms