local particles = require("particles")
local rooms = require("rooms")

rooms.respawnEffect = rooms.RESPAWN_EFFECT_DIAMOND
rooms.respawnBlankTime = 8
rooms.deathSoundEffect = "Death.wav"
rooms.deathEarthquake = 10

function onStart()
	player.character = CHARACTER_MARIO
end

function onTickEnd()
	Audio.SeizeStream(0)
	Audio.MusicOpen(Misc.resolveFile("deepSeaBass.spc"))
	Audio.MusicPlay()
	if Level.winState() ~= 0 then
		Audio.MusicStop()
	end
	for _,v in ipairs(NPC.get(195,player.section)) do
		local data = v.data
		if data.trail == nil then
			data.trail = particles.Emitter(0, 0, Misc.resolveFile("iris.ini"))
			data.trail:Attach(v)
		end
	end
end

function onDraw()
    for _,v in ipairs(NPC.get(195,player.section)) do
		local data = v.data
		data.trail:Draw(-64)
	end
end