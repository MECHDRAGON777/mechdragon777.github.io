--********************************************************************--
--********************************************************************--
--		 _____          _ _       _                        __         --
--		/  ___|        (_) |     | |                      / _|        --
--		\ `--.__      ___| |_ ___| |__   ___  ___    ___ | |_         --
--		 `--. \ \ /\ / / | __/ __| '_ \ / _ \/ __|  / _ \|  _|        --
--		/\__/ /\ V  V /| | || (__| | | |  __/\__ \ | (_) | |          --
--		\____/  \_/\_/ |_|\__\___|_| |_|\___||___/  \___/|_|          --
--	 _____             _     _     _   _           _   _              --
--	/  ___|           | |   (_)   | | (_)         | | (_)             --
--	\ `--.  ___  _ __ | |__  _ ___| |_ _  ___ __ _| |_ _  ___  _ __   --
--	 `--. \/ _ \| '_ \| '_ \| / __| __| |/ __/ _` | __| |/ _ \| '_ \  --
--	/\__/ / (_) | |_) | | | | \__ \ |_| | (_| (_| | |_| | (_) | | | | --
--	\____/ \___/| .__/|_| |_|_|___/\__|_|\___\__,_|\__|_|\___/|_| |_| --
--				| |                                                   --
--				|_|                                                   --
--																	  --
--              B Y   F U Y U & M E C H D R A G O N 7 7 7             --
--																	  --
--********************************************************************--
--********************************************************************--


--****************************************************--
--  __    __  ____  ____   __   ____  __  ____  ____  --
-- (  )  (  )(  _ \(  _ \ / _\ (  _ \(  )(  __)/ ___) --
-- / (_/\ )(  ) _ ( )   //    \ )   / )(  ) _) \___ \ --
-- \____/(__)(____/(__\_)\_/\_/(__\_)(__)(____)(____/ --
--****************************************************--

local areaNames = require("areaNames") --Enjl
local rooms = require("rooms") --By Mr.DoubleA
local warpTransition = require("warpTransition") --By Mr.DoubleA
local colliders = require("colliders") --By Hoeloe

warpTransition.levelStartTransition = warpTransition.TRANSITION_NONE --Removes level start transition
warpTransition.crossSectionTransition = warpTransition.TRANSITION_MOSAIC --Makes cross-section transitions to be MOSAIC
--warpTransition.sameSectionTransition = warpTransition.TRANSITION_MOSAIC
warpTransition.musicFadeOut = false --Prevents music fadeout (no need really)

--******************************************************--
--  __    ___  ____   ____  __  ____  __    ____  ____  --
-- / _\  / __)(_  _) (_  _)(  )(_  _)(  )  (  __)/ ___) --
--/    \( (__   )(     )(   )(   )(  / (_/\ ) _) \___ \ --
--\_/\_/ \___) (__)   (__) (__) (__) \____/(____)(____/ --
--******************************************************--

areaNames.sectionNames = {
	[1] = "ACT 1 - PULLING ALL THE STOPS",
	[2] = "ACT 2 - ORDER BEFORE BRUTE FORCE",
	[3] = "ACT 3 - BE THE ROUNDABOUT",
	[4] = "ACT 4 - THERE'S ALWAYS A LOOPHOLE",
	[6] = "ACT 5 - IN ONE GO",
	[7] = "ACT 6 - TIMING IS KEY",
	[8] = "ACT 7 - REMOTE SHELL TRACK",
	[9] = "ACT 8 - ALL PAWNS ACCOUNTED FOR",
	[11] = "ACT 9 - CAREFUL PARENTING",
	[12] = "ACT 10 - FAKE LOVE",
	[13] = "ACT 11 - TO A CHILD, LOVE IS SPELLED T-I-M-E",
	[14] = "ACT 12 - CUPID'S ARROW",
	[16] = "ACT 13 - RACE THE CLOCK",
	[17] = "ACT 14 - DECEIVING LOOKS",
	[18] = "ACT 14 - POLYBRIDGE",
	[19] = "ACT 15 - RATHER ANTICLIMATIC END"
}

--*****************************************************--
-- _  _   __   ____  __   __   ____  __    ____  ____  --
--/ )( \ / _\ (  _ \(  ) / _\ (  _ \(  )  (  __)/ ___) --
--\ \/ //    \ )   / )( /    \ ) _ (/ (_/\ ) _) \___ \ --
-- \__/ \_/\_/(__\_)(__)\_/\_/(____/\____/(____)(____/ --
--*****************************************************--

local instY = 600 --Puzzle reset hint Y coordinates
local count = 250 --Zone messages timer
local zoneOpacity = 0 --Zone messages opacity
local hasPlayer --Used for door SFX handling
local S1Dir = -1 --Act 1 Switch Block direction
local S1 = 0 --Act 1 Switch Block timer
local deathWait = 10 --Timer before allowed to puzzle reset
local heartRot = 0.6 --Rotating speed of the heart sprite
local hR = 1 --Direction of the heart sprite while rotating
local trialClearTimer = 0 --The timer for the end custscene

local heartSP = Sprite{ --Heart Sprite Background
	image = Graphics.loadImage(Misc.resolveFile("heartBG1.png")),
	x = camera.x + camera.width * 0.5,
	y = camera.y + camera.height * 0.5,
	align = Sprite.align.CENTER
}

local spadeSP = Sprite{ --Spade Sprite Background
	image = Graphics.loadImage(Misc.resolveFile("spadeHands.png")),
	x = camera.x + camera.width * 0.5,
	y = camera.y + camera.height * 0.5,
	align = Sprite.align.CENTER
}

--****************************************************--
-- ____  _  _  __ _   ___  ____  __  __   __ _  ____  --
--(  __)/ )( \(  ( \ / __)(_  _)(  )/  \ (  ( \/ ___) --
-- ) _) ) \/ (/    /( (__   )(   )((  O )/    /\___ \ --
--(__)  \____/\_)__) \___) (__) (__)\__/ \_)__)(____/ --
--****************************************************--

function onStart()
	Graphics.activateHud(false) --Gets rid of the HUD
	player.character = CHARACTER_MARIO --Forces the player to be Mario
	player:mem(0x112, FIELD_WORD, 1) --Forces the player to be small
end

function onTick()
	--Handles Ending Cutscene
	if trialClear and trialClearTimer < 320 then
		Layer.get("door"):hide(true)
		zoneOpacity = 1
		if trialClearTimer == 64 then
			SFX.play(32)
			for _,k in ipairs(Block.get()) do
				if k.id == 171 then
					k:transform(172)
				elseif k.id == 172 then
					k:transform(171)
				end
			end
		elseif trialClearTimer == 128 then
			SFX.play(32)
			for _,k in ipairs(Block.get()) do
				if k.id == 177 then
					k:transform(178)
				elseif k.id == 178 then
					k:transform(177)
				end
			end
		elseif trialClearTimer == 192 then
			SFX.play(32)
			for _,k in ipairs(Block.get()) do
				if k.id == 180 then
					k:transform(181)
				elseif k.id == 181 then
					k:transform(180)
				end
			end
		elseif trialClearTimer == 256 then
			SFX.play(32)
			for _,k in ipairs(Block.get()) do
				if k.id == 174 then
					k:transform(175)
				elseif k.id == 175 then
					k:transform(174)
				end
			end
		end
		trialClearTimer = trialClearTimer + 1
	elseif trialClear then
		zoneOpacity = 0
	end

	--Handles Act 1 Moving Switch
	if S1 > 0 then
		S1 = S1 - 1
		Layer.get("S1").speedX = 2 * S1Dir
	else
		Layer.get("S1").speedX = 0
		Layer.get("Block1"):show(false)
	end

	--Kills any npc the player is currently holding when the player collides with player-only blocks
	for k,v in ipairs(Block.getIntersecting(player.x, player.y, player.x + player.width, player.y + player.height)) do
		if v.id == 658 and player.holdingNPC then
			local npc = player.holdingNPC
			npc:kill()
		end
	end

	for _,k in ipairs(NPC.get()) do
		--Makes all NPCs in the same section as the player not despawn
		if k:mem(0x146, FIELD_WORD) == player.section then
			k:mem(0x12A, FIELD_WORD, 180)
		end
		--Handles Mr.Saturn Logic
		for _,n in ipairs(NPC.get(165)) do
			if k.id == 158 and colliders.collide(k, n) then
				for _,b in ipairs(Block.get(223)) do
					b:remove(false)
				end
				k:kill(HARM_TYPE_OFFSCREEN)
				SFX.play(Misc.resolveFile("happy.ogg"))
				pass = true
				heartX = n.x
				heartY = n.y
			end
		end
	end
	
	--Draws happy Mr.Saturn upon reaching glowing heart
	if pass then
		Graphics.drawImageToSceneWP(Graphics.loadImage(Misc.resolveFile("happy.png")), heartX + 10, heartY + 18, -35)
	end
	
	--Handles which warps cause the zone clear messages to appear
	if player:mem(0x15C, FIELD_WORD) > 0 then
		hasPlayer = false
		startCountdown = false
		countDown = 0
		if player:mem(0x15E, FIELD_WORD) == 5 then diamondDone = true end
		if player:mem(0x15E, FIELD_WORD) == 11 then cloverDone = true end
		if player:mem(0x15E, FIELD_WORD) == 17 then heartDone = true end
		if player:mem(0x15E, FIELD_WORD) == 23 then spadeDone = true end
	end

	--Handles zone clear fanfares
	if instY == 577 then
		if player.section == 4 then
			Audio.MusicChange(4, 0)
			SFX.play(Misc.resolveFile("Mechanic Master DS - THEME_01_WIN.ogg"))
		elseif player.section == 9 then
			Audio.MusicChange(9, 0)
			SFX.play(Misc.resolveFile("Mechanic Master DS - THEME_05_WIN.ogg"))
		elseif player.section == 14 then
			Audio.MusicChange(14, 0)
			SFX.play(Misc.resolveFile("Mechanic Master DS - THEME_06_WIN.ogg"))
		elseif player.section == 19 then
			Audio.MusicChange(19, 0)
			SFX.play(Misc.resolveFile("Mechanic Master DS - THEME_03_WIN.ogg"))
		end
	end
	
	---Handles door warp SFX to play (default door SFX is mute as to prevent it from playing during zone clear)
	if player:mem(0x15E, FIELD_WORD) ~= 6 and player:mem(0x15E, FIELD_WORD) ~= 12 and player:mem(0x15E, FIELD_WORD) ~= 18 and player:mem(0x15E, FIELD_WORD) ~= 24 then
		if player:mem(0x122, FIELD_WORD) == 7 and not hasPlayer and not poof then
			SFX.play(Misc.resolveFile("door.ogg"))
			hasPlayer = true
		end
	end

	--Counts down until puzzle is ready to be reset
	if deathWait > 0 then
		deathWait = deathWait - 1
	end

	--Handles zone transition
	if poof then
		if diamondDone then
			player:mem(0x15E, FIELD_WORD, 6)
		elseif cloverDone then
			player:mem(0x15E, FIELD_WORD, 12)
		elseif heartDone then
			player:mem(0x15E, FIELD_WORD, 18)
		elseif spadeDone then
			player:mem(0x15E, FIELD_WORD, 24)
		end
		player.keys.up = true
	end
	
	--Handles Heart Switches -- Part 2
	if startCountdown then
		if not countDown then countDown = 0 end
		if countDown % 65 == 1 and countDown > 64 then
			SFX.play(26)
		end
		countDown = countDown + 1
		if countDown > 195 then
			startCountdown = false
			countDown = 0
			SFX.play(32)
			for _,k in ipairs(Block.get()) do
				if k.id == 89 then
					k:transform(179)
				elseif k.id == 180 then
					k:transform(181)
				elseif k.id == 181 then
					k:transform(180)
				elseif k.id == 160 then
					k:transform(173)
				elseif k.id == 174 then
					k:transform(175)
				elseif k.id == 175 then
					k:transform(174)
				end
			end
		end
	end
	
	--Prevents the same messages from appearing
	if getout then
		Layer.get("leave my room now"):show(true)
		Layer.get("oh hi"):hide(true)
	end
	
	--Resets Lua variables when the puzzle is reset	
	if rooms.respawnTimer then
		deathWait = 25
		S1Dir = -1
		pass = false
		startCountdown = false
		countDown = 0
	end
end

function onBlockHit(eventToken, hitBlock, fromUpper, playerOrNil)
	if hitBlock.id == 176 then --Destroys Clover Switches when hit
		hitBlock:remove(true)
	elseif hitBlock.id == 179 then --Handles Heart Switches -- Part 1
		for _,k in ipairs(Block.get()) do
			if k.id == 179 then
				k:transform(89)
			elseif k.id == 180 then
				k:transform(181)
			elseif k.id == 181 then
				k:transform(180)
			end
		end
		SFX.play(32)
		startCountdown = true
	elseif hitBlock.id == 173 then --Handles Spade Switches when hit
		for _,k in ipairs(NPC.get()) do
			if k.id == 155 then
				k:transform(156)
				k.speedX = 0
				k.speedY = 0
			elseif k.id == 156 then
				k:transform(155)
			end
		end
		local i = player.holdingNPC
		if i then
			if i.id == 156 then
				i:kill(9)
				NPC.spawn(i.id,player.x + player.direction*32,player.y,player.section)
			end
		end
	end
end

--Prevents player from getting bigger when collecting checkpoint
function onNPCKill(obj, npc, reason)
	if npc.id == 430 then
		player:mem(0x112, FIELD_WORD, 1)
	end
end

function onEvent(e)
	if e == "Block1Hit" then --Activated when Act 1 Question Block is hit
		Layer.get("Block1"):hide(false)
		S1Dir = -S1Dir
		S1 = 64
	elseif e == "lol" then --Activated when Starman is collected
		getout = true
	end
end

function onInputUpdate()
	--Prevents player from getting reserve box items
	if player.dropItemKeyPressing then
		player.dropItemKeyPressing = false
	end
	--Takes control away from player when zone messages are displaying
	if zoneOpacity > 0 then
		player.rightKeyPressing = false
		player.leftKeyPressing = false
		player.upKeyPressing = false
		player.downKeyPressing = false
		player.jumpKeyPressing = false
		player.altJumpKeyPressing = false
		player.altRunKeyPressing = false
		player.runKeyPressing = false
	end
	--Handles puzzle reset
	if player:mem(0x13E, FIELD_WORD) == 0 and player.altRunKeyPressing and deathWait == 0 and not trialClear then
		player:kill()
	end
end

function onDraw()
	--Makes the heart and spade sprite in the background stay in the center of the screen
	heartSP.x = camera.x + camera.width * 0.5
	heartSP.y = camera.y + camera.height * 0.5
	spadeSP.x = camera.x + camera.width * 0.5
	spadeSP.y = camera.y + camera.height * 0.5

	--Draws zone messages
	if diamondShowcase then
		Graphics.drawImageWP(Graphics.loadImage(Misc.resolveFile("diamondZone.png")), 180, 131, zoneOpacity, 5)
	elseif diamondDone then
		Graphics.drawImageWP(Graphics.loadImage(Misc.resolveFile("dzClear.png")), 150, 131, zoneOpacity, 5)
	elseif cloverShowcase then
		Graphics.drawImageWP(Graphics.loadImage(Misc.resolveFile("cloverZone.png")), 180, 131, zoneOpacity, 5)
	elseif cloverDone then
		Graphics.drawImageWP(Graphics.loadImage(Misc.resolveFile("czClear.png")), 150, 131, zoneOpacity, 5)
	elseif heartShowcase then
		Graphics.drawImageWP(Graphics.loadImage(Misc.resolveFile("heartZone.png")), 180, 131, zoneOpacity, 5)
	elseif heartDone then
		Graphics.drawImageWP(Graphics.loadImage(Misc.resolveFile("hzClear.png")), 150, 131, zoneOpacity, 5)
	elseif spadeShowcase then
		Graphics.drawImageWP(Graphics.loadImage(Misc.resolveFile("spadeZone.png")), 180, 131, zoneOpacity, 5)
	elseif spadeDone then
		Graphics.drawImageWP(Graphics.loadImage(Misc.resolveFile("szClear.png")), 150, 131, zoneOpacity, 5)
	end
	
	--Draws Heart Sprite background
	if heartSP and heartZone then
		heartSP:draw{
			priority = -99,
			sceneCoords = true
		}
	end

	--Draws Spade Sprite background
	if spadeSP and spadeZone then
		spadeSP:draw{
			priority = -99,
			sceneCoords = true
		}
	end
	
	--Handles syncronized Heart Sprite rotation
	if deathWait == 0 then
		if heartRot < 0.6 and hR == 1 then
			heartRot = heartRot + 0.01
		elseif heartRot > -0.6 and hR == -1 then
			heartRot = heartRot - 0.01
		else
			hR = -hR
		end
		heartSP:rotate(heartRot)
		spadeSP:rotate(1)
	end
	
	--Handles zone message logic
	if (diamondShowcase or cloverShowcase or heartShowcase or spadeShowcase or
	   diamondDone or cloverDone or heartDone or spadeDone) and not poof then
		if zoneOpacity < 1 then
			zoneOpacity = zoneOpacity + 0.01
			player:mem(0x15C, FIELD_WORD, 40)
		else
			if count > 0 then
				count = count - 1
				player:mem(0x15C, FIELD_WORD, 40)
			else
				poof = true
			end
		end
	else
		if zoneOpacity > 0 then
			zoneOpacity = zoneOpacity - 0.01
		else
			poof = false
			count = 250
			diamondShowcase = false
			cloverShowcase = false
			heartShowcase = false
			spadeShowcase = false
			diamondDone = false
			cloverDone = false
			heartDone = false
			spadeDone = false
			if player:mem(0x15E, FIELD_WORD) == 24 then trialClear = true end --Triggers end cutscene
		end
	end

	--Makes player invisible during zone clear
	if diamondDone or cloverDone or heartDone or spadeDone then
		player:setFrame(-50*player.direction)
	end
	
	--Handles puzzle reset hint
	if zoneOpacity > 0 or trialClear then
		if instY < 600 then
			instY = instY + 1
		end
	else
		if instY > 576 then
			player:mem(0x15C, FIELD_WORD, 0)
			instY = instY - 1
		end
	end

	--Draws puzzle reset hint
	Graphics.drawImageWP(Graphics.loadImage(Misc.resolveFile("restart.png")), 0, instY, -10)
end

--Resets everything upon section load and death
function onLoadSection()
    rooms.reset(false)
end

--Triggers Diamond Zone message
function onLoadSection0()
	diamondShowcase = true
end

--Triggers Clover Zone message
function onLoadSection5()
	cloverShowcase = true
end

--Triggers Heart Zone message
function onLoadSection10()
	heartZone = true
	heartShowcase = true
end
function onLoadSection15()
	heartZone = false
	spadeZone = true
	spadeShowcase = true
end
function onLoadSection20()
	spadeZone = false
end