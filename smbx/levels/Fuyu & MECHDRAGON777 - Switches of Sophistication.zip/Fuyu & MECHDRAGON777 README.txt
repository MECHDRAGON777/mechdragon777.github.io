Level name: Switches of Sophistication
by: Fuyu & MECHDRAGON777
Collectable Stars = 0
Credits:
- Music from Mechanic Master DS
- Graphics from SMW and tweaks and original work by Fuyu
- Sounds from SMBX + Mr.Saturn Love Sitting by Fuyu

HOW THE THEME WAS USED
Being "main problem being solved" is represented in two forms, one being the necesity for the solvence of the trial of Switches of Sophistication, and the second being the puzzles riddled throughout the level.