local HoverMeter = {} --Package table

local maxTimer = 64
HoverMeter.base = Graphics.loadImage(Misc.resolveFile("HoverMeter.png"))
HoverMeter.peg = Graphics.loadImage(Misc.resolveFile("Peg.png"))
HoverMeter.barX = 331
HoverMeter.barY = 566
HoverMeter.pegOffsetX = 26
HoverMeter.pegOffsetY = 8
HoverMeter.pegCount = 8
HoverMeter.pegWidth = 14
HoverMeter.barPriority = 4.99999999
HoverMeter.pegPriority = 5

function HoverMeter.onInitAPI() --Is called when the api is loaded by loadAPI.
	registerEvent(HoverMeter, "onDraw", "onDraw", true);
end

function HoverMeter.onDraw()
	if (player.powerup == 4 or player.powerup == 5) and maxTimer ~= 99 then
		maxTimer = 99
	end
	local hoverBar = math.floor((player:mem(0x1C, FIELD_WORD)/maxTimer)*HoverMeter.pegCount)
	Graphics.drawImageWP(HoverMeter.base, HoverMeter.barX, HoverMeter.barY, HoverMeter.barPriority)
	if not player:isGroundTouching() and not player:mem(0x18, FIELD_BOOL) then
		for i = 1, hoverBar do
			Graphics.drawImageWP(HoverMeter.peg, (HoverMeter.barX + (HoverMeter.pegOffsetX+(HoverMeter.pegWidth*(i-1)))), (HoverMeter.barY + HoverMeter.pegOffsetY), HoverMeter.pegPriority)
		end
	else
		for i = 1, 8 do
			Graphics.drawImageWP(HoverMeter.peg, (HoverMeter.barX + (HoverMeter.pegOffsetX+(HoverMeter.pegWidth*(i-1)))), (HoverMeter.barY + HoverMeter.pegOffsetY), HoverMeter.pegPriority)
		end
	end
end

return HoverMeter --Return the package when the api is getting loaded.