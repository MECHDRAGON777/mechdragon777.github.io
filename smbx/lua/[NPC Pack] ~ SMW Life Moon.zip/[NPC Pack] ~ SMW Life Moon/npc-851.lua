local npcManager = require("npcManager")

local ThreeDown = {}
local npcID = NPC_ID
npcManager.registerDefines(npcID, {NPC.COLLECTIBLE})

local ThreeDownSettings = {
	id = npcID,
	width = 30, 
	height = 32, 
	frames = 1,
	framestyle = 1,
	framespeed = 8,
	score = 2,
	speed = 1,
	playerblock=false,
	playerblocktop=false,
	npcblock=false,
	npcblocktop=false,
	spinjumpsafe=false,
	nowaterphysics=false,
	noblockcollision=true,
	cliffturn=false,
	nogravity = true,
	nofireball=false,
	noiceball=true,
	noyoshi=false,
	iswaternpc=false,
	iscollectablegoal=false,
	isvegetable=false,
	isvine=false,
	isbot=false,
	iswalker=false,
	grabtop = false,
	grabside = false,
	foreground=false,
	isflying=false,
	iscoin=false,
	isshoe=false,
	nohurt = false,
	jumphurt = false,
	isinteractable=true,
	iscoin=false
}
npcManager.registerDefines(npcID, {NPC.UNHITTABLE})

npcManager.setNpcSettings(ThreeDownSettings)

function ThreeDown.onInitAPI()
	registerEvent(ThreeDown, "onNPCKill")
end

function ThreeDown.onNPCKill(eventObj, v)
	if v.id == npcID then
		if v.direction == -1 then
			if mem(0x00B2C5AC, FIELD_FLOAT) < 3 then
				mem(0x00B2C5AC, FIELD_FLOAT, 0)
				player:kill()
			else
				mem(0x00B2C5AC, FIELD_FLOAT, (mem(0x00B2C5AC, FIELD_FLOAT) - 3))
				Audio.playSFX(Misc.resolveFile("Incorrect.ogg"))
			end
			Effect.spawn(751, player.x, player.y)
		elseif v.direction == 1 then
			if mem(0x00B2C5AC, FIELD_FLOAT) > 96 then
				mem(0x00B2C5AC, FIELD_FLOAT, 99)
			else
				mem(0x00B2C5AC, FIELD_FLOAT, (mem(0x00B2C5AC, FIELD_FLOAT) + 3))
			end
			Effect.spawn(79, player.x, player.y).animationFrame = 11
			Audio.playSFX(Misc.resolveFile("3up.ogg"))
		end
	end
end

return ThreeDown