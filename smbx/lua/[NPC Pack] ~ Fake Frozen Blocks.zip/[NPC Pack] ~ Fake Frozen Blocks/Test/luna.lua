function onStart()
	player:transform(CHARACTER_TOAD)
end