local npcManager = require("npcManager")

local FFB = {}

local npcIDs = {}

local ice

local interactingNpcList = NPC.get({13,108,246,276,85,87,260,12,210,259,206,282, 297, 356, 307, 308, 348, 351, 359, 358, 359, 362, 384, 385, 390, 402, 414, 589, 590, 667}, player.section)
local v = NPC

function FFB.register(id, type)
	npcManager.registerEvent(id, FFB, "onTickEndNPC")
	
	npcIDs[id] = type
	
	if type == 1 then GameData["Freezeable"] = id end
	if type == 2 then GameData["FakeFrozenBlocks"] = id end
end

function FFB.onInitAPI()
	registerEvent(FFB, "onTick")
	registerEvent(FFB, "onTickEndNPC")
	registerEvent(FFB, "onTickEnd")
end

function FFB.onTick(v)

end

function FFB.onTickEnd()
	local FFB_ID = GameData["FakeFrozenBlocks"]
    local Freezable_ID = GameData["Freezeable"]
    local interactingNpcList = NPC.get({13,108,246,276,85,87,260,12,210,259,206,282, 297, 356, 307, 308, 348, 351, 359, 358, 359, 362, 384, 385, 390, 402, 414, 589, 590, 667}, player.section)
    for _,v in ipairs(NPC.get({FFB_ID, Freezable_ID}, player.section)) do
        if v.id == FFB_ID then
            local box = Colliders.Box(v.x - 2, v.y - 2, v.width + 4, v.height + 4);
			for key2, v2 in ipairs(interactingNpcList)do
				if Colliders.collideNPC(v2, box) then
					v:transform(Freezable_ID)
					if v2.id == 13 or v2.id == 390 then
						v2:kill()
					end
				end
			end
        elseif v.id == Freezable_ID then
			local box = Colliders.Box(v.x - 2, v.y - 2, v.width + 4, v.height + 4);
			if Colliders.collideNPC({540}, box) then
				v:transform(FFB_ID)
			end
        end
		v.speedY = 0
		v.speedX = 0
    end
	for key,v in ipairs(NPC.get(263, player.section)) do
		if v.ai1 == Freezable_ID then
			v:transform(FFB_ID)
		end
	end
end

function FFB.onTickEndNPC(v)
	--Don't act during time freeze
	if Defines.levelFreeze then return end
	if player:mem(0x176, FIELD_WORD) > 0 then
		if player.standingNPC.id == GameData["FakeFrozenBlocks"] then
			player:mem(0x0A, FIELD_BOOL, true)
		end
	end
	local data = v.data
	
	--If despawned
	if v:mem(0x12A, FIELD_WORD) <= 0 then
		--Reset our properties, if necessary
		data.initialized = false
		return
	end

	--Initialize
	if not data.initialized then
		--Initialize necessary data.
		data.initialized = true
	end

	--Depending on the NPC, these checks must be handled differently
	if v:mem(0x12C, FIELD_WORD) > 0    --Grabbed
	or v:mem(0x136, FIELD_BOOL)        --Thrown
	or v:mem(0x138, FIELD_WORD) > 0    --Contained within
	then
		--Handling
	end
	
	--Execute main AI. This template just jumps when it touches the ground.
	if v.collidesBlockBottom then
		v.speedY = -6
	end
end
return FFB